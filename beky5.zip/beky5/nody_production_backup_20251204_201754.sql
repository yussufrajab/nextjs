--
-- PostgreSQL database dump
--

\restrict 30h9tCj4NxHCaaAKQ4VVWU9ndmaN5jQthcecEICsmCgMaobJYVgvRLwLnzK7R7G

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_institutionId_fkey";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceExtensionRequest" DROP CONSTRAINT IF EXISTS "ServiceExtensionRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceExtensionRequest" DROP CONSTRAINT IF EXISTS "ServiceExtensionRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."ServiceExtensionRequest" DROP CONSTRAINT IF EXISTS "ServiceExtensionRequest_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."SeparationRequest" DROP CONSTRAINT IF EXISTS "SeparationRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."SeparationRequest" DROP CONSTRAINT IF EXISTS "SeparationRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."SeparationRequest" DROP CONSTRAINT IF EXISTS "SeparationRequest_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."RetirementRequest" DROP CONSTRAINT IF EXISTS "RetirementRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."RetirementRequest" DROP CONSTRAINT IF EXISTS "RetirementRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."RetirementRequest" DROP CONSTRAINT IF EXISTS "RetirementRequest_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."ResignationRequest" DROP CONSTRAINT IF EXISTS "ResignationRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."ResignationRequest" DROP CONSTRAINT IF EXISTS "ResignationRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."ResignationRequest" DROP CONSTRAINT IF EXISTS "ResignationRequest_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."PromotionRequest" DROP CONSTRAINT IF EXISTS "PromotionRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."PromotionRequest" DROP CONSTRAINT IF EXISTS "PromotionRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."PromotionRequest" DROP CONSTRAINT IF EXISTS "PromotionRequest_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."Notification" DROP CONSTRAINT IF EXISTS "Notification_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."LwopRequest" DROP CONSTRAINT IF EXISTS "LwopRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."LwopRequest" DROP CONSTRAINT IF EXISTS "LwopRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."LwopRequest" DROP CONSTRAINT IF EXISTS "LwopRequest_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."Employee" DROP CONSTRAINT IF EXISTS "Employee_institutionId_fkey";
ALTER TABLE IF EXISTS ONLY public."EmployeeCertificate" DROP CONSTRAINT IF EXISTS "EmployeeCertificate_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."ConfirmationRequest" DROP CONSTRAINT IF EXISTS "ConfirmationRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."ConfirmationRequest" DROP CONSTRAINT IF EXISTS "ConfirmationRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."ConfirmationRequest" DROP CONSTRAINT IF EXISTS "ConfirmationRequest_employeeId_fkey";
ALTER TABLE IF EXISTS ONLY public."Complaint" DROP CONSTRAINT IF EXISTS "Complaint_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."Complaint" DROP CONSTRAINT IF EXISTS "Complaint_complainantId_fkey";
ALTER TABLE IF EXISTS ONLY public."CadreChangeRequest" DROP CONSTRAINT IF EXISTS "CadreChangeRequest_submittedById_fkey";
ALTER TABLE IF EXISTS ONLY public."CadreChangeRequest" DROP CONSTRAINT IF EXISTS "CadreChangeRequest_reviewedById_fkey";
ALTER TABLE IF EXISTS ONLY public."CadreChangeRequest" DROP CONSTRAINT IF EXISTS "CadreChangeRequest_employeeId_fkey";
DROP INDEX IF EXISTS public."idx_employee_retirementDate_range";
DROP INDEX IF EXISTS public."idx_employee_retirementDate";
DROP INDEX IF EXISTS public.idx_employee_probation_overdue;
DROP INDEX IF EXISTS public.idx_employee_institution_retirement;
DROP INDEX IF EXISTS public.idx_employee_institution_probation;
DROP INDEX IF EXISTS public."User_username_key";
DROP INDEX IF EXISTS public."User_employeeId_key";
DROP INDEX IF EXISTS public."Institution_tinNumber_key";
DROP INDEX IF EXISTS public."Institution_name_key";
DROP INDEX IF EXISTS public."Employee_zanId_key";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."ServiceExtensionRequest" DROP CONSTRAINT IF EXISTS "ServiceExtensionRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."SeparationRequest" DROP CONSTRAINT IF EXISTS "SeparationRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."RetirementRequest" DROP CONSTRAINT IF EXISTS "RetirementRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."ResignationRequest" DROP CONSTRAINT IF EXISTS "ResignationRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."PromotionRequest" DROP CONSTRAINT IF EXISTS "PromotionRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."Notification" DROP CONSTRAINT IF EXISTS "Notification_pkey";
ALTER TABLE IF EXISTS ONLY public."LwopRequest" DROP CONSTRAINT IF EXISTS "LwopRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."Institution" DROP CONSTRAINT IF EXISTS "Institution_pkey";
ALTER TABLE IF EXISTS ONLY public."Employee" DROP CONSTRAINT IF EXISTS "Employee_pkey";
ALTER TABLE IF EXISTS ONLY public."EmployeeCertificate" DROP CONSTRAINT IF EXISTS "EmployeeCertificate_pkey";
ALTER TABLE IF EXISTS ONLY public."ConfirmationRequest" DROP CONSTRAINT IF EXISTS "ConfirmationRequest_pkey";
ALTER TABLE IF EXISTS ONLY public."Complaint" DROP CONSTRAINT IF EXISTS "Complaint_pkey";
ALTER TABLE IF EXISTS ONLY public."CadreChangeRequest" DROP CONSTRAINT IF EXISTS "CadreChangeRequest_pkey";
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."ServiceExtensionRequest";
DROP TABLE IF EXISTS public."SeparationRequest";
DROP TABLE IF EXISTS public."RetirementRequest";
DROP TABLE IF EXISTS public."ResignationRequest";
DROP TABLE IF EXISTS public."PromotionRequest";
DROP TABLE IF EXISTS public."Notification";
DROP TABLE IF EXISTS public."LwopRequest";
DROP TABLE IF EXISTS public."Institution";
DROP TABLE IF EXISTS public."EmployeeCertificate";
DROP TABLE IF EXISTS public."Employee";
DROP TABLE IF EXISTS public."ConfirmationRequest";
DROP TABLE IF EXISTS public."Complaint";
DROP TABLE IF EXISTS public."CadreChangeRequest";
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: CadreChangeRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CadreChangeRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "newCadre" text NOT NULL,
    reason text,
    "studiedOutsideCountry" boolean,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CadreChangeRequest" OWNER TO postgres;

--
-- Name: Complaint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Complaint" (
    id text NOT NULL,
    "complaintType" text NOT NULL,
    subject text NOT NULL,
    details text NOT NULL,
    "complainantPhoneNumber" text NOT NULL,
    "nextOfKinPhoneNumber" text NOT NULL,
    attachments text[],
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "officerComments" text,
    "internalNotes" text,
    "rejectionReason" text,
    "complainantId" text NOT NULL,
    "assignedOfficerRole" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Complaint" OWNER TO postgres;

--
-- Name: ConfirmationRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConfirmationRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "decisionDate" timestamp(3) without time zone,
    "commissionDecisionDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ConfirmationRequest" OWNER TO postgres;

--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    id text NOT NULL,
    "employeeEntityId" text,
    name text NOT NULL,
    gender text NOT NULL,
    "profileImageUrl" text,
    "dateOfBirth" timestamp(3) without time zone,
    "placeOfBirth" text,
    region text,
    "countryOfBirth" text,
    "zanId" text NOT NULL,
    "phoneNumber" text,
    "contactAddress" text,
    "zssfNumber" text,
    "payrollNumber" text,
    cadre text,
    "salaryScale" text,
    ministry text,
    department text,
    "appointmentType" text,
    "contractType" text,
    "recentTitleDate" timestamp(3) without time zone,
    "currentReportingOffice" text,
    "currentWorkplace" text,
    "employmentDate" timestamp(3) without time zone,
    "confirmationDate" timestamp(3) without time zone,
    "retirementDate" timestamp(3) without time zone,
    status text,
    "ardhilHaliUrl" text,
    "confirmationLetterUrl" text,
    "jobContractUrl" text,
    "birthCertificateUrl" text,
    "institutionId" text NOT NULL
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: EmployeeCertificate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmployeeCertificate" (
    id text NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    url text,
    "employeeId" text NOT NULL
);


ALTER TABLE public."EmployeeCertificate" OWNER TO postgres;

--
-- Name: Institution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Institution" (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    "phoneNumber" text,
    "voteNumber" text,
    "tinNumber" text
);


ALTER TABLE public."Institution" OWNER TO postgres;

--
-- Name: LwopRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LwopRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    duration text NOT NULL,
    reason text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "startDate" timestamp(3) without time zone
);


ALTER TABLE public."LwopRequest" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    message text NOT NULL,
    link text,
    "isRead" boolean DEFAULT false NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: PromotionRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PromotionRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "proposedCadre" text NOT NULL,
    "promotionType" text NOT NULL,
    "studiedOutsideCountry" boolean,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "commissionDecisionReason" text
);


ALTER TABLE public."PromotionRequest" OWNER TO postgres;

--
-- Name: ResignationRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ResignationRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "effectiveDate" timestamp(3) without time zone NOT NULL,
    reason text,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ResignationRequest" OWNER TO postgres;

--
-- Name: RetirementRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RetirementRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "retirementType" text NOT NULL,
    "illnessDescription" text,
    "proposedDate" timestamp(3) without time zone NOT NULL,
    "delayReason" text,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."RetirementRequest" OWNER TO postgres;

--
-- Name: SeparationRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SeparationRequest" (
    id text NOT NULL,
    type text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    reason text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SeparationRequest" OWNER TO postgres;

--
-- Name: ServiceExtensionRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceExtensionRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "currentRetirementDate" timestamp(3) without time zone NOT NULL,
    "requestedExtensionPeriod" text NOT NULL,
    justification text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceExtensionRequest" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "employeeId" text,
    "institutionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "phoneNumber" text,
    email text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Data for Name: CadreChangeRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CadreChangeRequest" (id, status, "reviewStage", "newCadre", reason, "studiedOutsideCountry", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Complaint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Complaint" (id, "complaintType", subject, details, "complainantPhoneNumber", "nextOfKinPhoneNumber", attachments, status, "reviewStage", "officerComments", "internalNotes", "rejectionReason", "complainantId", "assignedOfficerRole", "reviewedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ConfirmationRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConfirmationRequest" (id, status, "reviewStage", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "decisionDate", "commissionDecisionDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Employee" (id, "employeeEntityId", name, gender, "profileImageUrl", "dateOfBirth", "placeOfBirth", region, "countryOfBirth", "zanId", "phoneNumber", "contactAddress", "zssfNumber", "payrollNumber", cadre, "salaryScale", ministry, department, "appointmentType", "contractType", "recentTitleDate", "currentReportingOffice", "currentWorkplace", "employmentDate", "confirmationDate", "retirementDate", status, "ardhilHaliUrl", "confirmationLetterUrl", "jobContractUrl", "birthCertificateUrl", "institutionId") FROM stdin;
\.


--
-- Data for Name: EmployeeCertificate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."EmployeeCertificate" (id, type, name, url, "employeeId") FROM stdin;
\.


--
-- Data for Name: Institution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Institution" (id, name, email, "phoneNumber", "voteNumber", "tinNumber") FROM stdin;
cmd059ion0000e6d85kexfukl	TUME YA UTUMISHI SERIKALINI	info@zanajira.go.tz	0773101012	037	101817199
cmd06xe45000xe6bqb6qc19ys	MAMLAKA YA KUDHIBITI NA KUPAMBANA NA DAWA ZA KULEVYA ZANZIBAR	info@zdcea.go.tz	+255242233403	032	141776339
cmd06xe3w000te6bqc44b0xpr	MAMLAKA YA KUZUIA RUSHWA NA UHUJUMU WA UCHUMI ZANZIBAR	info@zaeca.go.tz	0774824242	035	122439755
cmd06nn7u0003e67wa4hiyie7	WIZARA YA AFYA	info@mohz.go.tz	+255242231614	008	101817180
cmd06xe3y000ue6bqzqkztrsa	WIZARA YA ARDHI NA MAENDELEO YA MAKAAZI ZANZIBAR	info@ardhismz.go.tz	0242941193	014	101697509
cmd06nn7r0002e67w8df8thtn	WIZARA YA ELIMU NA MAFUNZO YA AMALI	info@moez.go.tz	+255777458878	011	101817709
cme6s7yqe000m2bgx708j9uly	Tume ya kusimamia Nidhamu	\N	\N	\N	\N
cmd06xe3t000se6bqknluakbq	OFISI YA MUFTI MKUU WA ZANZIBAR	info@muftizanzibar.go.tz	0777483627	\N	\N
cmd06xe43000we6bqegt3ofa0	OFISI YA RAIS - IKULU	info@ikuluzanzibar.go.tz	+2252230814#5	567	\N
cmd06xe48000ye6bqwhlp0tum	TUME YA MAADILI YA VIONGOZI WA UMMA	info@ethicscommission.go.tz	+255242235535	113	136664387
cmd06xe4g0012e6bqou5f9gur	WIZARA YA MAJI NISHATI NA MADINI	info@majismz.go.tz	0242232695	15	150308305
cmd06xe40000ve6bqrip9e4m6	WIZARA YA UTALII NA MAMBO YA KALE	info@utaliismz.go.tz	0242231250	10	104480454
cmd4a32f22d9f78e3dec338	Wakala wa Matrekta	\N	\N	527	136148710
cmdca390e5b7e3c6f4ddbd4	Baraza la Jiji	\N	\N	201	141760874
cmde5633af0fb1bb7af7905	Skuli ya Sheria Zanzibar	\N	\N	570	154057374
cmd06xe2w000de6bqzqo9qu3m	TAASISI YA ELIMU ZANZIBAR	info@zie.go.tz	+255242230193	542	165130197
cmd06xe4b0010e6bqt54zkblq	AFISI YA MKURUGENZI WA MASHTAKA	dppznz@dppznz.go.tz	+255-24-2235564	029	107779272
cmd06xe4e0011e6bqv8eg0b16	AFISI YA MWANASHERIA MKUU	info@agcz.go.tz	0242232502	028	101817016
cmd06xe2o000ae6bquqbkbg4z	AFISI YA RAISI KAZI, UCHUMI NA UWEKEZAJI	info@arkuusmz.go.tz	0242230061	006	101697533
cmd1ff26c0c4e3e30140a6e	Hospitali ya Mnazi Mmoja	\N	\N	025	124546745
cmd06xe3n000pe6bquce6e6ga	TUME YA UCHAGUZI YA ZANZIBAR	info@zec.go.tz	242231489	031	106692653
cmd3c2909246966ab8bc819	Tume ya Mipango	\N	\N	024	121462354
cmd06xe2a0004e6bqwbtjm4x9	KAMISHENI YA UTUMISHI WA UMMA	kamisheni.utumishi@zpsc.go.tz	+255242230872	036	145869242
cmd06xe39000je6bqeouszvrd	OFISI YA MAKAMO WA KWANZA WA RAISI	info@omkr.go.tz	+255 242232475	002	115615637
cmd06xe2r000be6bqrqhwhbq1	KAMISHENI YA UTALII ZANZIBAR	info@zanzibartourism.go.tz	+255 24 2233485	\N	\N
cmd06xe3p000qe6bqwqcuyke1	OFISI YA MAKAMO WA PILI WA RAISI	info@ompr.go.tz	0242231826	003	101817601
cmd06xe2j0008e6bqqpmbs9bv	Ofisi ya Mhasibu Mkuu wa Serikali	info@mofzanzibar.go.tz	024776666	023	111658218
cmd06xe2e0006e6bqvjfhq32c	OFISI YA MKAGUZI MKUU WA NDANI WA SERIKALI	info@oiagsmz.go.tz	255743600320	052	156958174
cmd5f2656be26e643588334	Ofisi ya Mkuu wa Mkoa wa Kaskazini Pemba	\N	\N	051	119060877
cmd6c89e74df51ddc217c8c	Ofisi ya Mkuu wa Mkoa wa Kaskazini Unguja	\N	\N	048	107779450
cmd91d823ed52820fc6020f	Ofisi ya Mkuu wa Mkoa wa Kusini Pemba	\N	\N	050	119062888
cmd06xe220001e6bqj26tnlsj	Ofisi ya Mkuu wa Mkoa wa Kusini Unguja	info@southunguja.go.tz	0777433124	049	107779477
cmd06xe3g000me6bqh9gabe3e	OFISI YA RAIS, TAWALA ZA MIKOA, SERIKALI ZA MITAA NA IDARA MAALUMU ZA SMZ	info@tamisemim.go.tz	+255242230034	004	101732835
cmddc37c28c068eb077e082	Ofisi ya Mkuu wa Mkoa wa Mjini Magharibi Unguja	\N	\N	047	107779396
cmd06xe3i000ne6bq2q3y9g2z	OFISI YA RAIS - KATIBA SHERIA UTUMISHI NA UTAWALA BORA	info@utumishismz.go.tz	+255242230034	005	141811827
cmd06xe2m0009e6bq0ps9u9ut	TAASISI YA NYARAKA NA KUMBUKUMBU	info@ziar.go.tz	11111111111	057	165400550
cmd06xe3b000ke6bqxuwovzub	WIZARA YA BIASHARA NA MAENDELEO YA VIWANDA	info@tradesmz.go.tz	024-2941140	017	101789799
cmd06xe3l000oe6bq5drrocqt	WIZARA YA HABARI, VIJANA, UTAMADUNI NA MICHEZO	info@habarismz.go.tz	0242231202	018	137692902
cmd06xe34000he6bqfdqiw9ll	WIZARA YA KILIMO UMWAGILIAJI MALIASILI NA MIFUGO	ps@kilimoznz.go.tz	0777868306	012	101817679
cmd06xe270003e6bq0wm0v3c7	WIZARA YA MAENDELEO YA JAMII,JINSIA,WAZEE NA WATOTO	info@jamiismz.go.tz	+255242231413	019	157443895
cmd240bed02bab1eccc8039	Mamlaka ya Serikali Mtandao (eGAZ)	\N	\N	038	154803912
cmdd75324353437b4a24d98	Chuo cha Kiislamu	\N	\N	\N	\N
cmd6d9165d0597ad7596c4c	JKU	\N	\N	\N	\N
cmdb53ddd6c0a56b44ed006	Magereza	\N	\N	\N	\N
cmd233f6362082a7199509b	Baraza la Mji Kaskazini A Unguja	\N	\N	207	141799118
cmdfb652b1e5f9cc9589ae4	Baraza la Mji Kaskazini B Unguja	\N	\N	208	106226431
cmd25a57d5fa38437bac519	Ofisi ya Hatimiliki (COSOZA)	\N	\N	558	132175306
cmd06xe2h0007e6bqta680e3b	KAMISHENI YA ARDHI ZANZIBAR	info@kamisheniardhi.go.tz	0774776619	520	101816990
cmd06xe2y000ee6bqel875c2s	KAMISHENI YA KUKABILIANA NA MAAFA ZANZIBAR	zdmc@maafaznz.go.tz	+255242234755	510	119752302
cmd06xe1x0000e6bqalx28nja	Ofisi ya Msajili wa Hazina	info@trosmz.go.tz	111111111111	106	176281286
cmd06nn7n0001e67w2h5rf86x	OFISI YA RAIS, FEDHA NA MIPANGO	info@mofzanzibar.go.tz	+255 2477666664/5	567	\N
cmd06xe30000fe6bqe6ljiz1v	WAKALA WA MAJENGO ZANZIBAR	info@zba.go.tz	0242232695	522	137516160
cmd06xe250002e6bqp8aabk92	Wakala wa Vipimo Zanzibar	info@zawemasmz.go.tz	0778586654	519	157124463
cmd06xe3r000re6bqum8g62id	WIZARA YA UCHUMI WA BULUU NA UVUVI	info@blueeconomy.go.tz	242941195	13	150874084
cmd06xe37000ie6bq43r62ea6	WIZARA YA UJENZI MAWASILIANO NA UCHUKUZI	info@moic.go.tz	0242941138	16	101817156
cmd02cee2d68e90a9e93d12	Baraza la Mji Chake Chake	\N	\N	210	119062896
cmde5b940e9d54567bfc3a4	Baraza la Mji Wete	\N	\N	211	119065402
cmd77f48672584df7bbec35	Baraza la Mji Mkoani	\N	\N	209	119062756
cmdf0c43f7013ab7f2a66fb	Halmashauri ya Wilaya ya Micheweni	\N	\N	212	137833387
cmd536a0c15bebc592f98dc	Baraza la Mji Kati Unguja	\N	\N	205	134349867
cmdfdb6ca0e59fb2784253c	Halmashauri ya Wilaya ya Kusini Unguja	\N	\N	206	137926121
cmd59d412885295792e5a6f	Baraza la Manispaa Mjini Unguja	\N	\N	202	121454009
cmd4caf3852445c2568bc7c	Baraza la Manispaa Magharibi A	\N	\N	203	137175088
cmdbcf753dfb9d0ae18259a	Baraza la Manispaa Magharibi B	\N	\N	204	129840552
cmd4375abda3f14b3a95b77	Taasisi ya Utafiti wa Uvuvi (ZAFIRI)	\N	\N	526	140711764
cmd2be7aa7f5b3c47595cc4	Kamisheni ya Kazi	\N	\N	573	101817687
cmd4c5ec2ff8bee042f8320	Mamlaka ya Uwezeshaji Wananchi Kiuchumi (ZEA)	\N	\N	105	176332557
cmd1545dfaf1f7a12e14814	Baraza la Mitihani	\N	\N	547	124650941
cmdc44d2a81af54539661a3	Ofisi ya Mkaguzi wa Elimu	\N	\N	546	181476419
cmdb58cb33c0f5031c1db39	Bodi ya Huduma za Maktaba	\N	\N	543	114542164
cmd2376970b68ca8887a4fa	Wakala wa Barabara	\N	\N	559	151578152
cmdd32c25c06bcef1153da0	Tume ya Ushindani Halali wa Biashara	\N	\N	518	148444331
\.


--
-- Data for Name: LwopRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LwopRequest" (id, status, "reviewStage", duration, reason, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt", "endDate", "startDate") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, message, link, "isRead", "userId", "createdAt") FROM stdin;
\.


--
-- Data for Name: PromotionRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PromotionRequest" (id, status, "reviewStage", "proposedCadre", "promotionType", "studiedOutsideCountry", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt", "commissionDecisionReason") FROM stdin;
\.


--
-- Data for Name: ResignationRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ResignationRequest" (id, status, "reviewStage", "effectiveDate", reason, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: RetirementRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RetirementRequest" (id, status, "reviewStage", "retirementType", "illnessDescription", "proposedDate", "delayReason", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SeparationRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SeparationRequest" (id, type, status, "reviewStage", reason, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ServiceExtensionRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceExtensionRequest" (id, status, "reviewStage", "currentRetirementDate", "requestedExtensionPeriod", justification, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, username, password, role, active, "employeeId", "institutionId", "createdAt", "updatedAt", "phoneNumber", email) FROM stdin;
cmecjzkmi00032bhu3ts6wi8y	Shaibu Nassor Juma	snjuma	$2a$10$6DRPqfw6bxMZ3Nmp84Y8IOURcSe1GLjApM5A24//FI2Y2Cqfcwnke	HRO	t	\N	cmd06xe2o000ae6bquqbkbg4z	2025-08-15 08:15:29.322	2025-08-15 08:15:29.322	0987654321	shaibu.juma@gmail.local
cmd06nn9p0005e67wgvz3pd6c	Amina Kassim	akassim	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	Admin	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.421	2025-08-03 03:39:26.051	\N	akassim@mock.local
cmd06nnb50007e67wa5491lw5	Zaituni Haji	zhaji	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	CSCS	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.473	2025-08-03 03:39:26.052	\N	zhaji@mock.local
cmd06nnbb000be67wwgil78yv	Fauzia Iddi	fiddi	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRMO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.479	2025-07-20 05:28:54.194	\N	fiddi@mock.local
cmd06nnbd000de67wb6e6ild5	Maimuna Ussi	mussi	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	DO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.482	2025-07-20 05:28:54.195	\N	mussi@mock.local
cmd06nnbg000fe67wdbus4imu	Mwanakombo Is-hak	mishak	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	PO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.484	2025-07-20 05:28:54.196	\N	mishak@mock.local
cmd06nnbi000he67wz9doivi6	Khamis Hamadi	khamadi	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRRP	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.487	2025-07-20 05:28:54.197	\N	khamadi@mock.local
cmd06nnbl000je67wtl28pk42	HRO (Tume)	hro_commission	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.489	2025-07-20 05:28:54.198	\N	hro_commission@mock.local
cmd06nnbn000le67wtg41s3su	Khamis Mnyonge	kmnyonge	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd06nn7n0001e67w2h5rf86x	2025-07-12 11:49:21.492	2025-07-20 05:28:54.199	\N	kmnyonge@mock.local
cmd06nnbq000ne67wwmiwxuo8	Ahmed Mohammed	ahmedm	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd06nn7r0002e67w8df8thtn	2025-07-12 11:49:21.494	2025-07-20 05:28:54.2	\N	ahmedm@mock.local
cmd06nnbs000pe67woh62ey8r	Mariam Juma	mariamj	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd06nn7u0003e67wa4hiyie7	2025-07-12 11:49:21.497	2025-07-20 05:28:54.202	\N	mariamj@mock.local
cmd059ir10002e6d86l802ljc	Safia Khamis	skhamis	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	HHRMD	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:10:22.766	2025-08-03 03:39:26.045	\N	skhamis@mock.local
admin-backend-id	System Administrator	admin	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	ADMIN	t	\N	cmd059ion0000e6d85kexfukl	2025-07-20 22:03:33.497	2025-08-03 03:39:26.05	\N	admin@mock.local
user_1753046780450	Test User Updated	4hhrmd	defaultpassword	HHRMD	f	\N	cmd059ion0000e6d85kexfukl	2025-07-21 00:26:20.451	2025-07-21 17:14:36.713	\N	4hhrmd@mock.local
cme471pqo00032bidhttxmboj	Yassir Haji Zubeir	yhzubeir	$2a$10$RC7M40AM.F/rT7lD/0gfEu3Vobdi1kNcJFwa8WwbyboVe5twn39X2	HRO	t	\N	cmd06nn7u0003e67wa4hiyie7	2025-08-09 11:51:04.847	2025-08-09 11:53:40.935	\N	yhzubeir@mock.local
cme56ma17000x2btjnpvgr0kg	Yussuf Mzee Rajab	ymrajab	$2a$10$d7GxHTx8ZGjqYAmyhWtk8ezoC./BjFDAweFQ86NecSyhfJMJCD7Cm	Admin	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:26:50.826	2025-08-10 04:26:50.826	\N	ymrajab@mock.local
cme57api100042bcqhbkg91r8	sophy majaribio	safiatest	$2a$10$358txTTZ/4JutwHfTxbT1./z0yFTqbkCoCUMtaDWXMsI0BSz5irG6	HHRMD	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:45:50.616	2025-08-10 04:45:50.616	\N	safiatest@mock.local
cme57bm9600062bcqtlkj9wcx	Maimuna Majaribio	maitest	$2a$10$logSYVyjw8nccvm12H72huhbLpQ89UWgmyfeVvjIpscRo.hPp9ACa	DO	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:46:33.066	2025-08-10 04:46:33.066	\N	maitest@mock.local
cme57cciu00082bcqnbw9sjm9	Fauzia Majaribo	fautest	$2a$10$Hw29S3kizuE1Sl205UtwouNarFkFqybH28HfXwbMFtQbJ4SHpMxhu	HRMO	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:47:07.075	2025-08-10 04:47:07.075	\N	fautest@mock.local
cme6sts42000o2bgxfjax08co	Abdalla Juma Abdalla	ajabdalla	$2a$10$c25cE7dGWhdP9xsO7o04mueaGkwgb2adEeelffsH55QILrKArmQn.	HRO	t	\N	cme6s7yqe000m2bgx708j9uly	2025-08-11 07:36:18.578	2025-08-11 07:36:18.578	0987654321	ajabdalla@mock.local
d7e938ff-71f8-41fd-b954-cd840855049a	Fauzia Makame	fmakame	$2a$10$ZYQIoqjVPOQMnk6.ORYPgeKFIGrNl9azMJiRohFULi.paNIcV1FbW	HRO	t	\N	cmd1545dfaf1f7a12e14814	2025-12-04 06:55:24.24	2025-12-04 06:55:24.238	0774564624	fmakame@bmz.go.tz
42635a13-283a-48eb-9752-752bbda196b9	Mwanaidi sallum	msalum	$2a$10$kigZun7lIgIX1lrMQID8l.s.1KAjGf41cNs8rtEQlE5NLO5Ralpmu	HRO	t	\N	cmd06xe4e0011e6bqv8eg0b16	2025-12-03 12:19:39.904	2025-12-03 12:19:39.903	0777626242	msalum@sheria.go.tz
f965a775-0572-4469-aab3-ad1d0f7e2032	Harith Abdalla	habdalla	$2a$10$TBCJXfqag57hlPK4361t/.AOo145q6STuNQWQqXcXZ0MoR1RZMEwq	HRO	t	\N	cmd06xe2h0007e6bqta680e3b	2025-12-03 12:40:57.681	2025-12-03 12:40:57.679	0776346383	habadalla@ardhi.go.tz
7011a404-7ebc-4c2d-96dd-807a073b5911	Lela Kassim Ali	lkali	$2a$10$EVAP8ZlNSPTzHFDkscKcUONwMpUL1LgAZ/iw.r.Gy3J8KEzJl.wte	HRO	t	\N	cmd06xe34000he6bqfdqiw9ll	2025-12-03 12:54:02.473	2025-12-03 12:54:02.471	0776382949	lkali@kilimo.go.tz
33e358d2-1820-415d-abab-3213926e2096	Salma Ali	sali	$2a$10$n4UqZKZ8zlmdxP4Ln6HrkuSR8iPvKtVoOf/TGXFVePFbYaKvH3AKO	HRO	t	\N	cmd06xe2e0006e6bqvjfhq32c	2025-12-03 14:28:56.149	2025-12-03 14:28:56.147	0773527322	sali@mkaguzi.go.tz
5382cf01-9b4e-4dbc-833b-ec88a02e49b4	zulfa shariff	zshariff	$2a$10$9Cs06omqcc6Oq1VFIjYJyuTTU67QcSgFSf4m7bLi/HF2hxl72ZhoK	HRO	t	\N	cmd06xe2j0008e6bqqpmbs9bv	2025-12-03 16:12:18.826	2025-12-03 16:12:18.824	0774234826	zshariff@mhasibu.go.tz
69b8c30e-ffab-466c-8c86-6e6d1c1ff4ee	Shuwekha Kassim Awesu	skawesu	$2a$10$Hu0jlanL97PA0/5UaDQMaOv4bBm7.tUmhVvZvqjkGD8LzgDeSB0Ey	HRO	t	\N	cmd059ion0000e6d85kexfukl	2025-12-04 07:11:04.075	2025-12-04 07:11:04.073	0775462416	skawesu@tus.go.tz
\.


--
-- Name: CadreChangeRequest CadreChangeRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_pkey" PRIMARY KEY (id);


--
-- Name: Complaint Complaint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_pkey" PRIMARY KEY (id);


--
-- Name: ConfirmationRequest ConfirmationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_pkey" PRIMARY KEY (id);


--
-- Name: EmployeeCertificate EmployeeCertificate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeCertificate"
    ADD CONSTRAINT "EmployeeCertificate_pkey" PRIMARY KEY (id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (id);


--
-- Name: Institution Institution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Institution"
    ADD CONSTRAINT "Institution_pkey" PRIMARY KEY (id);


--
-- Name: LwopRequest LwopRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PromotionRequest PromotionRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_pkey" PRIMARY KEY (id);


--
-- Name: ResignationRequest ResignationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_pkey" PRIMARY KEY (id);


--
-- Name: RetirementRequest RetirementRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_pkey" PRIMARY KEY (id);


--
-- Name: SeparationRequest SeparationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_pkey" PRIMARY KEY (id);


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Employee_zanId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Employee_zanId_key" ON public."Employee" USING btree ("zanId");


--
-- Name: Institution_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Institution_name_key" ON public."Institution" USING btree (name);


--
-- Name: Institution_tinNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Institution_tinNumber_key" ON public."Institution" USING btree ("tinNumber");


--
-- Name: User_employeeId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_employeeId_key" ON public."User" USING btree ("employeeId");


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: idx_employee_institution_probation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_institution_probation ON public."Employee" USING btree ("institutionId", status, "employmentDate") WHERE (status <> 'Confirmed'::text);


--
-- Name: idx_employee_institution_retirement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_institution_retirement ON public."Employee" USING btree ("institutionId", "retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: idx_employee_probation_overdue; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_probation_overdue ON public."Employee" USING btree (status, "employmentDate") WHERE (status <> 'Confirmed'::text);


--
-- Name: idx_employee_retirementDate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_employee_retirementDate" ON public."Employee" USING btree ("retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: idx_employee_retirementDate_range; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_employee_retirementDate_range" ON public."Employee" USING btree ("retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: CadreChangeRequest CadreChangeRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CadreChangeRequest CadreChangeRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CadreChangeRequest CadreChangeRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Complaint Complaint_complainantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_complainantId_fkey" FOREIGN KEY ("complainantId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Complaint Complaint_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConfirmationRequest ConfirmationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConfirmationRequest ConfirmationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConfirmationRequest ConfirmationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmployeeCertificate EmployeeCertificate_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeCertificate"
    ADD CONSTRAINT "EmployeeCertificate_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Employee Employee_institutionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES public."Institution"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LwopRequest LwopRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LwopRequest LwopRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LwopRequest LwopRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PromotionRequest PromotionRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PromotionRequest PromotionRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PromotionRequest PromotionRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResignationRequest ResignationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResignationRequest ResignationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResignationRequest ResignationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RetirementRequest RetirementRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RetirementRequest RetirementRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RetirementRequest RetirementRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SeparationRequest SeparationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SeparationRequest SeparationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeparationRequest SeparationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: User User_institutionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES public."Institution"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 30h9tCj4NxHCaaAKQ4VVWU9ndmaN5jQthcecEICsmCgMaobJYVgvRLwLnzK7R7G

