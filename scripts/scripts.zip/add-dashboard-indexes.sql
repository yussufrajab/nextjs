-- Dashboard Performance Optimization Indexes
-- This script adds indexes to improve dashboard loading performance
-- Run this with: PGPASSWORD=your_password psql -h localhost -U postgres -d nody -f scripts/add-dashboard-indexes.sql

-- Employee table indexes (most critical for performance)
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_institutionId" ON "Employee"("institutionId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_status" ON "Employee"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_retirementDate" ON "Employee"("retirementDate") WHERE "retirementDate" IS NOT NULL;
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_employmentDate" ON "Employee"("employmentDate");

-- ConfirmationRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_confirmationrequest_status" ON "ConfirmationRequest"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_confirmationrequest_employeeId" ON "ConfirmationRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_confirmationrequest_updatedAt" ON "ConfirmationRequest"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_confirmationrequest_status_updatedAt" ON "ConfirmationRequest"("status", "updatedAt" DESC);

-- PromotionRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_promotionrequest_status" ON "PromotionRequest"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_promotionrequest_employeeId" ON "PromotionRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_promotionrequest_updatedAt" ON "PromotionRequest"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_promotionrequest_status_updatedAt" ON "PromotionRequest"("status", "updatedAt" DESC);

-- LwopRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_lwoprequest_employeeId" ON "LwopRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_lwoprequest_updatedAt" ON "LwopRequest"("updatedAt" DESC);

-- Complaint indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_complaint_status" ON "Complaint"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_complaint_complainantId" ON "Complaint"("complainantId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_complaint_updatedAt" ON "Complaint"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_complaint_status_updatedAt" ON "Complaint"("status", "updatedAt" DESC);

-- SeparationRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_separationrequest_status" ON "SeparationRequest"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_separationrequest_employeeId" ON "SeparationRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_separationrequest_updatedAt" ON "SeparationRequest"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_separationrequest_status_updatedAt" ON "SeparationRequest"("status", "updatedAt" DESC);

-- CadreChangeRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_cadrechangerequest_status" ON "CadreChangeRequest"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_cadrechangerequest_employeeId" ON "CadreChangeRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_cadrechangerequest_updatedAt" ON "CadreChangeRequest"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_cadrechangerequest_status_updatedAt" ON "CadreChangeRequest"("status", "updatedAt" DESC);

-- RetirementRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_retirementrequest_status" ON "RetirementRequest"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_retirementrequest_employeeId" ON "RetirementRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_retirementrequest_updatedAt" ON "RetirementRequest"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_retirementrequest_status_updatedAt" ON "RetirementRequest"("status", "updatedAt" DESC);

-- ResignationRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_resignationrequest_status" ON "ResignationRequest"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_resignationrequest_employeeId" ON "ResignationRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_resignationrequest_updatedAt" ON "ResignationRequest"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_resignationrequest_status_updatedAt" ON "ResignationRequest"("status", "updatedAt" DESC);

-- ServiceExtensionRequest indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_serviceextensionrequest_status" ON "ServiceExtensionRequest"("status");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_serviceextensionrequest_employeeId" ON "ServiceExtensionRequest"("employeeId");
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_serviceextensionrequest_updatedAt" ON "ServiceExtensionRequest"("updatedAt" DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_serviceextensionrequest_status_updatedAt" ON "ServiceExtensionRequest"("status", "updatedAt" DESC);

-- User indexes for institution filtering
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_user_institutionId" ON "User"("institutionId");

-- Composite index for employee lookups by institution
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_institution_status" ON "Employee"("institutionId", "status");

-- Print completion message
\echo 'Dashboard performance indexes created successfully!'
\echo 'These indexes will significantly improve dashboard loading times.'
