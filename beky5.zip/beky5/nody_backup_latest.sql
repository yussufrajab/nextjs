--
-- PostgreSQL database dump
--

\restrict b6b3vFdpx91T6HN4VLpZiALs8Ws2rCMdYYIivgqrW1wCO7cOuUJ77DpaWuNBcRz

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: CadreChangeRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CadreChangeRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "newCadre" text NOT NULL,
    reason text,
    "studiedOutsideCountry" boolean,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CadreChangeRequest" OWNER TO postgres;

--
-- Name: Complaint; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Complaint" (
    id text NOT NULL,
    "complaintType" text NOT NULL,
    subject text NOT NULL,
    details text NOT NULL,
    "complainantPhoneNumber" text NOT NULL,
    "nextOfKinPhoneNumber" text NOT NULL,
    attachments text[],
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "officerComments" text,
    "internalNotes" text,
    "rejectionReason" text,
    "complainantId" text NOT NULL,
    "assignedOfficerRole" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Complaint" OWNER TO postgres;

--
-- Name: ConfirmationRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ConfirmationRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "decisionDate" timestamp(3) without time zone,
    "commissionDecisionDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ConfirmationRequest" OWNER TO postgres;

--
-- Name: Employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Employee" (
    id text NOT NULL,
    "employeeEntityId" text,
    name text NOT NULL,
    gender text NOT NULL,
    "profileImageUrl" text,
    "dateOfBirth" timestamp(3) without time zone,
    "placeOfBirth" text,
    region text,
    "countryOfBirth" text,
    "zanId" text NOT NULL,
    "phoneNumber" text,
    "contactAddress" text,
    "zssfNumber" text,
    "payrollNumber" text,
    cadre text,
    "salaryScale" text,
    ministry text,
    department text,
    "appointmentType" text,
    "contractType" text,
    "recentTitleDate" timestamp(3) without time zone,
    "currentReportingOffice" text,
    "currentWorkplace" text,
    "employmentDate" timestamp(3) without time zone,
    "confirmationDate" timestamp(3) without time zone,
    "retirementDate" timestamp(3) without time zone,
    status text,
    "ardhilHaliUrl" text,
    "confirmationLetterUrl" text,
    "jobContractUrl" text,
    "birthCertificateUrl" text,
    "institutionId" text NOT NULL
);


ALTER TABLE public."Employee" OWNER TO postgres;

--
-- Name: EmployeeCertificate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EmployeeCertificate" (
    id text NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    url text,
    "employeeId" text NOT NULL
);


ALTER TABLE public."EmployeeCertificate" OWNER TO postgres;

--
-- Name: Institution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Institution" (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    "phoneNumber" text,
    "voteNumber" text,
    "tinNumber" text
);


ALTER TABLE public."Institution" OWNER TO postgres;

--
-- Name: LwopRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LwopRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    duration text NOT NULL,
    reason text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "startDate" timestamp(3) without time zone
);


ALTER TABLE public."LwopRequest" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    message text NOT NULL,
    link text,
    "isRead" boolean DEFAULT false NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: PromotionRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PromotionRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "proposedCadre" text NOT NULL,
    "promotionType" text NOT NULL,
    "studiedOutsideCountry" boolean,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "commissionDecisionReason" text
);


ALTER TABLE public."PromotionRequest" OWNER TO postgres;

--
-- Name: ResignationRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ResignationRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "effectiveDate" timestamp(3) without time zone NOT NULL,
    reason text,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ResignationRequest" OWNER TO postgres;

--
-- Name: RetirementRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RetirementRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "retirementType" text NOT NULL,
    "illnessDescription" text,
    "proposedDate" timestamp(3) without time zone NOT NULL,
    "delayReason" text,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."RetirementRequest" OWNER TO postgres;

--
-- Name: SeparationRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SeparationRequest" (
    id text NOT NULL,
    type text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    reason text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SeparationRequest" OWNER TO postgres;

--
-- Name: ServiceExtensionRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceExtensionRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "currentRetirementDate" timestamp(3) without time zone NOT NULL,
    "requestedExtensionPeriod" text NOT NULL,
    justification text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceExtensionRequest" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "employeeId" text,
    "institutionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "phoneNumber" text,
    email text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: CadreChangeRequest CadreChangeRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_pkey" PRIMARY KEY (id);


--
-- Name: Complaint Complaint_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_pkey" PRIMARY KEY (id);


--
-- Name: ConfirmationRequest ConfirmationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_pkey" PRIMARY KEY (id);


--
-- Name: EmployeeCertificate EmployeeCertificate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeCertificate"
    ADD CONSTRAINT "EmployeeCertificate_pkey" PRIMARY KEY (id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (id);


--
-- Name: Institution Institution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Institution"
    ADD CONSTRAINT "Institution_pkey" PRIMARY KEY (id);


--
-- Name: LwopRequest LwopRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PromotionRequest PromotionRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_pkey" PRIMARY KEY (id);


--
-- Name: ResignationRequest ResignationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_pkey" PRIMARY KEY (id);


--
-- Name: RetirementRequest RetirementRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_pkey" PRIMARY KEY (id);


--
-- Name: SeparationRequest SeparationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_pkey" PRIMARY KEY (id);


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Employee_zanId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Employee_zanId_key" ON public."Employee" USING btree ("zanId");


--
-- Name: Institution_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Institution_name_key" ON public."Institution" USING btree (name);


--
-- Name: Institution_tinNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Institution_tinNumber_key" ON public."Institution" USING btree ("tinNumber");


--
-- Name: User_employeeId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_employeeId_key" ON public."User" USING btree ("employeeId");


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: idx_employee_institution_probation; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_institution_probation ON public."Employee" USING btree ("institutionId", status, "employmentDate") WHERE (status <> 'Confirmed'::text);


--
-- Name: idx_employee_institution_retirement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_institution_retirement ON public."Employee" USING btree ("institutionId", "retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: idx_employee_probation_overdue; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employee_probation_overdue ON public."Employee" USING btree (status, "employmentDate") WHERE (status <> 'Confirmed'::text);


--
-- Name: idx_employee_retirementDate; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_employee_retirementDate" ON public."Employee" USING btree ("retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: idx_employee_retirementDate_range; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_employee_retirementDate_range" ON public."Employee" USING btree ("retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: CadreChangeRequest CadreChangeRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CadreChangeRequest CadreChangeRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CadreChangeRequest CadreChangeRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Complaint Complaint_complainantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_complainantId_fkey" FOREIGN KEY ("complainantId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Complaint Complaint_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConfirmationRequest ConfirmationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConfirmationRequest ConfirmationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConfirmationRequest ConfirmationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmployeeCertificate EmployeeCertificate_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EmployeeCertificate"
    ADD CONSTRAINT "EmployeeCertificate_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Employee Employee_institutionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES public."Institution"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LwopRequest LwopRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LwopRequest LwopRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LwopRequest LwopRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PromotionRequest PromotionRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PromotionRequest PromotionRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PromotionRequest PromotionRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResignationRequest ResignationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResignationRequest ResignationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResignationRequest ResignationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RetirementRequest RetirementRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RetirementRequest RetirementRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RetirementRequest RetirementRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SeparationRequest SeparationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SeparationRequest SeparationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeparationRequest SeparationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: User User_institutionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES public."Institution"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict b6b3vFdpx91T6HN4VLpZiALs8Ws2rCMdYYIivgqrW1wCO7cOuUJ77DpaWuNBcRz

--
-- PostgreSQL database dump
--

\restrict wuaHYbh3S3LeOo3jU55EsnxYwnfB49cQKFAVe3xEV9rMKXEwIKW3EAlstvFjmkk

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: Institution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Institution" (id, name, email, "phoneNumber", "voteNumber", "tinNumber") FROM stdin;
cmd059ion0000e6d85kexfukl	TUME YA UTUMISHI SERIKALINI	info@zanajira.go.tz	0773101012	037	101817199
cmd06xe45000xe6bqb6qc19ys	MAMLAKA YA KUDHIBITI NA KUPAMBANA NA DAWA ZA KULEVYA ZANZIBAR	info@zdcea.go.tz	+255242233403	032	141776339
cmd06xe3w000te6bqc44b0xpr	MAMLAKA YA KUZUIA RUSHWA NA UHUJUMU WA UCHUMI ZANZIBAR	info@zaeca.go.tz	0774824242	035	122439755
cmd06nn7u0003e67wa4hiyie7	WIZARA YA AFYA	info@mohz.go.tz	+255242231614	008	101817180
cmd06xe3y000ue6bqzqkztrsa	WIZARA YA ARDHI NA MAENDELEO YA MAKAAZI ZANZIBAR	info@ardhismz.go.tz	0242941193	014	101697509
cmd06nn7r0002e67w8df8thtn	WIZARA YA ELIMU NA MAFUNZO YA AMALI	info@moez.go.tz	+255777458878	011	101817709
cme6s7yqe000m2bgx708j9uly	Tume ya kusimamia Nidhamu	\N	\N	\N	\N
cmd06xe3t000se6bqknluakbq	OFISI YA MUFTI MKUU WA ZANZIBAR	info@muftizanzibar.go.tz	0777483627	\N	\N
cmd06xe43000we6bqegt3ofa0	OFISI YA RAIS - IKULU	info@ikuluzanzibar.go.tz	+2252230814#5	567	\N
cmd06xe48000ye6bqwhlp0tum	TUME YA MAADILI YA VIONGOZI WA UMMA	info@ethicscommission.go.tz	+255242235535	113	136664387
cmd06xe4g0012e6bqou5f9gur	WIZARA YA MAJI NISHATI NA MADINI	info@majismz.go.tz	0242232695	15	150308305
cmd06xe40000ve6bqrip9e4m6	WIZARA YA UTALII NA MAMBO YA KALE	info@utaliismz.go.tz	0242231250	10	104480454
cmd4a32f22d9f78e3dec338	Wakala wa Matrekta	\N	\N	527	136148710
cmdca390e5b7e3c6f4ddbd4	Baraza la Jiji	\N	\N	201	141760874
cmde5633af0fb1bb7af7905	Skuli ya Sheria Zanzibar	\N	\N	570	154057374
cmd06xe2w000de6bqzqo9qu3m	TAASISI YA ELIMU ZANZIBAR	info@zie.go.tz	+255242230193	542	165130197
cmd06xe4b0010e6bqt54zkblq	AFISI YA MKURUGENZI WA MASHTAKA	dppznz@dppznz.go.tz	+255-24-2235564	029	107779272
cmd06xe4e0011e6bqv8eg0b16	AFISI YA MWANASHERIA MKUU	info@agcz.go.tz	0242232502	028	101817016
cmd06xe2o000ae6bquqbkbg4z	AFISI YA RAISI KAZI, UCHUMI NA UWEKEZAJI	info@arkuusmz.go.tz	0242230061	006	101697533
cmd1ff26c0c4e3e30140a6e	Hospitali ya Mnazi Mmoja	\N	\N	025	124546745
cmd06xe3n000pe6bquce6e6ga	TUME YA UCHAGUZI YA ZANZIBAR	info@zec.go.tz	242231489	031	106692653
cmd3c2909246966ab8bc819	Tume ya Mipango	\N	\N	024	121462354
cmd06xe2a0004e6bqwbtjm4x9	KAMISHENI YA UTUMISHI WA UMMA	kamisheni.utumishi@zpsc.go.tz	+255242230872	036	145869242
cmd06xe39000je6bqeouszvrd	OFISI YA MAKAMO WA KWANZA WA RAISI	info@omkr.go.tz	+255 242232475	002	115615637
cmd06xe2r000be6bqrqhwhbq1	KAMISHENI YA UTALII ZANZIBAR	info@zanzibartourism.go.tz	+255 24 2233485	\N	\N
cmd06xe3p000qe6bqwqcuyke1	OFISI YA MAKAMO WA PILI WA RAISI	info@ompr.go.tz	0242231826	003	101817601
cmd06xe2j0008e6bqqpmbs9bv	Ofisi ya Mhasibu Mkuu wa Serikali	info@mofzanzibar.go.tz	024776666	023	111658218
cmd06xe2e0006e6bqvjfhq32c	OFISI YA MKAGUZI MKUU WA NDANI WA SERIKALI	info@oiagsmz.go.tz	255743600320	052	156958174
cmd5f2656be26e643588334	Ofisi ya Mkuu wa Mkoa wa Kaskazini Pemba	\N	\N	051	119060877
cmd6c89e74df51ddc217c8c	Ofisi ya Mkuu wa Mkoa wa Kaskazini Unguja	\N	\N	048	107779450
cmd91d823ed52820fc6020f	Ofisi ya Mkuu wa Mkoa wa Kusini Pemba	\N	\N	050	119062888
cmd06xe220001e6bqj26tnlsj	Ofisi ya Mkuu wa Mkoa wa Kusini Unguja	info@southunguja.go.tz	0777433124	049	107779477
cmd06xe3g000me6bqh9gabe3e	OFISI YA RAIS, TAWALA ZA MIKOA, SERIKALI ZA MITAA NA IDARA MAALUMU ZA SMZ	info@tamisemim.go.tz	+255242230034	004	101732835
cmddc37c28c068eb077e082	Ofisi ya Mkuu wa Mkoa wa Mjini Magharibi Unguja	\N	\N	047	107779396
cmd06xe3i000ne6bq2q3y9g2z	OFISI YA RAIS - KATIBA SHERIA UTUMISHI NA UTAWALA BORA	info@utumishismz.go.tz	+255242230034	005	141811827
cmd06xe2m0009e6bq0ps9u9ut	TAASISI YA NYARAKA NA KUMBUKUMBU	info@ziar.go.tz	11111111111	057	165400550
cmd06xe3b000ke6bqxuwovzub	WIZARA YA BIASHARA NA MAENDELEO YA VIWANDA	info@tradesmz.go.tz	024-2941140	017	101789799
cmd06xe3l000oe6bq5drrocqt	WIZARA YA HABARI, VIJANA, UTAMADUNI NA MICHEZO	info@habarismz.go.tz	0242231202	018	137692902
cmd06xe34000he6bqfdqiw9ll	WIZARA YA KILIMO UMWAGILIAJI MALIASILI NA MIFUGO	ps@kilimoznz.go.tz	0777868306	012	101817679
cmd06xe270003e6bq0wm0v3c7	WIZARA YA MAENDELEO YA JAMII,JINSIA,WAZEE NA WATOTO	info@jamiismz.go.tz	+255242231413	019	157443895
cmd240bed02bab1eccc8039	Mamlaka ya Serikali Mtandao (eGAZ)	\N	\N	038	154803912
cmdd75324353437b4a24d98	Chuo cha Kiislamu	\N	\N	\N	\N
cmd6d9165d0597ad7596c4c	JKU	\N	\N	\N	\N
cmdb53ddd6c0a56b44ed006	Magereza	\N	\N	\N	\N
cmd233f6362082a7199509b	Baraza la Mji Kaskazini A Unguja	\N	\N	207	141799118
cmdfb652b1e5f9cc9589ae4	Baraza la Mji Kaskazini B Unguja	\N	\N	208	106226431
cmd25a57d5fa38437bac519	Ofisi ya Hatimiliki (COSOZA)	\N	\N	558	132175306
cmd06xe2h0007e6bqta680e3b	KAMISHENI YA ARDHI ZANZIBAR	info@kamisheniardhi.go.tz	0774776619	520	101816990
cmd06xe2y000ee6bqel875c2s	KAMISHENI YA KUKABILIANA NA MAAFA ZANZIBAR	zdmc@maafaznz.go.tz	+255242234755	510	119752302
cmd06xe1x0000e6bqalx28nja	Ofisi ya Msajili wa Hazina	info@trosmz.go.tz	111111111111	106	176281286
cmd06nn7n0001e67w2h5rf86x	OFISI YA RAIS, FEDHA NA MIPANGO	info@mofzanzibar.go.tz	+255 2477666664/5	567	\N
cmd06xe30000fe6bqe6ljiz1v	WAKALA WA MAJENGO ZANZIBAR	info@zba.go.tz	0242232695	522	137516160
cmd06xe250002e6bqp8aabk92	Wakala wa Vipimo Zanzibar	info@zawemasmz.go.tz	0778586654	519	157124463
cmd06xe3r000re6bqum8g62id	WIZARA YA UCHUMI WA BULUU NA UVUVI	info@blueeconomy.go.tz	242941195	13	150874084
cmd06xe37000ie6bq43r62ea6	WIZARA YA UJENZI MAWASILIANO NA UCHUKUZI	info@moic.go.tz	0242941138	16	101817156
cmd02cee2d68e90a9e93d12	Baraza la Mji Chake Chake	\N	\N	210	119062896
cmde5b940e9d54567bfc3a4	Baraza la Mji Wete	\N	\N	211	119065402
cmd77f48672584df7bbec35	Baraza la Mji Mkoani	\N	\N	209	119062756
cmdf0c43f7013ab7f2a66fb	Halmashauri ya Wilaya ya Micheweni	\N	\N	212	137833387
cmd536a0c15bebc592f98dc	Baraza la Mji Kati Unguja	\N	\N	205	134349867
cmdfdb6ca0e59fb2784253c	Halmashauri ya Wilaya ya Kusini Unguja	\N	\N	206	137926121
cmd59d412885295792e5a6f	Baraza la Manispaa Mjini Unguja	\N	\N	202	121454009
cmd4caf3852445c2568bc7c	Baraza la Manispaa Magharibi A	\N	\N	203	137175088
cmdbcf753dfb9d0ae18259a	Baraza la Manispaa Magharibi B	\N	\N	204	129840552
cmd4375abda3f14b3a95b77	Taasisi ya Utafiti wa Uvuvi (ZAFIRI)	\N	\N	526	140711764
cmd2be7aa7f5b3c47595cc4	Kamisheni ya Kazi	\N	\N	573	101817687
cmd4c5ec2ff8bee042f8320	Mamlaka ya Uwezeshaji Wananchi Kiuchumi (ZEA)	\N	\N	105	176332557
cmd1545dfaf1f7a12e14814	Baraza la Mitihani	\N	\N	547	124650941
cmdc44d2a81af54539661a3	Ofisi ya Mkaguzi wa Elimu	\N	\N	546	181476419
cmdb58cb33c0f5031c1db39	Bodi ya Huduma za Maktaba	\N	\N	543	114542164
cmd2376970b68ca8887a4fa	Wakala wa Barabara	\N	\N	559	151578152
cmdd32c25c06bcef1153da0	Tume ya Ushindani Halali wa Biashara	\N	\N	518	148444331
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, username, password, role, active, "employeeId", "institutionId", "createdAt", "updatedAt", "phoneNumber", email) FROM stdin;
cmecjzkmi00032bhu3ts6wi8y	Shaibu Nassor Juma	snjuma	$2a$10$6DRPqfw6bxMZ3Nmp84Y8IOURcSe1GLjApM5A24//FI2Y2Cqfcwnke	HRO	t	\N	cmd06xe2o000ae6bquqbkbg4z	2025-08-15 08:15:29.322	2025-08-15 08:15:29.322	0987654321	shaibu.juma@gmail.local
cmd06nn9p0005e67wgvz3pd6c	Amina Kassim	akassim	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	Admin	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.421	2025-08-03 03:39:26.051	\N	akassim@mock.local
cmd06nnb50007e67wa5491lw5	Zaituni Haji	zhaji	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	CSCS	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.473	2025-08-03 03:39:26.052	\N	zhaji@mock.local
cmd06nnbb000be67wwgil78yv	Fauzia Iddi	fiddi	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRMO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.479	2025-07-20 05:28:54.194	\N	fiddi@mock.local
cmd06nnbd000de67wb6e6ild5	Maimuna Ussi	mussi	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	DO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.482	2025-07-20 05:28:54.195	\N	mussi@mock.local
cmd06nnbg000fe67wdbus4imu	Mwanakombo Is-hak	mishak	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	PO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.484	2025-07-20 05:28:54.196	\N	mishak@mock.local
cmd06nnbi000he67wz9doivi6	Khamis Hamadi	khamadi	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRRP	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.487	2025-07-20 05:28:54.197	\N	khamadi@mock.local
cmd06nnbl000je67wtl28pk42	HRO (Tume)	hro_commission	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:49:21.489	2025-07-20 05:28:54.198	\N	hro_commission@mock.local
cmd06nnbn000le67wtg41s3su	Khamis Mnyonge	kmnyonge	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd06nn7n0001e67w2h5rf86x	2025-07-12 11:49:21.492	2025-07-20 05:28:54.199	\N	kmnyonge@mock.local
cmd06nnbq000ne67wwmiwxuo8	Ahmed Mohammed	ahmedm	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd06nn7r0002e67w8df8thtn	2025-07-12 11:49:21.494	2025-07-20 05:28:54.2	\N	ahmedm@mock.local
cmd06nnbs000pe67woh62ey8r	Mariam Juma	mariamj	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	HRO	t	\N	cmd06nn7u0003e67wa4hiyie7	2025-07-12 11:49:21.497	2025-07-20 05:28:54.202	\N	mariamj@mock.local
cmd059ir10002e6d86l802ljc	Safia Khamis	skhamis	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	HHRMD	t	\N	cmd059ion0000e6d85kexfukl	2025-07-12 11:10:22.766	2025-08-03 03:39:26.045	\N	skhamis@mock.local
admin-backend-id	System Administrator	admin	$2a$10$UcJJU0rS2PEzokX626tjgeDGRDgDp899RYtW94UOkq5.8frYzwl9S	ADMIN	t	\N	cmd059ion0000e6d85kexfukl	2025-07-20 22:03:33.497	2025-08-03 03:39:26.05	\N	admin@mock.local
user_1753044141852	Test User	testuser	defaultpassword	EMPLOYEE	t	\N	cmd059ion0000e6d85kexfukl	2025-07-20 23:42:21.853	2025-07-20 23:42:21.853	\N	testuser@mock.local
user_1753046780450	Test User Updated	4hhrmd	defaultpassword	HHRMD	f	\N	cmd059ion0000e6d85kexfukl	2025-07-21 00:26:20.451	2025-07-21 17:14:36.713	\N	4hhrmd@mock.local
cmd5a9ybb00012bt6m2oxl3li	Mwanasha Saleh Omar	mwanashasalehomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_004	cmd06nn7n0001e67w2h5rf86x	2025-07-16 01:29:31.895	2025-07-16 01:29:31.895	\N	mwanashasalehomar@mock.local
cmd5a9ybi00032bt60sbzycha	Zeinab Mohammed Ali	zeinabmohammedali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_006	cmd06nn7n0001e67w2h5rf86x	2025-07-16 01:29:31.902	2025-07-16 01:29:31.902	\N	zeinabmohammedali@mock.local
cmd5a9ybm00052bt65vf6eel7	Mwalimu Hassan Khamis	mwalimuhassankhamis	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_001	cmd06nn7n0001e67w2h5rf86x	2025-07-16 01:29:31.906	2025-07-16 01:29:31.906	\N	mwalimuhassankhamis@mock.local
cmd5a9ybq00072bt6fk4ixogc	Said Juma Nassor	saidjumanassor	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_003	cmd06nn7n0001e67w2h5rf86x	2025-07-16 01:29:31.911	2025-07-16 01:29:31.911	\N	saidjumanassor@mock.local
cmd5a9ybv00092bt6wp2ybul7	Ahmed Khamis Vuai	ahmedkhamisvuai	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_005	cmd06nn7n0001e67w2h5rf86x	2025-07-16 01:29:31.915	2025-07-16 01:29:31.915	\N	ahmedkhamisvuai@mock.local
cmd5a9ybz000b2bt6aslk4abk	Prof. Omar Juma Khamis	profomarjumakhamis	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_007	cmd06nn7r0002e67w8df8thtn	2025-07-16 01:29:31.919	2025-07-16 01:29:31.919	\N	profomarjumakhamis@mock.local
cmd5a9yc3000d2bt6ptv4b80p	Dr. Amina Hassan Said	draminahassansaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_008	cmd06nn7r0002e67w8df8thtn	2025-07-16 01:29:31.923	2025-07-16 01:29:31.923	\N	draminahassansaid@mock.local
cmd5a9yc7000f2bt6k3z7fpcx	Hamad Ali Khamis	hamadalikhamis	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_009	cmd06nn7r0002e67w8df8thtn	2025-07-16 01:29:31.927	2025-07-16 01:29:31.927	\N	hamadalikhamis@mock.local
cmd5a9ycb000h2bt6n20bjds6	Mwalimu Fatuma Juma	mwalimufatumajuma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_010	cmd06nn7r0002e67w8df8thtn	2025-07-16 01:29:31.931	2025-07-16 01:29:31.931	\N	mwalimufatumajuma@mock.local
cmd5a9yce000j2bt65eqmtcdp	Dr. Fatma Ali Mohamed	drfatmaalimohamed	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_002	cmd06nn7n0001e67w2h5rf86x	2025-07-16 01:29:31.934	2025-07-16 01:29:31.934	\N	drfatmaalimohamed@mock.local
cmd5a9yci000l2bt67nmav3dd	Halima Said Ali	halimasaidali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_012	cmd06nn7r0002e67w8df8thtn	2025-07-16 01:29:31.938	2025-07-16 01:29:31.938	\N	halimasaidali@mock.local
cmd5a9ycm000n2bt6xzmixcgp	Dr. Mwalimu Hassan Omar	drmwalimuhassanomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_013	cmd06nn7u0003e67wa4hiyie7	2025-07-16 01:29:31.942	2025-07-16 01:29:31.942	\N	drmwalimuhassanomar@mock.local
cmd5a9ycq000p2bt6x06ollw8	Dr. Khadija Ali Mohamed	drkhadijaalimohamed	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_014	cmd06nn7u0003e67wa4hiyie7	2025-07-16 01:29:31.946	2025-07-16 01:29:31.946	\N	drkhadijaalimohamed@mock.local
cmd5a9ycu000r2bt64139fgb0	Daktari Salim Juma Said	daktarisalimjumasaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_015	cmd06nn7u0003e67wa4hiyie7	2025-07-16 01:29:31.95	2025-07-16 01:29:31.95	\N	daktarisalimjumasaid@mock.local
cmd5a9ycy000t2bt64mu7gxpc	Nurse Mwanasha Hassan	nursemwanashahassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_016	cmd06nn7u0003e67wa4hiyie7	2025-07-16 01:29:31.954	2025-07-16 01:29:31.954	\N	nursemwanashahassan@mock.local
cmd5a9yd2000v2bt6ujmk31n9	Pharmacist Ahmed Ali	pharmacistahmedali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_017	cmd06nn7u0003e67wa4hiyie7	2025-07-16 01:29:31.958	2025-07-16 01:29:31.958	\N	pharmacistahmedali@mock.local
cmd5a9yd6000x2bt6mh8tqmsf	Fatma Khamis Omar	fatmakhamisomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_018	cmd06nn7u0003e67wa4hiyie7	2025-07-16 01:29:31.962	2025-07-16 01:29:31.962	\N	fatmakhamisomar@mock.local
cmd5a9ydb000z2bt6u03i5p63	Mhe. Ali Mohamed Khamis	mhealimohamedkhamis	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_019	cmd059ion0000e6d85kexfukl	2025-07-16 01:29:31.967	2025-07-16 01:29:31.967	\N	mhealimohamedkhamis@mock.local
cmd5a9ydh00112bt6x1qstl3w	Dr. Mwanajuma Said Ali	drmwanajumasaidali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_020	cmd059ion0000e6d85kexfukl	2025-07-16 01:29:31.973	2025-07-16 01:29:31.973	\N	drmwanajumasaidali@mock.local
cmd5a9ydl00132bt6dm40hcav	Mwalimu Hassan Juma	mwalimuhassanjuma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_021	cmd059ion0000e6d85kexfukl	2025-07-16 01:29:31.977	2025-07-16 01:29:31.977	\N	mwalimuhassanjuma@mock.local
cmd5a9ydp00152bt6q3ms10z1	Zeinab Ali Hassan	zeinabalihassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_022	cmd059ion0000e6d85kexfukl	2025-07-16 01:29:31.982	2025-07-16 01:29:31.982	\N	zeinabalihassan@mock.local
cmd5a9ydt00172bt6fptzcn58	Dr. Juma Ali Khamis	drjumaalikhamis	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_023	cmd06xe34000he6bqfdqiw9ll	2025-07-16 01:29:31.986	2025-07-16 01:29:31.986	\N	drjumaalikhamis@mock.local
cmd5a9ydx00192bt6orfmqpf7	Veterinarian Ahmed Hassan	veterinarianahmedhas	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_025	cmd06xe34000he6bqfdqiw9ll	2025-07-16 01:29:31.989	2025-07-16 01:29:31.989	\N	veterinarianahmedhas@mock.local
cmd5a9ye1001b2bt6hcr48oj2	Mwanasha Juma Omar	mwanashajumaomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_026	cmd06xe34000he6bqfdqiw9ll	2025-07-16 01:29:31.993	2025-07-16 01:29:31.993	\N	mwanashajumaomar@mock.local
cmd06nnbu000re67wdeax0fwp	Ali Juma Ali	alijuma	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	EMPLOYEE	t	emp1	cmd06nn7n0001e67w2h5rf86x	2025-07-12 11:49:21.499	2025-07-20 05:28:54.202	\N	alijuma@mock.local
cmd06nnbx000te67ww4cbaug7	Khadija Nassor	khadijanassor	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	EMPLOYEE	t	emp8	cmd06nn7r0002e67w8df8thtn	2025-07-12 11:49:21.501	2025-07-20 05:28:54.203	\N	khadijanassor@mock.local
cmd06nnbz000ve67wncnv4etg	Yussuf Makame	yussufmakame	$2a$10$TCRDCczcivs/N6gYCYeqmO66o7Z2kjeFKbHvCzR5vq8JaJS4vXbMe	EMPLOYEE	t	emp9	cmd06nn7r0002e67w8df8thtn	2025-07-12 11:49:21.504	2025-07-20 05:28:54.204	\N	yussufmakame@mock.local
cmd5a9ye6001d2bt6bccrik2i	Engineer Said Hassan	engineersaidhassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_027	cmd06xe37000ie6bq43r62ea6	2025-07-16 01:29:31.998	2025-07-16 01:29:31.998	\N	engineersaidhassan@mock.local
cmd5a9yea001f2bt6ga3t8xai	Engineer Amina Ali	engineeraminaali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_028	cmd06xe37000ie6bq43r62ea6	2025-07-16 01:29:32.002	2025-07-16 01:29:32.002	\N	engineeraminaali@mock.local
cmd5a9yee001h2bt6fubd8gt2	Architect Omar Juma	architectomarjuma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_029	cmd06xe37000ie6bq43r62ea6	2025-07-16 01:29:32.007	2025-07-16 01:29:32.007	\N	architectomarjuma@mock.local
cmd5a9yej001j2bt6fy0ff0ga	Surveyor Mwanajuma Hassan	surveyormwanajumahas	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_030	cmd06xe37000ie6bq43r62ea6	2025-07-16 01:29:32.011	2025-07-16 01:29:32.011	\N	surveyormwanajumahas@mock.local
cmd5a9yeo001l2bt6eqlxvvbs	Mwalimu Hassan Said	mwalimuhassansaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_031	cmd06xe40000ve6bqrip9e4m6	2025-07-16 01:29:32.016	2025-07-16 01:29:32.016	\N	mwalimuhassansaid@mock.local
cmd5a9yes001n2bt6pkv7c2ca	Dr. Fatma Juma Ali	drfatmajumaali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_032	cmd06xe40000ve6bqrip9e4m6	2025-07-16 01:29:32.02	2025-07-16 01:29:32.02	\N	drfatmajumaali@mock.local
cmd5a9yf0001r2bt6k5mfy0g1	Engineer Ali Hassan	engineeralihassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_034	cmd06xe4g0012e6bqou5f9gur	2025-07-16 01:29:32.029	2025-07-16 01:29:32.029	\N	engineeralihassan@mock.local
cmd5a9yf5001t2bt6wpo8k9av	Engineer Zeinab Omar	engineerzeinabomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_035	cmd06xe4g0012e6bqou5f9gur	2025-07-16 01:29:32.033	2025-07-16 01:29:32.033	\N	engineerzeinabomar@mock.local
cmd5a9yfa001v2bt6rudyi19t	Technician Said Ali	techniciansaidali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_036	cmd06xe4g0012e6bqou5f9gur	2025-07-16 01:29:32.038	2025-07-16 01:29:32.038	\N	techniciansaidali@mock.local
cmd5a9yfe001x2bt62nr23oeq	MBA Mwanasha Said	mbamwanashasaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_038	cmd06xe3b000ke6bqxuwovzub	2025-07-16 01:29:32.042	2025-07-16 01:29:32.042	\N	mbamwanashasaid@mock.local
cmd5a9yfj001z2bt6rs1wkh2g	Trade Officer Ahmed	tradeofficerahmed	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_039	cmd06xe3b000ke6bqxuwovzub	2025-07-16 01:29:32.047	2025-07-16 01:29:32.047	\N	tradeofficerahmed@mock.local
cmd5a9yfn00212bt6ng83u3h3	Surveyor Hassan Ali	surveyorhassanali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_040	cmd06xe3y000ue6bqzqkztrsa	2025-07-16 01:29:32.051	2025-07-16 01:29:32.051	\N	surveyorhassanali@mock.local
cmd5a9yfr00232bt6mr0d9gf4	Architect Fatma Hassan	architectfatmahassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_041	cmd06xe3y000ue6bqzqkztrsa	2025-07-16 01:29:32.055	2025-07-16 01:29:32.055	\N	architectfatmahassan@mock.local
cmd5a9yfw00252bt6j7ora5rb	Land Officer Omar Said	landofficeromarsaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_042	cmd06xe3y000ue6bqzqkztrsa	2025-07-16 01:29:32.06	2025-07-16 01:29:32.06	\N	landofficeromarsaid@mock.local
cmd5a9yg000272bt6osdb3yt9	Journalist Ali Omar	journalistaliomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_043	cmd06xe3l000oe6bq5drrocqt	2025-07-16 01:29:32.064	2025-07-16 01:29:32.064	\N	journalistaliomar@mock.local
cmd5a9yg500292bt6aelcn756	Dr. Mwanajuma Ali	drmwanajumaali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_044	cmd06xe3l000oe6bq5drrocqt	2025-07-16 01:29:32.069	2025-07-16 01:29:32.069	\N	drmwanajumaali@mock.local
cmd5a9yg9002b2bt6nfdb8rab	Sports Officer Hassan	sportsofficerhassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_045	cmd06xe3l000oe6bq5drrocqt	2025-07-16 01:29:32.073	2025-07-16 01:29:32.073	\N	sportsofficerhassan@mock.local
cmd5a9ygd002d2bt6d3vhx6z5	Marine Biologist Said	marinebiologistsaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_046	cmd06xe3r000re6bqum8g62id	2025-07-16 01:29:32.077	2025-07-16 01:29:32.077	\N	marinebiologistsaid@mock.local
cmd5a9ygh002f2bt6090rznm6	Dr. Amina Juma	draminajuma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_047	cmd06xe3r000re6bqum8g62id	2025-07-16 01:29:32.081	2025-07-16 01:29:32.081	\N	draminajuma@mock.local
cmd5a9ygk002h2bt6m9j9hq9r	Fisheries Officer Omar	fisheriesofficeromar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_048	cmd06xe3r000re6bqum8g62id	2025-07-16 01:29:32.085	2025-07-16 01:29:32.085	\N	fisheriesofficeromar@mock.local
cmd5a9ygp002j2bt6bs8rties	Social Worker Fatma	socialworkerfatma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_049	cmd06xe270003e6bq0wm0v3c7	2025-07-16 01:29:32.089	2025-07-16 01:29:32.089	\N	socialworkerfatma@mock.local
cmd5a9ygx002l2bt6a6x3t2a9	Child Protection Officer	childprotectionoffic	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_051	cmd06xe270003e6bq0wm0v3c7	2025-07-16 01:29:32.097	2025-07-16 01:29:32.097	\N	childprotectionoffic@mock.local
cmd5a9yh1002n2bt6zn3l6zz6	Auditor General Hassan	auditorgeneralhassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_052	cmd06xe2e0006e6bqvjfhq32c	2025-07-16 01:29:32.101	2025-07-16 01:29:32.101	\N	auditorgeneralhassan@mock.local
cmd5a9yh6002p2bt6nxjylqgb	Senior Auditor Amina	seniorauditoramina	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_053	cmd06xe2e0006e6bqvjfhq32c	2025-07-16 01:29:32.106	2025-07-16 01:29:32.106	\N	seniorauditoramina@mock.local
cmd5a9yhe002t2bt6yd4tij4y	Records Manager Fatma	recordsmanagerfatma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_055	cmd06xe2m0009e6bq0ps9u9ut	2025-07-16 01:29:32.114	2025-07-16 01:29:32.114	\N	recordsmanagerfatma@mock.local
cmd5a9yhj002v2bt65br99otf	CPA Amina Juma Hassan	cpaaminajumahassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_059	cmd06xe1x0000e6bqalx28nja	2025-07-16 01:29:32.119	2025-07-16 01:29:32.119	\N	cpaaminajumahassan@mock.local
cmd5a9yhn002x2bt6n0ao0lbl	Accountant Said Ali Khamis	accountantsaidalikha	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_060	cmd06xe1x0000e6bqalx28nja	2025-07-16 01:29:32.123	2025-07-16 01:29:32.123	\N	accountantsaidalikha@mock.local
cmd5a9yhs002z2bt6k3cobl2l	Auditor Mwanajuma Omar	auditormwanajumaomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_061	cmd06xe1x0000e6bqalx28nja	2025-07-16 01:29:32.128	2025-07-16 01:29:32.128	\N	auditormwanajumaomar@mock.local
cmd5a9yhw00312bt6nf4amgdl	Metrologist Dr. Hassan Ali	metrologistdrhassana	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_062	cmd06xe250002e6bqp8aabk92	2025-07-16 01:29:32.132	2025-07-16 01:29:32.132	\N	metrologistdrhassana@mock.local
cmd5a9yi100332bt62sgr5ysk	Engineer Fatma Said Omar	engineerfatmasaidoma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_063	cmd06xe250002e6bqp8aabk92	2025-07-16 01:29:32.138	2025-07-16 01:29:32.138	\N	engineerfatmasaidoma@mock.local
cmd5a9yi600352bt6okit1az6	Technician Ahmed Hassan	technicianahmedhassa	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_064	cmd06xe250002e6bqp8aabk92	2025-07-16 01:29:32.142	2025-07-16 01:29:32.142	\N	technicianahmedhassa@mock.local
cmd5a9yib00372bt677md29kl	Judge (Rtd) Ali Mohamed	judgertdalimohamed	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_065	cmd06xe2a0004e6bqwbtjm4x9	2025-07-16 01:29:32.147	2025-07-16 01:29:32.147	\N	judgertdalimohamed@mock.local
cmd5a9yif00392bt69sywfpzq	HR Specialist Juma Ali	hrspecialistjumaali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_067	cmd06xe2a0004e6bqwbtjm4x9	2025-07-16 01:29:32.151	2025-07-16 01:29:32.151	\N	hrspecialistjumaali@mock.local
cmd5a9yj0003j2bt6af8bv72y	Surveyor General Hassan	surveyorgeneralhassa	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_072	cmd06xe2h0007e6bqta680e3b	2025-07-16 01:29:32.172	2025-07-16 01:29:32.172	\N	surveyorgeneralhassa@mock.local
cmd5a9yj4003l2bt6hjjbsqas	Land Lawyer Dr. Mwanajuma	landlawyerdrmwanajum	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_073	cmd06xe2h0007e6bqta680e3b	2025-07-16 01:29:32.176	2025-07-16 01:29:32.176	\N	landlawyerdrmwanajum@mock.local
cmd5a9yj8003n2bt6j71cia6i	Cartographer Ahmed Said	cartographerahmedsai	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_074	cmd06xe2h0007e6bqta680e3b	2025-07-16 01:29:32.18	2025-07-16 01:29:32.18	\N	cartographerahmedsai@mock.local
cmd5a9yjd003p2bt6xo2yqbhj	CPA Dr. Ali Hassan Omar	cpadralihassanomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_075	cmd06xe2j0008e6bqqpmbs9bv	2025-07-16 01:29:32.185	2025-07-16 01:29:32.185	\N	cpadralihassanomar@mock.local
cmd5a9yjh003r2bt62irv8ozy	Budget Analyst Fatma Juma	budgetanalystfatmaju	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_076	cmd06xe2j0008e6bqqpmbs9bv	2025-07-16 01:29:32.189	2025-07-16 01:29:32.189	\N	budgetanalystfatmaju@mock.local
cmd5a9yjl003t2bt61d6gpj0t	Financial Controller Said	financialcontrollers	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_077	cmd06xe2j0008e6bqqpmbs9bv	2025-07-16 01:29:32.193	2025-07-16 01:29:32.193	\N	financialcontrollers@mock.local
cmd5a9yjp003v2bt66gi7gvf9	Chief Archivist Dr. Mwanajuma	chiefarchivistdrmwan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_078	cmd06xe2m0009e6bq0ps9u9ut	2025-07-16 01:29:32.197	2025-07-16 01:29:32.197	\N	chiefarchivistdrmwan@mock.local
cmd5a9yjt003x2bt65r1wy2u6	Librarian Amina Omar	librarianaminaomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_080	cmd06xe2m0009e6bq0ps9u9ut	2025-07-16 01:29:32.201	2025-07-16 01:29:32.201	\N	librarianaminaomar@mock.local
cmd5a9yjy003z2bt6pxcut0n9	Economist Dr. Omar Juma	economistdromarjuma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_081	cmd06xe2o000ae6bquqbkbg4z	2025-07-16 01:29:32.206	2025-07-16 01:29:32.206	\N	economistdromarjuma@mock.local
cmd5a9yk200412bt6vomd2ank	Investment Analyst Zeinab	investmentanalystzei	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_082	cmd06xe2o000ae6bquqbkbg4z	2025-07-16 01:29:32.21	2025-07-16 01:29:32.21	\N	investmentanalystzei@mock.local
cmd5a9yk700432bt6umm6zmtx	Statistics Officer Ahmed	statisticsofficerahm	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_083	cmd06xe2o000ae6bquqbkbg4z	2025-07-16 01:29:32.215	2025-07-16 01:29:32.215	\N	statisticsofficerahm@mock.local
cmd5a9ykb00452bt6jyy4e15l	Tourism Expert Dr. Hassan	tourismexpertdrhassa	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_084	cmd06xe2r000be6bqrqhwhbq1	2025-07-16 01:29:32.219	2025-07-16 01:29:32.219	\N	tourismexpertdrhassa@mock.local
cmd5a9ykg00472bt6tkq70vp4	Marketing Manager Fatma	marketingmanagerfatm	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_085	cmd06xe2r000be6bqrqhwhbq1	2025-07-16 01:29:32.224	2025-07-16 01:29:32.224	\N	marketingmanagerfatm@mock.local
cmd5a9ykl00492bt6xpeyen8g	Tour Guide Coordinator Said	tourguidecoordinator	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_086	cmd06xe2r000be6bqrqhwhbq1	2025-07-16 01:29:32.229	2025-07-16 01:29:32.229	\N	tourguidecoordinator@mock.local
cmd5a9yl3004h2bt62m3tadt5	Education Researcher Prof. Omar	educationresearcherp	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_090	cmd06xe2w000de6bqzqo9qu3m	2025-07-16 01:29:32.247	2025-07-16 01:29:32.247	\N	educationresearcherp@mock.local
cmd5a9yl7004j2bt6fl4b7ys6	Curriculum Developer Dr. Fatma	curriculumdeveloperd	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_091	cmd06xe2w000de6bqzqo9qu3m	2025-07-16 01:29:32.251	2025-07-16 01:29:32.251	\N	curriculumdeveloperd@mock.local
cmd5a9ylb004l2bt6w8j4u61o	Rashid Mohammed Omar	rashidmohammedomar	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_011	cmd06nn7r0002e67w8df8thtn	2025-07-16 01:29:32.256	2025-07-16 01:29:32.256	\N	rashidmohammedomar@mock.local
cmd5a9ylf004n2bt6uyvqo6or	Emergency Manager Dr. Said	emergencymanagerdrsa	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_093	cmd06xe2y000ee6bqel875c2s	2025-07-16 01:29:32.259	2025-07-16 01:29:32.259	\N	emergencymanagerdrsa@mock.local
cmd5a9ylj004p2bt6vurcjfmo	Risk Assessment Expert Zeinab	riskassessmentexpert	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_094	cmd06xe2y000ee6bqel875c2s	2025-07-16 01:29:32.263	2025-07-16 01:29:32.263	\N	riskassessmentexpert@mock.local
cmd5a9yln004r2bt6zelrp56z	Emergency Response Coordinator	emergencyresponsecoo	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_095	cmd06xe2y000ee6bqel875c2s	2025-07-16 01:29:32.267	2025-07-16 01:29:32.267	\N	emergencyresponsecoo@mock.local
cmd5a9ylr004t2bt6rweomswj	Construction Manager Eng. Ali	constructionmanagere	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_096	cmd06xe30000fe6bqe6ljiz1v	2025-07-16 01:29:32.271	2025-07-16 01:29:32.271	\N	constructionmanagere@mock.local
cmd5a9ylv004v2bt634q1clak	Quantity Surveyor Amina	quantitysurveyoramin	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_097	cmd06xe30000fe6bqe6ljiz1v	2025-07-16 01:29:32.276	2025-07-16 01:29:32.276	\N	quantitysurveyoramin@mock.local
cmd5a9ym0004x2bt63w4e2xxd	Site Supervisor Hassan	sitesupervisorhassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_098	cmd06xe30000fe6bqe6ljiz1v	2025-07-16 01:29:32.28	2025-07-16 01:29:32.28	\N	sitesupervisorhassan@mock.local
cmd5a9ym4004z2bt6ymck572i	Mhe. Dr. Seif Sharif Hamad	mhedrseifsharifhamad	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_099	cmd06xe220001e6bqj26tnlsj	2025-07-16 01:29:32.284	2025-07-16 01:29:32.284	\N	mhedrseifsharifhamad@mock.local
cmd5a9ym900512bt6xavf3l0b	Dkt. Mwalimu Fatma Khamis	dktmwalimufatmakhami	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_100	cmd06xe220001e6bqj26tnlsj	2025-07-16 01:29:32.289	2025-07-16 01:29:32.289	\N	dktmwalimufatmakhami@mock.local
cmd5a9ymd00532bt6zev4c6fl	Mwanakijiji Hassan Omar	mwanakijijihassanoma	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_101	cmd06xe220001e6bqj26tnlsj	2025-07-16 01:29:32.293	2025-07-16 01:29:32.293	\N	mwanakijijihassanoma@mock.local
cmd5a9ymi00552bt64xemdvls	Marine Conservation Expert Dr. Zeinab	marineconservationex	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_102	cmd06xe3r000re6bqum8g62id	2025-07-16 01:29:32.298	2025-07-16 01:29:32.298	\N	marineconservationex@mock.local
cmd5a9ymm00572bt6g8elg89t	Heritage Conservator Omar Ali Hassan	heritageconservatoro	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_103	cmd06xe40000ve6bqrip9e4m6	2025-07-16 01:29:32.302	2025-07-16 01:29:32.302	\N	heritageconservatoro@mock.local
cmd5a9ymq00592bt6dpde686w	Investigation Officer Zeinab Omar	investigationofficer	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_105	cmd06xe3w000te6bqc44b0xpr	2025-07-16 01:29:32.307	2025-07-16 01:29:32.307	\N	investigationofficer@mock.local
cmd5a9ymv005b2bt6pljdjia8	Forensic Accountant Said Ali	forensicaccountantsa	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_106	cmd06xe3w000te6bqc44b0xpr	2025-07-16 01:29:32.311	2025-07-16 01:29:32.311	\N	forensicaccountantsa@mock.local
cmd5a9ymz005d2bt6zyt8nosg	Chief Prosecutor Dr. Mwalimu Hassan	chiefprosecutordrmwa	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_107	cmd06xe4b0010e6bqt54zkblq	2025-07-16 01:29:32.315	2025-07-16 01:29:32.315	\N	chiefprosecutordrmwa@mock.local
cmd5a9yn3005f2bt6sr992pbu	State Attorney Amina Juma Ali	stateattorneyaminaju	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_108	cmd06xe4b0010e6bqt54zkblq	2025-07-16 01:29:32.319	2025-07-16 01:29:32.319	\N	stateattorneyaminaju@mock.local
cmd5a9yn8005h2bt6vgeek2ih	Legal Research Officer Omar Said	legalresearchofficer	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_109	cmd06xe4b0010e6bqt54zkblq	2025-07-16 01:29:32.324	2025-07-16 01:29:32.324	\N	legalresearchofficer@mock.local
cmd5a9ync005j2bt6og7oqk1p	Attorney General Prof. Fatma Hassan	attorneygeneralproff	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_110	cmd06xe4e0011e6bqv8eg0b16	2025-07-16 01:29:32.328	2025-07-16 01:29:32.328	\N	attorneygeneralproff@mock.local
cmd5a9yng005l2bt6twt3ibxr	Deputy Attorney General Dr. Ahmed Omar	deputyattorneygenera	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_111	cmd06xe4e0011e6bqv8eg0b16	2025-07-16 01:29:32.332	2025-07-16 01:29:32.332	\N	deputyattorneygenera@mock.local
cmd5a9ynk005n2bt6yizrd26z	Legal Advisor Mwanasha Ali	legaladvisormwanasha	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_112	cmd06xe4e0011e6bqv8eg0b16	2025-07-16 01:29:32.336	2025-07-16 01:29:32.336	\N	legaladvisormwanasha@mock.local
cmd5a9yno005p2bt6nbjlh99p	Drug Control Expert Dr. Hassan Ali Omar	drugcontrolexpertdrh	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_113	cmd06xe45000xe6bqb6qc19ys	2025-07-16 01:29:32.34	2025-07-16 01:29:32.34	\N	drugcontrolexpertdrh@mock.local
cmd5a9ynt005r2bt69ibyopcs	Narcotics Inspector Zeinab Hassan	narcoticsinspectorze	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_114	cmd06xe45000xe6bqb6qc19ys	2025-07-16 01:29:32.345	2025-07-16 01:29:32.345	\N	narcoticsinspectorze@mock.local
cmd5a9ynx005t2bt64bgse0qw	Rehabilitation Officer Ahmed Juma	rehabilitationoffice	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_115	cmd06xe45000xe6bqb6qc19ys	2025-07-16 01:29:32.349	2025-07-16 01:29:32.349	\N	rehabilitationoffice@mock.local
cmd5a9yo2005v2bt6580sd3cg	Legal Draftsman Omar Hassan Ali	legaldraftsmanomarha	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_117	cmd06xe3i000ne6bq2q3y9g2z	2025-07-16 01:29:32.354	2025-07-16 01:29:32.354	\N	legaldraftsmanomarha@mock.local
cmd5a9yo6005x2bt6h6lhugmk	Good Governance Officer Fatma Omar	goodgovernanceoffice	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_118	cmd06xe3i000ne6bq2q3y9g2z	2025-07-16 01:29:32.359	2025-07-16 01:29:32.359	\N	goodgovernanceoffice@mock.local
cmd5a9yob005z2bt6q0ie83g6	Ethics Expert Prof. Said Hassan	ethicsexpertprofsaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_119	cmd06xe48000ye6bqwhlp0tum	2025-07-16 01:29:32.363	2025-07-16 01:29:32.363	\N	ethicsexpertprofsaid@mock.local
cmd5a9yoh00612bt6eitx7vht	Ethics Officer Ahmed Hassan	ethicsofficerahmedha	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_121	cmd06xe48000ye6bqwhlp0tum	2025-07-16 01:29:32.37	2025-07-16 01:29:32.37	\N	ethicsofficerahmedha@mock.local
cmd5a9yom00632bt6gcmuup7r	Election Expert Dr. Hassan Omar	electionexpertdrhass	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_122	cmd06xe3n000pe6bquce6e6ga	2025-07-16 01:29:32.374	2025-07-16 01:29:32.374	\N	electionexpertdrhass@mock.local
cmd5a9yoq00652bt6cylh041i	Election Manager Amina Ali	electionmanageramina	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_123	cmd06xe3n000pe6bquce6e6ga	2025-07-16 01:29:32.378	2025-07-16 01:29:32.378	\N	electionmanageramina@mock.local
cmd5a9you00672bt6py6cy7y2	Voter Education Officer Omar Juma	votereducationoffice	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_124	cmd06xe3n000pe6bquce6e6ga	2025-07-16 01:29:32.382	2025-07-16 01:29:32.382	\N	votereducationoffice@mock.local
cmd5a9yoz00692bt629n1ebl8	Protocol Officer Dr. Fatma Ali	protocolofficerdrfat	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_125	cmd06xe43000we6bqegt3ofa0	2025-07-16 01:29:32.387	2025-07-16 01:29:32.387	\N	protocolofficerdrfat@mock.local
cmd5a9yp3006b2bt6stnq1q6z	Security Advisor Ahmed Hassan Omar	securityadvisorahmed	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_126	cmd06xe43000we6bqegt3ofa0	2025-07-16 01:29:32.391	2025-07-16 01:29:32.391	\N	securityadvisorahmed@mock.local
cmd5a9yp7006d2bt66ws4a1mb	Press Secretary Said Ali Hassan	presssecretarysaidal	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_127	cmd06xe43000we6bqegt3ofa0	2025-07-16 01:29:32.396	2025-07-16 01:29:32.396	\N	presssecretarysaidal@mock.local
cmd5a9ypc006f2bt6z3s9o2mo	Policy Advisor Dr. Zeinab Omar	policyadvisordrzeina	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_128	cmd06xe39000je6bqeouszvrd	2025-07-16 01:29:32.4	2025-07-16 01:29:32.4	\N	policyadvisordrzeina@mock.local
cmd5a9yph006h2bt6om91ing2	Program Coordinator Amina Hassan	programcoordinatoram	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_130	cmd06xe39000je6bqeouszvrd	2025-07-16 01:29:32.405	2025-07-16 01:29:32.405	\N	programcoordinatoram@mock.local
cmd5a9ypp006l2bt6fynxlfeu	Coordination Officer Dr. Fatma Said	coordinationofficerd	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_132	cmd06xe3p000qe6bqwqcuyke1	2025-07-16 01:29:32.413	2025-07-16 01:29:32.413	\N	coordinationofficerd@mock.local
cmd5a9ypu006n2bt6y8wmji0c	Administrative Officer Ahmed Ali	administrativeoffice	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_133	cmd06xe3p000qe6bqwqcuyke1	2025-07-16 01:29:32.418	2025-07-16 01:29:32.418	\N	administrativeoffice@mock.local
cmd5a9ypy006p2bt6hxhy7q0o	Islamic Scholar Dr. Hassan Juma Omar	islamicscholardrhass	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_134	cmd06xe3t000se6bqknluakbq	2025-07-16 01:29:32.422	2025-07-16 01:29:32.422	\N	islamicscholardrhass@mock.local
cmd5a9yq3006r2bt6prscw2yv	Islamic Education Officer Mwanajuma Hassan	islamiceducationoffi	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_135	cmd06xe3t000se6bqknluakbq	2025-07-16 01:29:32.427	2025-07-16 01:29:32.427	\N	islamiceducationoffi@mock.local
cmd5a9yq8006t2bt6ktirfj8k	Religious Affairs Officer Said Omar Ali	religiousaffairsoffi	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_136	cmd06xe3t000se6bqknluakbq	2025-07-16 01:29:32.432	2025-07-16 01:29:32.432	\N	religiousaffairsoffi@mock.local
cmd5a9yqc006v2bt66y8gd557	Regional Affairs Expert Prof. Dr. Amina Hassan	regionalaffairsexper	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_137	cmd06xe3g000me6bqh9gabe3e	2025-07-16 01:29:32.436	2025-07-16 01:29:32.436	\N	regionalaffairsexper@mock.local
cmd5a9yqg006x2bt6506f18ul	Local Government Specialist Dr. Omar Ali	localgovernmentspeci	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_138	cmd06xe3g000me6bqh9gabe3e	2025-07-16 01:29:32.44	2025-07-16 01:29:32.44	\N	localgovernmentspeci@mock.local
cmd5a9yqk006z2bt6qsw7m8na	Community Development Officer Dr. Fatma Juma Hassan	communitydevelopment	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_139	cmd06xe3g000me6bqh9gabe3e	2025-07-16 01:29:32.445	2025-07-16 01:29:32.445	\N	communitydevelopment@mock.local
cmd5a9yqp00712bt68t8h3w8r	Infrastructure Engineer Ahmed Said	infrastructureengine	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_140	cmd06xe37000ie6bq43r62ea6	2025-07-16 01:29:32.449	2025-07-16 01:29:32.449	\N	infrastructureengine@mock.local
cmd5a9yqt00732bt6ih1ifet3	Energy Expert Zeinab Omar Hassan	energyexpertzeinabom	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_142	cmd06xe4g0012e6bqou5f9gur	2025-07-16 01:29:32.453	2025-07-16 01:29:32.453	\N	energyexpertzeinabom@mock.local
cmd5a9yqy00752bt67ud7jt2z	Trade Promotion Officer Said Omar	tradepromotionoffice	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_143	cmd06xe3b000ke6bqxuwovzub	2025-07-16 01:29:32.458	2025-07-16 01:29:32.458	\N	tradepromotionoffice@mock.local
cmd5a9yr200772bt62y7uz79j	Youth Development Coordinator Dr. Amina Ali	youthdevelopmentcoor	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_144	cmd06xe3l000oe6bq5drrocqt	2025-07-16 01:29:32.463	2025-07-16 01:29:32.463	\N	youthdevelopmentcoor@mock.local
cmd5a9yr700792bt6z1irt2ig	Sports Development Officer Omar Hassan	sportsdevelopmentoff	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_145	cmd06xe3l000oe6bq5drrocqt	2025-07-16 01:29:32.467	2025-07-16 01:29:32.467	\N	sportsdevelopmentoff@mock.local
cmd5a9yrf007d2bt6mg8wax9d	Construction Project Manager Dr. Hassan Omar	constructionprojectm	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_147	cmd06xe30000fe6bqe6ljiz1v	2025-07-16 01:29:32.475	2025-07-16 01:29:32.475	\N	constructionprojectm@mock.local
cmd5a9yrj007f2bt65zdhsezr	Disaster Response Coordinator Amina Hassan	disasterresponsecoor	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_148	cmd06xe2y000ee6bqel875c2s	2025-07-16 01:29:32.479	2025-07-16 01:29:32.479	\N	disasterresponsecoor@mock.local
cmd5a9yro007h2bt6svip2kq6	Archive Specialist Ahmed Omar	archivespecialistahm	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_149	cmd06xe2m0009e6bq0ps9u9ut	2025-07-16 01:29:32.484	2025-07-16 01:29:32.484	\N	archivespecialistahm@mock.local
cmd5a9yrw007j2bt6jshonn46	Agronomist Fatma Said	agronomistfatmasaid	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_024	cmd06xe34000he6bqfdqiw9ll	2025-07-16 01:29:32.492	2025-07-16 01:29:32.492	\N	agronomistfatmasaid@mock.local
cmd5a9ys0007l2bt6qs1xahb4	Economist Juma Hassan	economistjumahassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_037	cmd06xe3b000ke6bqxuwovzub	2025-07-16 01:29:32.497	2025-07-16 01:29:32.497	\N	economistjumahassan@mock.local
cmd5a9ys5007n2bt6e28gdi7d	Gender Specialist Zeinab	genderspecialistzein	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_050	cmd06xe270003e6bq0wm0v3c7	2025-07-16 01:29:32.501	2025-07-16 01:29:32.501	\N	genderspecialistzein@mock.local
cmd5a9ys9007p2bt6hh5a6j4f	Dr. Lawyer Zeinab Hassan	drlawyerzeinabhassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_066	cmd06xe2a0004e6bqwbtjm4x9	2025-07-16 01:29:32.505	2025-07-16 01:29:32.505	\N	drlawyerzeinabhassan@mock.local
cmd5a9ysd007r2bt6tgb96c7j	Digital Archivist Hassan Ali	digitalarchivisthass	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_079	cmd06xe2m0009e6bq0ps9u9ut	2025-07-16 01:29:32.509	2025-07-16 01:29:32.509	\N	digitalarchivisthass@mock.local
cmd5a9ysi007t2bt625ilihqi	Teacher Trainer Hassan	teachertrainerhassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_092	cmd06xe2w000de6bqzqo9qu3m	2025-07-16 01:29:32.514	2025-07-16 01:29:32.514	\N	teachertrainerhassan@mock.local
cmd5a9ysn007v2bt65itm5qkb	Lawyer Dr. Ali Hassan Mohamed	lawyerdralihassanmoh	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_104	cmd06xe3w000te6bqc44b0xpr	2025-07-16 01:29:32.519	2025-07-16 01:29:32.519	\N	lawyerdralihassanmoh@mock.local
cmd5a9yss007x2bt6wnjij1uz	Constitutional Expert Dr. Amina Said	constitutionalexpert	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_116	cmd06xe3i000ne6bq2q3y9g2z	2025-07-16 01:29:32.524	2025-07-16 01:29:32.524	\N	constitutionalexpert@mock.local
cmd5a9ysx007z2bt68algn9gq	Development Specialist Hassan Ali Juma	developmentspecialis	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_129	cmd06xe39000je6bqeouszvrd	2025-07-16 01:29:32.529	2025-07-16 01:29:32.529	\N	developmentspecialis@mock.local
cmd5a9yt200812bt6pbqfayyh	Agricultural Specialist Dr. Hassan Ali	agriculturalspeciali	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_141	cmd06xe34000he6bqfdqiw9ll	2025-07-16 01:29:32.534	2025-07-16 01:29:32.534	\N	agriculturalspeciali@mock.local
cmd5a9yew001p2bt6hcn7qujs	Ahmed Omar Hassan	ahmedomarhassan	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_033	cmd06xe40000ve6bqrip9e4m6	2025-07-16 01:29:32.024	2025-07-21 17:51:19.505	\N	ahmedomarhassan@mock.local
cmd5a9ypl006j2bt6nxnq6nwn	Administration Expert Engineer Omar Hassan	administrationexpert	$2a$10$UeCqePP2DQPDQkpwhOjH5uj0/BWa0Ol6dEIBa1qdzcU.bimYPapu6	EMPLOYEE	t	emp_131	cmd06xe3p000qe6bqwqcuyke1	2025-07-16 01:29:32.409	2025-07-21 17:51:34.941	\N	administrationexpert@mock.local
cme471pqo00032bidhttxmboj	Yassir Haji Zubeir	yhzubeir	$2a$10$RC7M40AM.F/rT7lD/0gfEu3Vobdi1kNcJFwa8WwbyboVe5twn39X2	HRO	t	\N	cmd06nn7u0003e67wa4hiyie7	2025-08-09 11:51:04.847	2025-08-09 11:53:40.935	\N	yhzubeir@mock.local
cme56ma17000x2btjnpvgr0kg	Yussuf Mzee Rajab	ymrajab	$2a$10$d7GxHTx8ZGjqYAmyhWtk8ezoC./BjFDAweFQ86NecSyhfJMJCD7Cm	Admin	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:26:50.826	2025-08-10 04:26:50.826	\N	ymrajab@mock.local
cme57api100042bcqhbkg91r8	sophy majaribio	safiatest	$2a$10$358txTTZ/4JutwHfTxbT1./z0yFTqbkCoCUMtaDWXMsI0BSz5irG6	HHRMD	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:45:50.616	2025-08-10 04:45:50.616	\N	safiatest@mock.local
cme57bm9600062bcqtlkj9wcx	Maimuna Majaribio	maitest	$2a$10$logSYVyjw8nccvm12H72huhbLpQ89UWgmyfeVvjIpscRo.hPp9ACa	DO	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:46:33.066	2025-08-10 04:46:33.066	\N	maitest@mock.local
cme57cciu00082bcqnbw9sjm9	Fauzia Majaribo	fautest	$2a$10$Hw29S3kizuE1Sl205UtwouNarFkFqybH28HfXwbMFtQbJ4SHpMxhu	HRMO	t	\N	cmd059ion0000e6d85kexfukl	2025-08-10 04:47:07.075	2025-08-10 04:47:07.075	\N	fautest@mock.local
cme6sts42000o2bgxfjax08co	Abdalla Juma Abdalla	ajabdalla	$2a$10$c25cE7dGWhdP9xsO7o04mueaGkwgb2adEeelffsH55QILrKArmQn.	HRO	t	\N	cme6s7yqe000m2bgx708j9uly	2025-08-11 07:36:18.578	2025-08-11 07:36:18.578	0987654321	ajabdalla@mock.local
d7e938ff-71f8-41fd-b954-cd840855049a	Fauzia Makame	fmakame	$2a$10$ZYQIoqjVPOQMnk6.ORYPgeKFIGrNl9azMJiRohFULi.paNIcV1FbW	HRO	t	\N	cmd1545dfaf1f7a12e14814	2025-12-04 06:55:24.24	2025-12-04 06:55:24.238	0774564624	fmakame@bmz.go.tz
emp_9298ec5cbab08d539af662de255c8203	Mwinyi Ramadhan Mwinyi	mwinyiramadhanmwinyi	$2a$10$Kd2dANf3lNG1ZHOKWYDAZOIKpUmL1wQAcgq0puQG1YbeyfgR0N/3q	EMPLOYEE	t	31980760-c244-454d-9aff-3cd34ff18b4a	cmd06nn7u0003e67wa4hiyie7	2025-11-27 02:53:00.028	2025-11-27 02:53:00.026	\N	\N
emp_2f17035e7b67f92a5a73a2e5550ba1d1	Habiba Abdalla Mohammed	habibaabdallamohammed	$2a$10$m2b848rOYG2xAY3W2iEazO3wQPNm5K/MBC1ebX2LHnEVAw7xiBKBm	EMPLOYEE	t	a7623c27-c0b6-4578-8944-e24abf73e9a6	cmd06nn7u0003e67wa4hiyie7	2025-11-27 02:55:28.707	2025-11-27 02:55:28.706	\N	\N
emp_4c64e6f5598bd32dedbe504a2605ed93	Arafa Abbass Issa	arafaabbassissa	$2a$10$aVKutkB5b547CvhGdmIMtuPVsXFGF00WinISYp4V7/sbpX04h397.	EMPLOYEE	t	0f37cf84-b64e-4159-a341-6c4d0a78213b	cmd06nn7u0003e67wa4hiyie7	2025-11-27 17:04:52.255	2025-11-27 17:04:52.254	\N	\N
42635a13-283a-48eb-9752-752bbda196b9	Mwanaidi sallum	msalum	$2a$10$kigZun7lIgIX1lrMQID8l.s.1KAjGf41cNs8rtEQlE5NLO5Ralpmu	HRO	t	\N	cmd06xe4e0011e6bqv8eg0b16	2025-12-03 12:19:39.904	2025-12-03 12:19:39.903	0777626242	msalum@sheria.go.tz
f965a775-0572-4469-aab3-ad1d0f7e2032	Harith Abdalla	habdalla	$2a$10$TBCJXfqag57hlPK4361t/.AOo145q6STuNQWQqXcXZ0MoR1RZMEwq	HRO	t	\N	cmd06xe2h0007e6bqta680e3b	2025-12-03 12:40:57.681	2025-12-03 12:40:57.679	0776346383	habadalla@ardhi.go.tz
7011a404-7ebc-4c2d-96dd-807a073b5911	Lela Kassim Ali	lkali	$2a$10$EVAP8ZlNSPTzHFDkscKcUONwMpUL1LgAZ/iw.r.Gy3J8KEzJl.wte	HRO	t	\N	cmd06xe34000he6bqfdqiw9ll	2025-12-03 12:54:02.473	2025-12-03 12:54:02.471	0776382949	lkali@kilimo.go.tz
33e358d2-1820-415d-abab-3213926e2096	Salma Ali	sali	$2a$10$n4UqZKZ8zlmdxP4Ln6HrkuSR8iPvKtVoOf/TGXFVePFbYaKvH3AKO	HRO	t	\N	cmd06xe2e0006e6bqvjfhq32c	2025-12-03 14:28:56.149	2025-12-03 14:28:56.147	0773527322	sali@mkaguzi.go.tz
5382cf01-9b4e-4dbc-833b-ec88a02e49b4	zulfa shariff	zshariff	$2a$10$9Cs06omqcc6Oq1VFIjYJyuTTU67QcSgFSf4m7bLi/HF2hxl72ZhoK	HRO	t	\N	cmd06xe2j0008e6bqqpmbs9bv	2025-12-03 16:12:18.826	2025-12-03 16:12:18.824	0774234826	zshariff@mhasibu.go.tz
69b8c30e-ffab-466c-8c86-6e6d1c1ff4ee	Shuwekha Kassim Awesu	skawesu	$2a$10$Hu0jlanL97PA0/5UaDQMaOv4bBm7.tUmhVvZvqjkGD8LzgDeSB0Ey	HRO	t	\N	cmd059ion0000e6d85kexfukl	2025-12-04 07:11:04.075	2025-12-04 07:11:04.073	0775462416	skawesu@tus.go.tz
\.


--
-- Data for Name: CadreChangeRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CadreChangeRequest" (id, status, "reviewStage", "newCadre", reason, "studiedOutsideCountry", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
cmd08nei5001de6qk339xyxa5	UNDER_REVIEW	FINAL_APPROVAL	Administrative Officer	Department reorganization	f	{https://placehold.co/cadre-change-application.pdf,https://placehold.co/qualifications.pdf}	\N	emp9	cmd06nnbz000ve67wncnv4etg	\N	2025-05-01 12:45:09.293	2025-07-12 12:45:09.293
cmd08nei8001fe6qkx8hdjhoh	REJECTED	DIRECTOR_REVIEW	Education Officer	Professional development	t	{https://placehold.co/cadre-change-application.pdf,https://placehold.co/qualifications.pdf}	Insufficient qualifications for requested cadre	emp8	cmd06nnbx000te67ww4cbaug7	cmd06nnbq000ne67wwmiwxuo8	2025-04-26 12:45:09.296	2025-06-29 12:45:09.296
cmd08neia001he6qkgh2tplbv	APPROVED	HR_REVIEW	Senior Administrative Officer	Career advancement	f	{https://placehold.co/cadre-change-application.pdf,https://placehold.co/qualifications.pdf}	\N	emp9	cmd06nnbx000te67ww4cbaug7	cmd06nnbl000je67wtl28pk42	2025-04-06 12:45:09.298	2025-06-17 12:45:09.298
cmd08neic001je6qkomon6imt	APPROVED	COMMISSION_REVIEW	Senior Education Officer	Skills alignment	t	{https://placehold.co/cadre-change-application.pdf,https://placehold.co/qualifications.pdf}	\N	emp9	cmd06nnbz000ve67wncnv4etg	\N	2025-03-30 12:45:09.3	2025-06-16 12:45:09.3
cmd08neie001le6qkxgss8taj	UNDER_REVIEW	FINAL_APPROVAL	Education Officer	Career advancement	t	{https://placehold.co/cadre-change-application.pdf,https://placehold.co/qualifications.pdf}	\N	emp1	cmd06nnbx000te67ww4cbaug7	cmd06nnbq000ne67wwmiwxuo8	2025-03-27 12:45:09.302	2025-06-19 12:45:09.302
cmd1kypbu0001e6gc7v2yod78	Pending HRMO Review	initial	Afisa Mkuu Daraja la III	kuna uhitaji katika taasisi yetu	f	{"Letter of Request",Certificate}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 11:17:38.106	2025-07-13 11:17:38.106
cmd1let7s0003e6gciwpw9wci	Pending HRMO Review	initial	Afisa Muandamizi Daraja la III	kuna uhitaji mkubwa awa kada hiyo	f	{"Letter of Request",Certificate}	\N	emp_006	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 11:30:09.64	2025-07-13 11:30:09.64
cmd4cgkw50003e6tcho3qmk5z	Approved by Commission	completed	Afisa Mkuu Daraja la III	kuna uhitaji wa kada hii	t	{"Letter of Request",Certificate,"TCU Form"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-15 09:42:54.149	2025-07-15 09:52:42.164
cmd8ff1ij001v2bgt7gt9uriy	Rejected by HRMO - Awaiting HRO Correction	initial	Afisa Sheria	Amesoma kada ya Sheria	f	{"Letter of Request",Certificate}	kada anayoombewa sio sahihi kwa m ujibu wa muundo	emp_020	cmd06nnbl000je67wtl28pk42	cmd06nnbb000be67wwgil78yv	2025-07-18 06:16:45.931	2025-07-18 07:13:04.032
cmd8g3r1e001z2bgtrs7sw3pb	Rejected by Commission	completed	Afisa Rasilimali watu	Kuongeza Elimu	f	{"Letter of Request",Certificate}	\N	emp_003	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-18 06:35:58.754	2025-07-18 07:29:59.393
cmd8fguow001x2bgtsbqxtl0i	Approved by Commission	completed	Afisa Ushauri nasaha	ana uzoefu wa kazi hii	f	{"Letter of Request",Certificate}	\N	emp_022	cmd06nnbl000je67wtl28pk42	cmd06nnbb000be67wwgil78yv	2025-07-18 06:18:10.399	2025-07-18 07:30:23.409
cmd1n5ay70001e6m4psaifpsy	Request Received – Awaiting Commission Decision	commission_review	Afisa Mkuu Msaidizi	kuna uhitaji	f	{"Letter of Request",Certificate}	\N	emp_004	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-13 12:18:45.295	2025-07-19 11:43:34.154
cmddezsds000fe67keau7xecg	Pending HRMO/HHRMD Review	initial	Mkurugenzi Fedha	kuna uhitaji	f	{"Letter of Request",Certificate}	\N	ofisi_emp_002	cmd06nnbn000le67wtg41s3su	\N	2025-07-21 18:03:45.101	2025-07-21 18:03:45.101
cmdgpzshb0003e6lwjr42jude	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Daraja la III	sawa	f	{"Letter of Request",Certificate}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 01:34:59.567	2025-07-24 01:34:59.567
cmdgyhlfk0003e6xo8eoongn9	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Daraja la III	asad	f	{"Letter of Request",Certificate}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 05:32:47.168	2025-07-24 05:32:47.168
cmdh1h5n60001e6l82wqx1ixc	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Msaidizi	sawa	f	{"Letter of Request",Certificate}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 06:56:25.554	2025-07-24 06:56:25.554
cmdh5yb690003e6l8fgy3hiww	Pending HRMO/HHRMD Review	initial	Mkurugenzi Fedha	sawa	f	{cadre-change/20250724_120140_77c69689.pdf,cadre-change/20250724_120117_b0bd4df8.pdf}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 09:01:44.337	2025-07-24 09:01:44.337
cmdhlyo9w0005e6l8e9fwu1mv	Pending HRMO/HHRMD Review	initial	Afisa Muandamizi Daraja la III	uko	f	{cadre-change/20250724_192949_05acec6d.pdf,cadre-change/20250724_192940_0b9845dd.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 16:29:55.172	2025-07-24 16:29:55.172
cmdhnxtz10001e65kllyx7hls	Pending HRMO/HHRMD Review	initial	Afisa Muandamizi Daraja la III	ok	f	{cadre-change/20250724_202508_04e771ff.pdf,cadre-change/20250724_202502_21fe0473.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 17:25:15.133	2025-07-24 17:25:15.133
cmdhpvde10005e65khs2oa9eh	Pending HRMO/HHRMD Review	initial	Afisa Muandamizi Daraja la III	saws	t	{cadre-change/20250724_211841_06cb2016.pdf,cadre-change/20250724_211826_e8400882.pdf,cadre-change/20250724_211832_cba57e7a.pdf}	\N	emp_004	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 18:19:19.561	2025-07-24 18:19:19.561
cmdhq3c2a0007e65khcj3tsel	Pending HRMO/HHRMD Review	initial	Mkurugenzi Fedha	sawa	f	{cadre-change/20250724_212523_a08541c4.pdf,cadre-change/20250724_212519_f1a65b2d.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 18:25:31.09	2025-07-24 18:25:31.09
cmdhr2db40009e65koqoagmov	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Daraja la III	sawaa	f	{cadre-change/20250724_215243_a5387445.pdf,cadre-change/20250724_215239_bcef3d4f.pdf}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 18:52:45.665	2025-07-24 18:52:45.665
cmdiej2sm0009e6rw7f5klo4v	Pending HRMO/HHRMD Review	initial	Mkurugenzi Fedha	sae	f	{cadre-change/20250725_084929_c76d1a21.pdf,cadre-change/20250725_084925_df88587b.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 05:49:36.357	2025-07-25 05:49:36.357
cmdiekyka000be6rw50hjw9nn	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Daraja la III	fgffdz	f	{cadre-change/20250725_085101_a60b988b.pdf,cadre-change/20250725_085057_9ada7b57.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 05:51:04.186	2025-07-25 05:51:04.186
cmdiu4kuw000fe6z0voji1fo7	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Daraja la III	ddf dfdsfdf	f	{cadre-change/20250725_160611_81b8b571.pdf,cadre-change/20250725_160605_2ed71ba1.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 13:06:13.784	2025-07-25 13:06:13.784
cmdye0kuj00092b41kmfbhlh7	Rejected by Commission - Request Concluded	completed	Afisa Sera na utafiti	kuna uhitaji	t	{cadre-change/1754389280345_ytqs0o_ripoti_ya_likizo_bila_malipo_report.pdf,cadre-change/1754389273559_sw9j83_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf,cadre-change/1754389276033_twmjuj_ripoti_ya_likizo_bila_malipo_report.pdf}	\N	ofisi_emp_006	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-08-05 10:19:32.108	2025-08-05 10:22:09.334
cmdye5x6y000b2b41ebhw25xi	Approved by Commission	completed	Afisa Sera	elimu	f	{cadre-change/1754389415435_kl8d9w_1754384852415_9af7qo_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf,cadre-change/1754389414382_m3vk3q_ya_kuacha_kazi_report.pdf}	\N	ofisi_emp_006	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 10:23:41.385	2025-08-05 10:24:23.231
cmdytwwym00052b7kxmkjav8s	Pending HRMO/HHRMD Review	initial	Mkurugenzi Fedha	kuna uhitaji	f	{cadre-change/1754415867992_zfj0wb_mfano.pdf,cadre-change/1754415863489_0zq8y5_Employee_Profile_Analysis.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-08-05 17:44:35.039	2025-08-05 17:44:35.039
cmdztvkh700012bl1x6btjdbq	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Daraja la III	kuna uhitaji	f	{cadre-change/1754476276442_45v9jg_Employee_Profile_Analysis.pdf,cadre-change/1754476270993_w4w3xb_cheti.pdf}	\N	ofisi_emp_002	cmd06nnbn000le67wtg41s3su	\N	2025-08-06 10:31:18.379	2025-08-06 10:31:18.379
cme4jwedg000n2btj1wv22elu	Approved by Commission	completed	Afisa Muandamizi Daraja la III	kuna uhitaji	f	{cadre-change/1754761847439_3dirvq_1754324616644_6r2ulr_cheti.pdf,cadre-change/1754761842809_l4grgk_mfano.pdf}	\N	cme45oe31000l2bfw2kzug3tj	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-09 17:50:51.844	2025-08-10 13:09:08.696
f409d31f-e097-49a2-bfe4-2ff10ca7900e	Pending HRMO/HHRMD Review	initial	Afisa Afya daraja la II	Kuna uhitaji	f	{cadre-change/1764180781395_ogz6v5_ripoti_ya_kupandishwa_cheo_report.pdf,cadre-change/1764180776494_zxp9ad_receipt_7FY81767J96865132.pdf}	\N	1abb6d7d-3816-421c-ac6e-48ccf04bf66e	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:13:03.513	2025-11-26 18:13:03.512
b1bfb461-7825-43e4-a34a-29df6c22b701	Pending HRMO/HHRMD Review	initial	Afisa Afya daraja la II	kuna uhitaji	f	{cadre-change/1764181322998_mr0ji9_1754676807327_mfbgv3_ripoti_ya_kupandishwa_cheo_report__2_.pdf,cadre-change/1764181317106_7cxwlp_ripoti_ya_kustaafu_kwa_hiari_report.pdf}	\N	2d159f48-cd89-4f23-aaf2-c8328d1240ee	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:22:07.582	2025-11-26 18:22:07.581
11639dd7-7ccd-43d8-8474-8643b6c47f34	Pending HRMO/HHRMD Review	initial	Daktari daraja la II	kuna uhitaji	f	{cadre-change/1764181516155_l28txr_1754676807327_mfbgv3_ripoti_ya_kupandishwa_cheo_report__2_.pdf,cadre-change/1764181509202_ruha0o_ripoti_ya_kupandishwa_cheo_report.pdf}	\N	cme45oe3h000t2bfw72unecxi	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:25:22.15	2025-11-26 18:25:22.149
dcc82507-f533-4ee7-8999-5019e11718ee	Pending HRMO/HHRMD Review	initial	Afisa Utendaji wa Afya daraja la II	kuna uhitaji	f	{cadre-change/1764181823474_07756c_ripoti_ya_nyongeza_ya_utumishi_report.pdf,cadre-change/1764181818093_ubmiol_ripoti_ya_kupandishwa_cheo_report.pdf}	\N	cme45oe2m000d2bfwd3agas2u	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:30:27.262	2025-11-26 18:30:27.26
\.


--
-- Data for Name: Complaint; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Complaint" (id, "complaintType", subject, details, "complainantPhoneNumber", "nextOfKinPhoneNumber", attachments, status, "reviewStage", "officerComments", "internalNotes", "rejectionReason", "complainantId", "assignedOfficerRole", "reviewedById", "createdAt", "updatedAt") FROM stdin;
cmd08nejb002be6qkujkym70h	Discrimination	Formal complaint regarding unfair treatment	This is a detailed description of the complaint. The complainant has experienced issues related to discrimination and is seeking appropriate action and resolution. The incident occurred during regular working hours and has affected the complainant's work environment and productivity.	0777-123009	0778-542236	{https://placehold.co/complaint-evidence.pdf,https://placehold.co/witness-statement.pdf}	REJECTED	INITIAL	\N	\N	Insufficient evidence to proceed with investigation	cmd06nnbu000re67wdeax0fwp	HHRMD	\N	2025-04-15 12:45:09.335	2025-06-25 12:45:09.335
cmd08neje002de6qkxls1avnb	Discrimination	Formal complaint regarding workplace harassment	This is a detailed description of the complaint. The complainant has experienced issues related to discrimination and is seeking appropriate action and resolution. The incident occurred during regular working hours and has affected the complainant's work environment and productivity.	0777-447638	0778-440913	{https://placehold.co/complaint-evidence.pdf,https://placehold.co/witness-statement.pdf}	REJECTED	INITIAL	\N	\N	Insufficient evidence to proceed with investigation	cmd06nnbz000ve67wncnv4etg	HRO	\N	2025-04-10 12:45:09.337	2025-07-06 12:45:09.337
cmd08nejg002fe6qk4oeqxes0	Service delivery	Formal complaint regarding policy violation	This is a detailed description of the complaint. The complainant has experienced issues related to unfair treatment and is seeking appropriate action and resolution. The incident occurred during regular working hours and has affected the complainant's work environment and productivity.	0777-914298	0778-993027	{https://placehold.co/complaint-evidence.pdf,https://placehold.co/witness-statement.pdf}	PENDING	HR_REVIEW	Initial review completed. Further investigation required.	Case assigned to investigating officer. Priority: Medium	\N	cmd06nnbu000re67wdeax0fwp	DO	cmd059ir10002e6d86l802ljc	2025-05-22 12:45:09.339	2025-06-24 12:45:09.339
cmd08neji002he6qk9n7hlyxz	Discrimination	Formal complaint regarding unfair treatment	This is a detailed description of the complaint. The complainant has experienced issues related to workplace harassment and is seeking appropriate action and resolution. The incident occurred during regular working hours and has affected the complainant's work environment and productivity.	0777-276616	0778-891037	{https://placehold.co/complaint-evidence.pdf,https://placehold.co/witness-statement.pdf}	PENDING	HR_REVIEW	Initial review completed. Further investigation required.	Case assigned to investigating officer. Priority: Medium	\N	cmd06nnbz000ve67wncnv4etg	HRO	cmd059ir10002e6d86l802ljc	2025-04-19 12:45:09.341	2025-07-12 12:45:09.341
cmd08nejk002je6qk8iqc25p7	Policy violation	Formal complaint regarding service delivery	This is a detailed description of the complaint. The complainant has experienced issues related to unfair treatment and is seeking appropriate action and resolution. The incident occurred during regular working hours and has affected the complainant's work environment and productivity.	0777-344690	0778-919508	{https://placehold.co/complaint-evidence.pdf,https://placehold.co/witness-statement.pdf}	REJECTED	INITIAL	Initial review completed. Further investigation required.	Case assigned to investigating officer. Priority: Medium	Insufficient evidence to proceed with investigation	cmd06nnbx000te67ww4cbaug7	HRO	cmd06nnbl000je67wtl28pk42	2025-05-20 12:45:09.343	2025-07-07 12:45:09.343
cmd08nejm002le6qkwxipk10f	Service delivery	Formal complaint regarding service delivery	This is a detailed description of the complaint. The complainant has experienced issues related to service delivery and is seeking appropriate action and resolution. The incident occurred during regular working hours and has affected the complainant's work environment and productivity.	0777-573004	0778-455709	{https://placehold.co/complaint-evidence.pdf,https://placehold.co/witness-statement.pdf}	APPROVED	DIRECTOR_REVIEW	\N	\N	\N	cmd06nnbu000re67wdeax0fwp	HHRMD	\N	2025-04-10 12:45:09.346	2025-07-12 12:45:09.346
cmd08nejo002ne6qkhr5ts0kd	Workplace harassment	Formal complaint regarding service delivery	This is a detailed description of the complaint. The complainant has experienced issues related to service delivery and is seeking appropriate action and resolution. The incident occurred during regular working hours and has affected the complainant's work environment and productivity.	0777-588006	0778-749376	{https://placehold.co/complaint-evidence.pdf,https://placehold.co/witness-statement.pdf}	UNDER_REVIEW	COMMISSION_REVIEW	\N	\N	\N	cmd06nnbz000ve67wncnv4etg	DO	\N	2025-04-17 12:45:09.348	2025-07-12 12:45:09.348
cmd5ttn0k00012bgtx88086m3	Kuchelewa Kupandishwa Cheo	Kutopandishwa Daraja	daraja tangu 2010 mwaka wa ajira 	776084853	776084853	{}	Rejected by HHRMD - Awaiting HRO/Submitter Action	initial	\N	\N	hujaweka wizara unayotoka	cmd5a9ybm00052bt65vf6eel7	DO	cmd059ir10002e6d86l802ljc	2025-07-16 10:36:43.076	2025-07-16 10:38:44.526
cmd5tycdi00052bgtns81i09b	Kuchelewa Kuthibitishwa	Kutopandishwa daraja	Mwaka wa ajira 2010 .	987654321	123456789	{"Test doc confirmation.pdf"}	Closed - Satisfied	completed	barua\\n\\n--- Additional Information from Employee ---\\nsawa	\N	\N	cmd5a9ybm00052bt65vf6eel7	HHRMD	cmd059ir10002e6d86l802ljc	2025-07-16 10:40:22.566	2025-07-16 10:43:54.467
cmd5u40af000f2bgt0jcwwxoa	Mengineyo	Kazini	mmmmmmmmmmmmmmm bbbbbbbbbbb	987654321	912345678	{}	Resolved - Rejected by Commission	completed	\N	\N	\N	cmd5a9ybm00052bt65vf6eel7	DO	cmd059ir10002e6d86l802ljc	2025-07-16 10:44:46.839	2025-07-16 10:46:10.672
cmd5u7o5l000n2bgt1mln14st	Mengineyo	zxzcxcvc 	wwwwwwwwww bbbbbbb mmmmmmmmm nnnnnnnn	987654321	123456789	{}	Resolved - Approved by Commission	completed	\N	\N	\N	cmd5a9ybm00052bt65vf6eel7	DO	cmd059ir10002e6d86l802ljc	2025-07-16 10:47:37.736	2025-07-16 10:50:27.889
cmd763ezv000x2bgtyjs41zx8	Ubaguzi	Ubaguzi	ubaguzi katika maeneo ya kazi unaendelea	987654321	123456789	{}	Rejected by DO - Awaiting HRO/Submitter Action	initial	\N	\N	naomba uthibitisho wa ubaguzi	cmd5a9ybm00052bt65vf6eel7	DO	cmd06nnbd000de67wb6e6ild5	2025-07-17 09:08:00.81	2025-07-17 09:11:26.244
cmd5g3k3200032btwu6pqqk97	Usalama Mahali Kwa Ajira	tunafanya kazi katika mazingira hatarishi	tunafanya kazi katika mazingira hatarishi.  tunaomba kupatiwa posho la mazingira magumu	776932849	777348920	{}	Awaiting More Information	completed	eleza kwa ufupi/ gdyghvjvjhvjb  khkjh h 	\N	\N	cmd5a9yrw007j2bt6jshonn46	DO	cmd06nnbd000de67wb6e6ild5	2025-07-16 04:12:31.213	2025-07-22 20:33:47.676
cmd7682ts00112bgta2iajjnr	Uamuzi Usio wa Haki	uamuzi	ddddfd ghgfhnh gfbhghg gfhhghg	987654321	123456789	{}	Resolved - Rejected by Commission	completed	\N	\N	\N	cmd5a9ybm00052bt65vf6eel7	DO	cmd06nnbd000de67wb6e6ild5	2025-07-17 09:11:38.321	2025-07-17 10:29:16.378
cmd76i5ap001n2bgtids8lcju	Mengineyo	qweqeqwerw	sdfsgfdgdf fdghfhjgh gfhgfcjghm gfhfghjgfj	987654432	198765432	{}	Closed - Satisfied	completed	Tutawasiliana na wizara yako kwa hatuwa za kupewa stahiki zako.	\N	\N	cmd5a9ybm00052bt65vf6eel7	DO	cmd06nnbd000de67wb6e6ild5	2025-07-17 09:19:28.081	2025-07-17 11:06:45.116
cmdewls7j000be6jogik5ye5j	Kuchelewa Kuthibitishwa	kuchelewa kuthibitishwa kazi	Tumefanya kazi kwa muda mrefu lakini hadi sasa hatujathibitishwa kazini.	773412554	777348920	{cheti.pdf}	Awaiting Commission Review	commission_review	eleze\\n\\n--- Additional Information from Employee ---\\nsawa\\nilikuwa ni jioni sana\\nhatujawahi kurudi mapema kazini . kila siku tunarudi usiku wa manane. 	kwa urefu	\N	cmd5a9yee001h2bt6fubd8gt2	HHRMD	cmd059ir10002e6d86l802ljc	2025-07-22 19:04:30.954	2025-07-22 19:32:58.109
cmd76eto700132bgtoyk4ul4v	Uongozi Mbaya	uongozi	ffsdgdh hgjhugjuy tyrhytjuyt ghthty yrtrhyur	987654321	123456789	{}	Resolved - Pending Employee Confirmation	completed	limewekwa sawa	\N	\N	cmd5a9ybm00052bt65vf6eel7	DO	cmd06nnbd000de67wb6e6ild5	2025-07-17 09:16:53.046	2025-07-22 19:45:36.895
cmd5vhkig000v2bgtwfu906dn	Kuchelewa Kupandishwa Cheo	nimekosa kupandishwa cheo kwa miaka mingi	Ninalalamika kutokana na kutopandishwa cheo tangu kuajiriwa kwangu. Nina sifa na vigezo vinavyohitajika kwa kupandishwa cheo. Hata hivyo, ninaamini kuwa upandishaji wa vyeo katika ofisi yetu unafanyika kwa upendeleo na si kwa kuzingatia sifa.	776543289	655543096	{cheti.pdf}	Rejected by DO - Awaiting HRO/Submitter Action	initial	\N	\N	sheria ndio zipo hivyo. hupaswi kulalamika	cmd06nnbx000te67ww4cbaug7	DO	cmd06nnbd000de67wb6e6ild5	2025-07-16 11:23:19.191	2025-07-22 20:06:42.816
cmdezmtfq000be6ec9mmibz0x	Usalama Mahali Kwa Ajira	tunafanya kazi katika mazingira hatarishi	hatari kazini. tuna shida kwa kweli	655412490	777348967	{}	Closed - Commission Decision (Resolved)	final_decision	tume imepokea lalamiko. na hatua imechukuliwa	\N	\N	cmd06nnbx000te67ww4cbaug7	DO	cmd059ir10002e6d86l802ljc	2025-07-22 20:29:18.086	2025-07-22 21:13:45.427
cmdf19xge000je6ecwttkug2j	Uamuzi Usio wa Haki	sijapata haki zangu za msingi	Nimepotezwa na kuachwa. Hii ni hatari.	655412490	777348920	{"Barua ya Lalamiko: sababu.pdf","Ushahidi: Employee Profile Analysis.pdf"}	Rejected by HHRMD – Waiting submitter reaction	initial	\N	\N	sivyo	cmd06nnbx000te67ww4cbaug7	DO	cmd059ir10002e6d86l802ljc	2025-07-22 21:15:15.998	2025-08-08 19:17:28.499
cmd5fsvuz00012btwexkeboan	Uamuzi Usio wa Haki	sijapata haki zangu za msingi	malipo hayajatimia. tumefanya kazi kubwa na malipo yakawa madogo. tunaomba tuwekewe njia imara ya kupata haki zetu.	773412490	777348967	{sababu.pdf}	Closed - Commission Decision (Resolved)	final_decision	litakubaliwa	\N	\N	cmd5a9yrw007j2bt6jshonn46	DO	cmd059ir10002e6d86l802ljc	2025-07-16 04:04:13.258	2025-08-08 19:18:14.326
cme35g8ll00012bask6u8wow6	Uongozi Mbaya	tunafanya kazi katika mazingira hatarishi	Naandika barua hii kuwasilisha malalamiko rasmi kuhusu mazingira ya kazi yanayoathiri utendaji wangu. Katika wiki mbili zilizopita, nimekumbana na changamoto zifuatazo: (1) Ukosefu wa vifaa vya kazi kama vile kompyuta na vifaa vya ulinzi. (2) Kutendewa vibaya na msimamizi wangu wa moja kwa moja. (3) Kelele na usumbufu wa mara kwa mara ofisini. Naomba ofisi yako iingilie kati ili kutatua hali hii. Niko tayari kushiriki katika mazungumzo yoyote ili kufikia suluhu.	0776932849	0777348967	{complaints/1754676807327_mfbgv3_ripoti_ya_kupandishwa_cheo_report__2_.pdf,complaints/1754676816389_mjk326_request_status_report_report.pdf}	Mtumishi ameridhika na hatua	completed	toa maelezo ya ziada kuhusu manyanyaso unayopata\n\n--- Additional Information from Employee ---\nsawa. nimeteseka sana\nusiku na mchana\nkazi hiyo hiyo moja		\N	cmd06nnbz000ve67wncnv4etg	HHRMD	cmd059ir10002e6d86l802ljc	2025-08-08 18:18:37.06	2025-08-08 18:48:51.403
cme38279300052bj1k2cnqxwa	Uamuzi Usio wa Haki	sijapata haki zangu za msingi	Nimefanyiwa ukiukwaji wa haki kwa kutopewa stahiki zangu. Nilipandishwa cheo miaka mitatu iliyopita lakini hadi sasa sijapokea stahiki za cheo hicho. Naomba msaada ili nipate haki zangu za msingi. Kwa sasa sijiendi kazini kwa kukosa fursa.	0655412490	0777348920	{complaints/1754681437035_ls5rt2_1754324616644_6r2ulr_cheti__1_.pdf,complaints/1754681442803_cbtyp4_cheti.pdf}	Closed - Commission Decision (Resolved)	final_decision	hakuna habari hiyo hapa  mjini	\N	\N	cmd5a9yci000l2bt67nmav3dd	DO	cmd059ir10002e6d86l802ljc	2025-08-08 19:31:40.982	2025-08-08 20:32:09.956
cme3d3xm100012b5rpgaa9m35	Ubaguzi	nimebaguliwa kazini	naomba kutoa maelezo ya ubaguzi	0655412432	0772987609	{complaints/1754689972071_wfdsxa_cheti.pdf,complaints/1754689975556_r3z81f_1754324616644_6r2ulr_cheti__1_.pdf}	Mtumishi ameridhika na hatua	completed	elezea zaidi kuhusu ubaguzi huo\n\n--- Additional Information from Employee ---\nnimeitwa majina mabaya.  nimedharauliwa\n\ntatizo lako tumelipokea. tunafanyia uchunguzi		\N	cmd5a9yci000l2bt67nmav3dd	HHRMD	cmd059ir10002e6d86l802ljc	2025-08-08 21:52:59.88	2025-08-08 21:56:32.656
\.


--
-- Data for Name: ConfirmationRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ConfirmationRequest" (id, status, "reviewStage", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "decisionDate", "commissionDecisionDate", "createdAt", "updatedAt") FROM stdin;
cmd08nef80001e6qk110e80y6	REJECTED	HR_REVIEW	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	Insufficient documentation provided	emp8	cmd06nnbz000ve67wncnv4etg	cmd06nnbs000pe67woh62ey8r	2025-06-27 12:45:09.187	\N	2025-05-13 12:45:09.187	2025-07-01 12:45:09.187
cmd08neg50003e6qkxgzynfcq	APPROVED	COMMISSION_REVIEW	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	\N	emp8	cmd06nnbz000ve67wncnv4etg	\N	2025-07-12 12:45:09.221	2025-07-01 12:45:09.221	2025-04-24 12:45:09.221	2025-07-06 12:45:09.221
cmd08negp0005e6qktv9kh13o	UNDER_REVIEW	DIRECTOR_REVIEW	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	\N	emp8	cmd06nnbx000te67ww4cbaug7	cmd06nnbq000ne67wwmiwxuo8	\N	\N	2025-07-01 12:45:09.241	2025-07-07 12:45:09.241
cmd08negs0007e6qkc02knatr	REJECTED	FINAL_APPROVAL	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	Insufficient documentation provided	emp8	cmd06nnbu000re67wdeax0fwp	cmd06nnbq000ne67wwmiwxuo8	2025-07-10 12:45:09.243	\N	2025-05-18 12:45:09.243	2025-06-22 12:45:09.243
cmd08negu0009e6qkond0rg45	PENDING	DIRECTOR_REVIEW	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	\N	emp9	cmd06nnbx000te67ww4cbaug7	\N	\N	\N	2025-02-06 12:45:09.246	2025-07-07 12:45:09.246
cmd08negx000be6qkuvyr51sw	REJECTED	FINAL_APPROVAL	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	Insufficient documentation provided	emp1	cmd06nnbx000te67ww4cbaug7	cmd059ir10002e6d86l802ljc	2025-07-05 12:45:09.248	\N	2025-02-26 12:45:09.248	2025-07-11 12:45:09.248
cmd08negz000de6qkwg9rc7j9	REJECTED	HR_REVIEW	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	Insufficient documentation provided	emp1	cmd06nnbz000ve67wncnv4etg	cmd06nnbl000je67wtl28pk42	2025-07-12 12:45:09.251	\N	2025-06-25 12:45:09.251	2025-06-27 12:45:09.251
cmd08neh1000fe6qkwwhbs675	APPROVED	HR_REVIEW	{https://placehold.co/confirmation-letter.pdf,https://placehold.co/performance-report.pdf}	\N	emp9	cmd06nnbz000ve67wncnv4etg	cmd06nnbl000je67wtl28pk42	2025-07-02 12:45:09.253	2025-07-08 12:45:09.253	2025-05-14 12:45:09.253	2025-06-22 12:45:09.253
cmd0ueqji0001e6gq7bmkselr	Approved by Commission	completed	{"Evaluation Form","Letter of Request","IPA Certificate"}	\N	emp1	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	\N	2025-07-12 22:58:54.214	2025-07-12 22:54:16.542	2025-07-12 22:58:55.547
cmd0vy7a60001e6m40ihekvy4	Approved by Commission	completed	{"Evaluation Form","Letter of Request","IPA Certificate"}	\N	emp1	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	\N	2025-07-12 23:37:55.432	2025-07-12 23:37:24.318	2025-07-12 23:37:57.132
cmdcozbhe0001e6n0cbc1pgtq	Approved by Commission	completed	{cheti.pdf,sababu.pdf}	\N	ofisi_emp_015	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 06:00:59.743	2025-07-21 06:01:20.004	2025-07-21 05:55:33.212	2025-07-21 06:01:20.017
cmdcprfgx0003e6n0v0b49p9x	Approved by Commission	completed	{"Evaluation Form","Letter of Request","IPA Certificate"}	\N	ofisi_emp_018	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 06:19:37.864	2025-07-21 06:20:13.096	2025-07-21 06:17:24.753	2025-07-21 06:20:13.108
cmdcq7xjz0005e6n0yz1ydjd4	Approved by Commission	completed	{"Evaluation Form","Letter of Request","IPA Certificate"}	\N	ofisi_emp_018	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 06:30:28.83	2025-07-21 06:30:31.412	2025-07-21 06:30:14.687	2025-07-21 06:30:31.42
cmdcsek3a0007e6n0miflen8k	Approved by Commission	completed	{mfano.pdf,sababu.pdf}	\N	ofisi_emp_022	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 07:32:42.893	2025-07-21 07:32:59.155	2025-07-21 07:31:23.062	2025-07-21 07:32:59.166
cmdbmq1lw0001e6esuvx3rvxu	Request Received – Awaiting Commission Decision	commission_review	{"Evaluation Form","Letter of Request"}	\N	emp_005	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 11:22:14.78	\N	2025-07-20 12:04:35.108	2025-07-21 11:22:14.791
cmdd0k3l20009e6n0b9e0qnwh	Approved by Commission	completed	{"Evaluation Form","Letter of Request","IPA Certificate"}	\N	ofisi_emp_015	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 11:22:51.31	2025-07-21 11:23:20.346	2025-07-21 11:19:38.504	2025-07-21 11:23:20.358
cmdd0s2y6000be6n0dqrhbbl5	Pending HRMO Review	initial	{cheti.pdf,mfano.pdf,sababu.pdf}	\N	ofisi_emp_013	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 11:32:52.713	\N	2025-07-21 11:25:50.958	2025-07-21 11:58:42.701
cmde2s0v70001e6johbjijq4i	Approved by Commission	completed	{cheti.pdf,mfano.pdf,"Employee Profile Analysis.pdf"}	\N	ofisi_emp_020	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 05:11:39.1	2025-07-22 05:13:20.476	2025-07-22 05:09:33.651	2025-07-22 05:13:20.571
cmdiduwj40005e6rw7guc7yze	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/20250725_083042_4925e195.pdf,confirmation/letters/20250725_083046_a61643e5.pdf}	\N	emp_005	cmd06nnbn000le67wtg41s3su	\N	\N	\N	2025-07-25 05:30:48.496	2025-07-25 05:30:48.496
cmdw5hm1n00012b0ne1o21wal	Approved by Commission	completed	{confirmation/evaluation-forms/1754254067580_b76ft4_cheti.pdf,confirmation/ipa-certificates/1754254071390_xlybp2_Employee_Profile_Analysis.pdf,confirmation/letters/1754254076882_xvdl9f_sababu.pdf}	\N	ofisi_emp_016	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-03 20:48:51.749	2025-08-05 00:51:03.879	2025-08-03 20:45:17.916	2025-08-05 00:51:03.959
cmdxud87400072bgt7a1glryc	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1754356161389_lf53z9_cheti.pdf,confirmation/letters/1754356167494_8ohpt0_mfano.pdf,confirmation/ipa-certificates/1754356164030_iz4wfk_mfano.pdf}	\N	ofisi_emp_014	cmd06nnbn000le67wtg41s3su	\N	\N	\N	2025-08-05 01:09:29.92	2025-08-05 01:09:29.92
cmdypzw5o00012bocfk8bmwqd	Approved by Commission	completed	{confirmation/evaluation-forms/1754409411389_l1eo9i_Employee_Profile_Analysis.pdf,confirmation/letters/1754409415478_9qb5jr_sababu.pdf}	\N	emp_005	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 15:57:51.639	2025-08-05 15:58:17.051	2025-08-05 15:54:55.499	2025-08-05 15:58:15.964
cmdyp7ihm00032bl76yk1u3r2	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1754407957125_o4qves_Employee_Profile_Analysis.pdf,confirmation/letters/1754407967935_qtl2ax_sababu.pdf,confirmation/ipa-certificates/1754407959833_ga0r4c_sababu.pdf}	\N	ofisi_emp_013	cmd06nnbn000le67wtg41s3su	\N	\N	\N	2025-08-05 15:32:51.387	2025-08-05 15:32:51.387
cmdzm1aly00072bgqn8l1s75j	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1754462658881_5gy5js_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf,confirmation/letters/1754463106247_9bjze5_kuacha_kazi_report.pdf,confirmation/ipa-certificates/1754462661529_4i4ic3_ripoti_ya_kupandishwa_cheo_report.pdf}	\N	ofisi_emp_017	cmd06nnbn000le67wtg41s3su	\N	\N	\N	2025-08-06 06:51:48.598	2025-08-06 06:51:48.598
cmdzvzx1100012bvsr3cunol4	Request Received – Awaiting Commission Decision	commission_review	{confirmation/evaluation-forms/1754479916140_3libml_1754478141939_tinkd3_SAID_SAID_New.pdf,confirmation/letters/1754479911747_b0ibuh_SAID_New_-_Copy__4_.pdf}	\N	emp_018	cmd06nnbs000pe67woh62ey8r	cmd06nnbb000be67wwgil78yv	2025-08-06 11:32:32.237	\N	2025-08-06 11:30:40.501	2025-08-06 11:32:31.482
cmdzw593j00032bvscdmyn5rl	Request Received – Awaiting Commission Decision	commission_review	{confirmation/evaluation-forms/1754480080292_s5iflr_Employee_Profile_Analysis.pdf,confirmation/letters/1754480087819_0zzfhg_mfano.pdf,confirmation/ipa-certificates/1754480083692_mwqyg5_cheti.pdf}	\N	ofisi_emp_013	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-06 11:35:19.489	\N	2025-08-06 11:34:49.424	2025-08-06 11:35:20.343
cmdzwoajn00052bvsy56z5o5s	Request Received – Awaiting Commission Decision	commission_review	{confirmation/evaluation-forms/1754480964371_377cxr_1754478412047_w3nnl4_ya_kustaafu_kwa_hiar....pdf,confirmation/letters/1754480973252_pim138_1754375024191_hbvy36_AJIRA_ZAWEMA.pdf}	\N	emp_018	cmd06nnbs000pe67woh62ey8r	cmd059ir10002e6d86l802ljc	2025-08-06 11:50:08.618	\N	2025-08-06 11:49:37.763	2025-08-06 11:50:09.464
cme4jplb800052btjfrl2lvvz	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1754761521868_3exh8a_request_status_report_report.pdf,confirmation/letters/1754761532449_wg29ym_20250725_100627_d2b91848.pdf,confirmation/ipa-certificates/1754761527165_56t9q8_1754324616644_6r2ulr_cheti.pdf}	\N	cme45oe2u000h2bfwmhka9n0f	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-08-09 17:45:34.244	2025-08-09 17:45:34.244
cme4jqahu00072btjzmscppks	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1754761556541_qi7naq_1754407554728_bj7hik_sababu.pdf,confirmation/letters/1754761565198_y2cobq_ripoti_ya_kustaafu_kwa_hiari_report.pdf}	\N	cme45oe2500052bfwa4brwe5k	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-08-09 17:46:06.883	2025-08-09 17:46:06.883
cme4jrggz00092btjq2orp8k1	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1754761613110_0417yh_request_status_report_report.pdf,confirmation/letters/1754761618971_4c1uae_1754241939359_p95qlf_cheti.pdf}	\N	cme45oe2000032bfwn1zsdqfe	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-08-09 17:47:01.283	2025-08-09 17:47:01.283
cme5hhrvz00032boben67f2ex	Approved by Commission	completed	{confirmation/evaluation-forms/1754818365989_a1k26l_1754403408864_8f2228_Employee_Profile_Analysis.pdf,confirmation/ipa-certificates/1754818372163_x6mjdx_1754241939359_p95qlf_cheti.pdf,confirmation/letters/1754818385820_50ba2w_cheti.pdf}	\N	cme45oe2q000f2bfwpadcd6pr	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-10 09:35:20.194	2025-08-10 09:36:49.56	2025-08-10 09:31:16.463	2025-08-10 09:36:49.066
cme5lo9mg00092bhemsl1ei9b	Approved by Commission	completed	{confirmation/evaluation-forms/1754825291661_5lf9o7_1754407554728_bj7hik_sababu.pdf,confirmation/letters/1754825295538_wkoykj_1754676807327_mfbgv3_ripoti_ya_kupandishwa_cheo_report__2_.pdf,confirmation/ipa-certificates/1754825294092_t00f8e_request_status_report_report.pdf}	\N	cme45oe2m000d2bfwd3agas2u	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-10 11:32:19.919	2025-08-10 11:32:22.926	2025-08-10 11:28:17.848	2025-08-10 11:32:22.421
cme602bjt00012boiv0g9jyul	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1754849447678_5z4taa_request_status_report_report.pdf,confirmation/letters/1754849466468_xpcvt3_ripoti_ya_kupandishwa_cheo_report__2_.pdf,confirmation/ipa-certificates/1754849458789_t29cyu_1754407554728_bj7hik_sababu.pdf}	\N	cme45oe2u000h2bfwmhka9n0f	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-08-10 18:11:08.153	2025-08-10 18:11:08.153
cmi4u9f3o0007xkxn4buxnyo2	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1763486370395_ik0y1f_Mozilla-Recovery-Key_2025-07-12_yussufrajab_gmail.com.pdf,confirmation/letters/1763486382181_eieunw_ripoti_ya_kupandishwa_cheo_report.pdf,confirmation/ipa-certificates/1763486373063_tytprq_ripoti_ya_kubadilishwa_kada_report.pdf}	\N	cme45oe2u000h2bfwmhka9n0f	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-11-18 17:19:44.821	2025-11-18 17:19:44.821
cmi4ua1pz0009xkxndb1l63zl	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1763486370395_ik0y1f_Mozilla-Recovery-Key_2025-07-12_yussufrajab_gmail.com.pdf,confirmation/letters/1763486382181_eieunw_ripoti_ya_kupandishwa_cheo_report.pdf,confirmation/ipa-certificates/1763486373063_tytprq_ripoti_ya_kubadilishwa_kada_report.pdf}	\N	cme45oe2u000h2bfwmhka9n0f	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-11-18 17:20:14.135	2025-11-18 17:20:14.135
cmi4ufw4k000bxkxnuwmrzju0	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1763486668076_k6odzl_ya_nyongeza_ya_utumi....pdf,confirmation/letters/1763486677434_a1xh1e_institutions_list_2025-08-17.pdf,confirmation/ipa-certificates/1763486672664_7avc80_ripoti_ya_nyongeza_ya_utumishi_report.pdf}	\N	cme45oe2900072bfwwhh9l9wp	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-11-18 17:24:46.821	2025-11-18 17:24:46.821
cmi4uqu7k000dxkxn2awbsojs	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1763486668076_k6odzl_ya_nyongeza_ya_utumi....pdf,confirmation/letters/1763486677434_a1xh1e_institutions_list_2025-08-17.pdf,confirmation/ipa-certificates/1763486672664_7avc80_ripoti_ya_nyongeza_ya_utumishi_report.pdf}	\N	cme45oe2900072bfwwhh9l9wp	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-11-18 17:33:17.552	2025-11-18 17:33:17.552
44da34af-032c-47c3-a42c-25e2fee9fb17	Pending HRMO/HHRMD Review	initial	{confirmation/evaluation-forms/1764179769264_frqmv3_ripoti_ya_kustaafu_kwa_hiari_report.pdf,confirmation/letters/1764179787831_j3j1wt_architecture_comparison.pdf,confirmation/ipa-certificates/1764179776918_bajujv_ripoti_ya_kubadilishwa_kada_report.pdf}	\N	ae8310dd-9a6a-40fe-9872-e1837a68354f	cme471pqo00032bidhttxmboj	\N	\N	\N	2025-11-26 17:56:32.82	2025-11-26 17:56:32.819
7fb96570-6407-4ef7-a85b-3cc022fafcb4	Approved by Commission	completed	{confirmation/evaluation-forms/1764300581596_5xiyk3_ripoti_ya_kupandishwa_cheo_report__1_.pdf,confirmation/ipa-certificates/1764300585695_t9uul6_ya_nyongeza_ya_utumi....pdf,confirmation/letters/1764300591220_v8xerm_ripoti_ya_nyongeza_ya_utumishi_report.pdf}	\N	1ec7e866-d306-4080-bfec-4405d4e14a51	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-11-28 03:30:26.201	2025-11-28 03:30:48.891	2025-11-26 18:08:31.303	2025-11-26 18:08:31.302
\.


--
-- Data for Name: LwopRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LwopRequest" (id, status, "reviewStage", duration, reason, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt", "endDate", "startDate") FROM stdin;
cmd08nehs0011e6qkmkjvhr1x	APPROVED	FINAL_APPROVAL	1 year	Personal study	{https://placehold.co/lwop-application.pdf,https://placehold.co/supporting-documents.pdf}	\N	emp9	cmd06nnbx000te67ww4cbaug7	cmd06nnbn000le67wtg41s3su	2025-06-13 12:45:09.279	2025-06-30 12:45:09.279	\N	\N
cmd08nehu0013e6qknl185vph	APPROVED	COMMISSION_REVIEW	3 months	Personal study	{https://placehold.co/lwop-application.pdf,https://placehold.co/supporting-documents.pdf}	\N	emp1	cmd06nnbx000te67ww4cbaug7	cmd06nnbq000ne67wwmiwxuo8	2025-06-28 12:45:09.282	2025-07-01 12:45:09.282	\N	\N
cmd08nehx0015e6qkmekftdzl	PENDING	HR_REVIEW	1 year	Family emergency	{https://placehold.co/lwop-application.pdf,https://placehold.co/supporting-documents.pdf}	\N	emp1	cmd06nnbz000ve67wncnv4etg	\N	2025-05-08 12:45:09.284	2025-06-15 12:45:09.284	\N	\N
cmd08nehz0017e6qklpfxsdun	REJECTED	FINAL_APPROVAL	6 months	Further education	{https://placehold.co/lwop-application.pdf,https://placehold.co/supporting-documents.pdf}	Request period conflicts with operational needs	emp1	cmd06nnbx000te67ww4cbaug7	\N	2025-06-30 12:45:09.287	2025-06-29 12:45:09.287	\N	\N
cmd08nei10019e6qk54d8ut5c	APPROVED	INITIAL	6 months	Personal study	{https://placehold.co/lwop-application.pdf,https://placehold.co/supporting-documents.pdf}	\N	emp1	cmd06nnbx000te67ww4cbaug7	\N	2025-06-08 12:45:09.289	2025-07-05 12:45:09.289	\N	\N
cmd08nei3001be6qk5ogon7kb	PENDING	HR_REVIEW	3 months	Family emergency	{https://placehold.co/lwop-application.pdf,https://placehold.co/supporting-documents.pdf}	\N	emp1	cmd06nnbu000re67wdeax0fwp	cmd06nnbn000le67wtg41s3su	2025-04-27 12:45:09.291	2025-06-21 12:45:09.291	\N	\N
cmdd8qf030001e62o8en01fpa	Pending HRMO Review	Initial Review	25	sasasa	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_008	cmd06nnbn000le67wtg41s3su	\N	2025-07-21 15:08:30.08	2025-07-21 15:08:30.08	\N	\N
cmddajprl0003e67kmjefbd26	Approved by Commission	completed	2 months	fgsddgd	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_002	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 15:59:16.785	2025-07-21 16:45:10.887	2025-08-10 00:00:00	2025-07-01 00:00:00
cmde308w80003e6jo3d1aiwyc	Approved by Commission	completed	23 months	kukagua ndugu na jamaa	{cheti.pdf,sababu.pdf}	\N	ofisi_emp_020	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-22 05:15:57.225	2025-07-22 05:18:01.883	2027-06-10 00:00:00	2025-08-09 00:00:00
cmdgmuh080001e6uwgwzfr754	Pending HRMO/HHRMD Review	initial	1 month	anasafiri	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 00:06:52.566	2025-07-24 00:06:52.566	2025-08-07 00:00:00	2025-07-26 00:00:00
cmddcj44m0009e67kaw89ifs6	Approved by Commission	completed	19 months	majaribu	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_008	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 16:54:47.974	2025-07-21 16:55:39.531	2027-02-10 00:00:00	2025-07-23 00:00:00
cmdgpkkxf0001e6lws4c0qecl	Pending HRMO/HHRMD Review	initial	16 months	kachoka kazi	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 01:23:09.939	2025-07-24 01:23:09.939	2026-10-23 00:00:00	2025-07-25 00:00:00
cmddcvqxy000be67kxujuevjv	Rejected by Commission - Awaiting HRO Correction	initial	11 months	kutembea	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_004	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 17:04:37.414	2025-07-21 17:05:06.094	2025-10-31 00:00:00	2024-12-12 00:00:00
cmdiag88w0001e6rwmtybkf8k	Pending HRMO/HHRMD Review	initial	5 months	sawa	{lwop/letters/20250725_065512_9090fb83.pdf,lwop/consents/20250725_065520_f023110a.pdf}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 03:55:24.992	2025-07-25 03:55:24.992	2025-11-29 00:00:00	2025-07-26 00:00:00
cmdib3tzd0003e6rw4heiduqs	Pending HRMO/HHRMD Review	initial	11 months	sawa	{lwop/letters/20250725_071305_7f9eb5d3.pdf,lwop/consents/20250725_071343_3d29979e.pdf}	\N	ofisi_emp_002	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 04:13:46.132	2025-07-25 04:13:46.132	2026-06-05 00:00:00	2025-08-08 00:00:00
cmddd8w9t000de67klodwi74p	Rejected by Commission - Request Concluded	completed	2 months	gjh	{mfano.pdf,sababu.pdf}	\N	ofisi_emp_004	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-21 17:14:50.849	2025-07-21 17:16:11.138	2025-08-10 00:00:00	2025-07-02 00:00:00
cmdzmynq400092bgq56pf1kpq	Pending HRMO/HHRMD Review	initial	11 months	utalii	{lwop/letters/1754465721056_shfu17_mfano__1_.pdf,lwop/consents/1754465724138_clhnd2_kuacha_kazi_report__1_.pdf}	\N	ofisi_emp_015	cmd06nnbn000le67wtg41s3su	\N	2025-08-06 07:17:45.244	2025-08-06 07:35:26.12	2026-07-08 00:00:00	2025-09-08 00:00:00
cmdzumwsv00012bfh4hvid031	Pending HRMO/HHRMD Review	initial	5 months	sawa	{lwop/letters/1754477548677_2lnh0a_Employee_Profile_Analysis.pdf,lwop/consents/1754477551363_dx4lsq_mfano.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-08-06 10:52:34.063	2025-08-06 10:52:34.063	2026-01-03 00:00:00	2025-08-08 00:00:00
cmdyoyqg900012bl7ezxr09rb	Rejected by Commission - Request Concluded	completed	6 months	kushiriki siasa	{lwop/letters/1754407707200_lko681_Employee_Profile_Analysis.pdf,lwop/consents/1754407710281_6i3lbz_sababu.pdf}	\N	ofisi_emp_002	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 15:26:01.833	2025-08-05 15:29:24.106	2026-01-11 00:00:00	2025-08-07 00:00:00
cmdytsy4v00032b7kqj1vw54s	Pending HRMO/HHRMD Review	initial	10 months	KUSHIRIKI SIASA	{lwop/letters/1754415679936_c4r910_mfano.pdf,lwop/consents/1754415685549_p4zd4o_sababu.pdf}	\N	ofisi_emp_008	cmd06nnbn000le67wtg41s3su	\N	2025-08-05 17:41:29.935	2025-08-05 17:41:29.935	2026-05-09 00:00:00	2025-08-08 00:00:00
cmdzuzn4d00032bfhjymbhe7o	Rejected by Commission - Request Concluded	completed	11 months	siasa	{lwop/letters/1754479223081_1i960v_mfano__1_.pdf,lwop/consents/1754479227057_hvdrfd_Profile_Analysis.pdf}	\N	emp_017	cmd06nnbs000pe67woh62ey8r	cmd06nnbb000be67wwgil78yv	2025-08-06 11:02:28.045	2025-08-06 11:22:01.423	2026-07-03 00:00:00	2025-08-08 00:00:00
cme4jt1p5000b2btjr5vy3853	Pending HRMO/HHRMD Review	initial	12 months	kutembea ulaya	{lwop/letters/1754761687532_l2epao_request_status_report_report.pdf,lwop/consents/1754761693225_9yqy5j_20250802_094101_02331ce1.pdf}	\N	emp_013	cme471pqo00032bidhttxmboj	\N	2025-08-09 17:48:15.449	2025-08-09 17:48:15.449	2026-08-09 00:00:00	2025-08-16 00:00:00
cmdzv5nqx00052bfht1rrvak3	Approved by Commission	completed	14 months	siasa	{lwop/letters/1754478412047_w3nnl4_ya_kustaafu_kwa_hiar....pdf,lwop/consents/1754478425971_wht7ty_mfano__1_.pdf}	\N	emp_014	cmd06nnbs000pe67woh62ey8r	cmd06nnbb000be67wwgil78yv	2025-08-06 11:07:08.793	2025-08-06 11:29:17.206	2026-09-26 00:00:00	2025-08-06 00:00:00
cme487gq500012btj3kb5djnh	Approved by Commission	completed	6 months	utalii	{lwop/letters/1754742198246_v25fvt_request_status_report_report.pdf,lwop/consents/1754742207404_gqvd6s_1754407554728_bj7hik_sababu.pdf}	\N	cme45oe3d000r2bfw3vs295u0	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-09 12:23:32.717	2025-08-09 12:27:09.393	2026-02-14 00:00:00	2025-08-23 00:00:00
cme4jui1y000f2btj2gd59qv8	Pending HRMO/HHRMD Review	initial	22 months	kushiriki siasa	{lwop/letters/1754761751649_iqv851_1754407554728_bj7hik_sababu.pdf,lwop/consents/1754761757969_yobc4z_ripoti_ya_kupandishwa_cheo_report.pdf}	\N	cme45oe31000l2bfw2kzug3tj	cme471pqo00032bidhttxmboj	\N	2025-08-09 17:49:23.302	2025-08-09 17:49:23.302	2027-06-09 00:00:00	2025-08-23 00:00:00
cmhu8nk2m0001xk0ssf3c5haa	Pending HRMO/HHRMD Review	initial	12 months	Kushiriki siasa	{lwop/letters/1762845379645_k94zjs_1760436302647_qdchvr_vmware_simplified_setup_1_.pdf,lwop/consents/1762845389648_ph5d7n_20250725_071305_7f9eb5d3__2_.pdf}	\N	emp1	cmd06nnbn000le67wtg41s3su	\N	2025-11-11 07:17:11.135	2025-11-11 07:17:11.135	2026-11-01 00:00:00	2025-11-11 00:00:00
83bf51e4-7240-47fd-ae90-ccef8884779b	Pending HRMO/HHRMD Review	initial	18 months	Kushiriki siasa	{lwop/letters/1764166544927_5l6inj_proxmox-setup-guide_single_10gbps_port.pdf,lwop/consents/1764166550871_8r8alh_ripoti_ya_kupandishwa_cheo_report__2_.pdf}	\N	b39e4521-e5d3-457d-9c64-2648b59cbf49	cme471pqo00032bidhttxmboj	\N	2025-11-26 14:15:53.734	2025-11-26 14:15:53.732	2027-05-07 00:00:00	2025-11-28 00:00:00
542b851c-bc8f-48fc-a923-aaa7a773c5e8	Pending HRMO/HHRMD Review	initial	16 months	Kushiriki siasa	{lwop/letters/1764179432049_u01x0l_ripoti_ya_kupandishwa_cheo_report__2_.pdf,lwop/consents/1764179449959_aqzw5t_1754324616644_6r2ulr_cheti__1_.pdf}	\N	1abb6d7d-3816-421c-ac6e-48ccf04bf66e	cme471pqo00032bidhttxmboj	\N	2025-11-26 17:50:53.888	2025-11-26 17:50:53.886	2027-03-05 00:00:00	2025-11-28 00:00:00
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, message, link, "isRead", "userId", "createdAt") FROM stdin;
cmd08nejx002te6qki3rnhq0y	LWOP request submitted successfully	/dashboard	f	cmd06nnbs000pe67woh62ey8r	2025-06-22 12:45:09.356
cmd08nejz002ve6qkgwu1jlz9	Retirement request pending commission approval	/dashboard	t	cmd059ir10002e6d86l802ljc	2025-07-07 12:45:09.359
cmd08nek2002ze6qkozdu6go4	Service extension request approved	/dashboard	t	cmd06nnbs000pe67woh62ey8r	2025-07-01 12:45:09.362
cmd08nek40031e6qksgxhushl	Service extension request approved	/dashboard	f	cmd06nnbi000he67wz9doivi6	2025-07-10 12:45:09.364
cmd08nek60033e6qk5s8kx9if	Service extension request approved	/dashboard	f	cmd06nnbs000pe67woh62ey8r	2025-07-03 12:45:09.366
cmd08nek80035e6qkl6ec2uga	LWOP request submitted successfully	/dashboard	t	cmd06nnbd000de67wb6e6ild5	2025-06-29 12:45:09.368
cmd08nek90037e6qk6qc17cha	Service extension request approved	/dashboard	t	cmd06nnbb000be67wwgil78yv	2025-06-24 12:45:09.369
cmd08nekb0039e6qkzv9so9xz	Complaint investigation update available	/dashboard	f	cmd06nnbi000he67wz9doivi6	2025-07-10 12:45:09.371
cmd08nekd003be6qkjebpyubb	Service extension request approved	/dashboard	t	cmd06nnbz000ve67wncnv4etg	2025-07-11 12:45:09.373
cmd08nekg003fe6qknn3dwy44	New promotion request requires your review	/dashboard	f	cmd06nnbi000he67wz9doivi6	2025-06-17 12:45:09.376
cmd08neki003he6qkwstuiw2r	New promotion request requires your review	/dashboard	t	cmd06nnbi000he67wz9doivi6	2025-07-04 12:45:09.378
cmd08nejs002re6qk654ttmj8	Service extension request approved	/dashboard	t	cmd06nnbb000be67wwgil78yv	2025-07-12 12:45:09.352
cmd08nekr003re6qk66wj2yk5	Service extension request approved	/dashboard	t	cmd06nnbb000be67wwgil78yv	2025-07-04 12:45:09.387
cmd08nekk003je6qk8i4zinha	New promotion request requires your review	/dashboard	t	cmd06nnbx000te67ww4cbaug7	2025-07-10 12:45:09.38
cmd08nekq003pe6qkef7cdjcr	LWOP request submitted successfully	/dashboard	t	cmd06nnbl000je67wtl28pk42	2025-06-30 12:45:09.385
cmd5tw8qk00032bgt9tx0voec	Your complaint "Kutopandishwa Daraja" has been updated to: Rejected by HHRMD - Awaiting HRO/Submitter Action.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:38:44.54
cmd5tzr6000072bgtxu6lsdn3	Your complaint "Kutopandishwa daraja" has been updated to: Awaiting More Information.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:41:28.392
cmd5u0grn00092bgtq94et8j6	Your complaint "Kutopandishwa daraja" has been updated to: Under Review - Additional Information Provided.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:42:01.571
cmd5u2a82000b2bgtpz916adx	Your complaint "Kutopandishwa daraja" has been updated to: Resolved - Pending Employee Confirmation.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:43:26.402
cmd5u2vvu000d2bgtqfq8t9eh	Your complaint "Kutopandishwa daraja" has been updated to: Closed - Satisfied.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:43:54.474
cmd5u4e65000h2bgtngn3tayo	Your complaint "Kazini" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:45:04.829
cmd5u4s19000j2bgt24f162ms	Your complaint "Kazini" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:45:22.797
cmd5u5szb000l2bgtequnbpu4	Your complaint "Kazini" has been updated to: Resolved - Rejected by Commission.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:46:10.679
cmd5u8o16000p2bgtxk4ceunn	Your complaint "zxzcxcvc " has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:48:24.234
cmd5u90xc000r2bgtsppshvuh	Your complaint "zxzcxcvc " has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:48:40.944
cmd5ubbg8000t2bgt7jktis0o	Your complaint "zxzcxcvc " has been updated to: Resolved - Approved by Commission.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-16 10:50:27.896
cmd767tj3000z2bgtargns86n	Your complaint "Ubaguzi" has been updated to: Rejected by DO - Awaiting HRO/Submitter Action.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:11:26.271
cmd76f3lu00152bgtjxs1q48q	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.922
cmd76f3m200172bgtpnugfq6e	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.913
cmd76f3m300192bgt3b5knbj1	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.931
cmd76f3m7001b2bgtpvnat9mt	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.918
cmd76f3mb001d2bgtk2x8jk8r	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.939
cmd76f3mf001f2bgth8qbj9aj	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.943
cmd76f3mi001h2bgtym3eyv94	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.947
cmd76f3mz001j2bgtnu6mu9ms	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:05.964
cmd76f4qt001l2bgtipc6we3d	Your complaint "uamuzi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 09:17:07.397
cmd78zx12001p2bgtfcgasl08	Your complaint "uamuzi" has been updated to: Resolved - Rejected by Commission.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 10:29:16.406
cmd79v4sr001r2bgtab5zbgz4	Your complaint "qweqeqwerw" has been updated to: Resolved - Pending Employee Confirmation.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 10:53:32.811
cmd7ac45k001t2bgt65n7v2bt	Your complaint "qweqeqwerw" has been updated to: Closed - Satisfied.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-17 11:06:45.129
cmd8h4fn100212bgt22wdskqa	Your Change of Cadre request to "Afisa Utawala" has been updated to: Pending HHRMD Review.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:04:30.254
cmd8h6spd00232bgtr5r0h6wu	Your Change of Cadre request to "Afisa Ushauri nasaha" has been updated to: Pending HHRMD Review.	/dashboard/cadre-change	f	cmd5a9ydp00152bt6q3ms10z1	2025-07-18 07:06:20.497
cmd08neko003ne6qk1fyzffeu	Complaint investigation update available	/dashboard	t	cmd06nnb50007e67wa5491lw5	2025-06-25 12:45:09.383
cmd8hfg3300252bgtsw1rgznk	Your Change of Cadre request to "Afisa Sheria" has been updated to: Rejected by HRMO - Awaiting HRO Correction.	/dashboard/cadre-change	f	cmd5a9ydh00112bt6x1qstl3w	2025-07-18 07:13:04.048
cmd8higsd00272bgtvp9edko9	Your Change of Cadre request to "Afisa Utawala" has been updated to: Rejected by HHRMD - Awaiting HRO Correction.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:15:24.925
cmd8hwh0600292bgtzulihr5b	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Pending HRMO/HHRMD Review.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:26:18.39
cmd8hx27h002b2bgt34md3r96	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Pending HHRMD Review.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:26:45.869
cmd8hxn59002d2bgt85d0ilss	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:27:13.006
cmd8hxqo3002f2bgt7w6fdkhp	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Pending HHRMD Review.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:27:17.572
cmd8hypfa002h2bgtlbb7izkm	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:02.615
cmd8hyr1z002j2bgtydyiiao5	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:04.727
cmd8hyrpu002l2bgtunmfx18r	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:05.586
cmd8hz667002n2bgtc4mvans7	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:24.319
cmd8hz6ld002p2bgtbdwb2euo	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:24.865
cmd8hz6vr002r2bgtf4cy69ve	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:25.239
cmd8hz6y4002t2bgt90g393mb	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:25.324
cmd8hz75i002v2bgtoj2g3w3t	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:25.59
cmd8hz7ef002x2bgtac8pv5g2	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:25.911
cmd8hz7j3002z2bgt42kxrm66	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:26.079
cmd8hz9gl00312bgtg7we6olu	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:28:28.582
cmd8i0fc800332bgt98atzebh	Your Change of Cadre request to "Afisa Ushauri nasaha" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ydp00152bt6q3ms10z1	2025-07-18 07:29:22.856
cmd8i12r600352bgty4abzk1w	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Rejected by Commission.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:29:53.203
cmd8i17jf00372bgts2nk5vj8	Your Change of Cadre request to "Afisa Rasilimali watu" has been updated to: Rejected by Commission.	/dashboard/cadre-change	f	cmd5a9ybq00072bt6fk4ixogc	2025-07-18 07:29:59.403
cmd8i1q2f00392bgtpll3yeul	Your Change of Cadre request to "Afisa Ushauri nasaha" has been updated to: Approved by Commission.	/dashboard/cadre-change	f	cmd5a9ydp00152bt6q3ms10z1	2025-07-18 07:30:23.416
cmd8isgo3003h2bgtv7dhh5wj	Your voluntary Retirement request has been updated to: Rejected by HRMO - Awaiting HRO Correction.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:51:10.948
cmd8iu8jm003j2bgtb1d5csjr	Your voluntary Retirement request has been updated to: Pending HRMO/HHRMD Review.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:52:33.73
cmd8ius8h003l2bgttix31gbd	Your voluntary Retirement request has been updated to: Pending HHRMD Review.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:52:59.249
cmd8iw6p6003n2bgt3ehxvpx1	Your voluntary Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:54:04.65
cmd8ix1s3003p2bgtbrng17a0	Your voluntary Retirement request has been updated to: Rejected by Commission.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:54:44.931
cmd8ixi30003r2bgte8kvbrnc	Your voluntary Retirement request has been updated to: Rejected by Commission.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:55:06.06
cmd8izpla003t2bgt2y1aat0e	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:56:49.102
cmd8j04h7003v2bgtimphpnth	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:08.396
cmd8j06b6003x2bgtb0rdb00k	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:10.77
cmd8j06u2003z2bgtc5vqaycx	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:11.45
cmd8j07cf00412bgtaqgqme84	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:12.111
cmd8j07wd00432bgtwqqhe34q	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:12.83
cmd8j08ay00452bgt0h00yj1b	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:13.354
cmd8j08m400472bgtngz7u0sm	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:13.756
cmd8j08td00492bgt0ex3qx09	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:14.017
cmd8j08zw004b2bgtmq3yzlrq	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:14.253
cmd8j097z004d2bgt4cmweso5	Your compulsory Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:57:14.543
cmd8j1a5h004f2bgtr5bagq4b	Your compulsory Retirement request has been updated to: Approved by Commission.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 07:58:02.405
cmd8jgvib004l2bgtw99d2vmz	Your illness Retirement request has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 08:10:09.923
cmd8jhgaj004n2bgt03me8px9	Your illness Retirement request has been updated to: Pending HHRMD Review.	/dashboard/retirement	f	cmd5a9ydh00112bt6x1qstl3w	2025-07-18 08:10:36.86
cmd8jyasy004p2bgt458u0tiy	Your illness Retirement request has been updated to: Rejected by Commission.	/dashboard/retirement	f	cmd5a9ydb000z2bt6u03i5p63	2025-07-18 08:23:42.898
cmd8kclye004t2bgt83241fii	Your Resignation request with effective date July 25th, 2025 has been updated to: Pending HHRMD Acknowledgement.	/dashboard/resignation	f	cmd5a9ybv00092bt6wp2ybul7	2025-07-18 08:34:50.534
cmd8kdx4t004v2bgtc3q2jn5f	Your Resignation request with effective date July 25th, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9ybv00092bt6wp2ybul7	2025-07-18 08:35:51.678
cmd8kf7w5004x2bgtdgn5ryrm	Your Resignation request with effective date July 25th, 2025 has been updated to: Approved by Commission.	/dashboard/resignation	f	cmd5a9ybv00092bt6wp2ybul7	2025-07-18 08:36:52.278
cmd8khuhc00512bgtefhrqzh9	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:54.864
cmd8khv7l00532bgt3l7tdszd	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:55.809
cmd8khvht00552bgt9039cro9	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:56.177
cmd8khvr500572bgtt4ge855q	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:56.513
cmd8khvzc00592bgt3cbhbd38	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:56.808
cmd8khw69005b2bgtg187fgcb	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:57.057
cmd8khwcj005d2bgtta2yvrfy	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:57.283
cmd8khwjj005f2bgthbo1fo7e	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:57.535
cmd8khwq9005h2bgtoz6hfrko	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:57.777
cmd8khwxp005j2bgt1mmcm7ba	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:58.046
cmd8khxjr005l2bgt9jizuehy	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:58.84
cmd8khxx3005n2bgtp3n4t0ra	Your Resignation request with effective date August 2nd, 2025 has been updated to: Forwarded to Commission for Acknowledgment.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:38:59.319
cmd8kife4005p2bgto8i83t7w	Your Resignation request with effective date August 2nd, 2025 has been updated to: Rejected by Commission.	/dashboard/resignation	f	cmd5a9yce000j2bt65eqmtcdp	2025-07-18 08:39:21.964
cmda6j60j005v2bgtizb6vdwb	Your Change of Cadre request to "Afisa Mkuu Msaidizi" has been updated to: Request Received – Awaiting Commission Decision.	/dashboard/cadre-change	f	cmd5a9ybb00012bt6m2oxl3li	2025-07-19 11:43:34.195
cmdexj5kz0001e6eceyw5x4b2	Your complaint "kuchelewa kuthibitishwa kazi" has been updated to: Awaiting More Information.	/dashboard/complaints	f	cmd5a9yee001h2bt6fubd8gt2	2025-07-22 19:30:27.972
cmdexkwh70003e6ecu6n5cp4w	Your complaint "kuchelewa kuthibitishwa kazi" has been updated to: Under Review - Additional Information Provided.	/dashboard/complaints	f	cmd5a9yee001h2bt6fubd8gt2	2025-07-22 19:31:49.484
cmdexmdfn0005e6ecbakhrr07	Your complaint "kuchelewa kuthibitishwa kazi" has been updated to: Awaiting Commission Review.	/dashboard/complaints	f	cmd5a9yee001h2bt6fubd8gt2	2025-07-22 19:32:58.115
cmdey2mxe0007e6ec6hxm0ctq	Your complaint "uongozi" has been updated to: Resolved - Pending Employee Confirmation.	/dashboard/complaints	f	cmd5a9ybm00052bt65vf6eel7	2025-07-22 19:45:36.914
cmdeytrqk0009e6ecwzdn04ir	Your complaint "nimekosa kupandishwa cheo kwa miaka mingi" has been updated to: Rejected by DO - Awaiting HRO/Submitter Action.	/dashboard/complaints	f	cmd06nnbx000te67ww4cbaug7	2025-07-22 20:06:42.86
cmdeznjft000de6ecicdpfbs5	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: lalamiko lako limepokelewa, linafanyiwa kazi.	/dashboard/complaints	f	cmd06nnbx000te67ww4cbaug7	2025-07-22 20:29:51.786
cmdezslhh000fe6ecy4ptaznh	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: Awaiting More Information.	/dashboard/complaints	f	cmd5a9yrw007j2bt6jshonn46	2025-07-22 20:33:47.717
cmdf17zlp000he6eci3qm8n7z	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: Closed - Commission Decision (Resolved).	/dashboard/complaints	f	cmd06nnbx000te67ww4cbaug7	2025-07-22 21:13:45.469
cmdf1a78d000le6ec7vy92zqf	Your complaint "sijapata haki zangu za msingi" has been updated to: lalamiko lako limepokelewa, linafanyiwa kazi.	/dashboard/complaints	f	cmd06nnbx000te67ww4cbaug7	2025-07-22 21:15:28.669
cme35k5rg00032basqkxz9lv8	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: lalamiko lako limepokelewa, linafanyiwa kazi.	/dashboard/complaints	t	cmd06nnbz000ve67wncnv4etg	2025-08-08 18:21:40.012
cme37jxi900012bj1ylpv3xtt	Your complaint "sijapata haki zangu za msingi" has been updated to: Rejected by HHRMD – Waiting submitter reaction.	/dashboard/complaints	f	cmd06nnbx000te67ww4cbaug7	2025-08-08 19:17:28.545
cme37kwua00032bj1lkjuevx2	Your complaint "sijapata haki zangu za msingi" has been updated to: Closed - Commission Decision (Resolved).	/dashboard/complaints	f	cmd5a9yrw007j2bt6jshonn46	2025-08-08 19:18:14.338
cme382n2v00072bj175biy4oh	Your complaint "sijapata haki zangu za msingi" has been updated to: lalamiko lako limepokelewa, linafanyiwa kazi.	/dashboard/complaints	t	cmd5a9yci000l2bt67nmav3dd	2025-08-08 19:32:01.495
cme3a7zfv00092bj1xos326m0	Your complaint "sijapata haki zangu za msingi" has been updated to: Closed - Commission Decision (Resolved).	/dashboard/complaints	t	cmd5a9yci000l2bt67nmav3dd	2025-08-08 20:32:10.027
cme3d5f6300032b5r2usxlfd0	Your complaint "nimebaguliwa kazini" has been updated to: Awaiting More Information.	/dashboard/complaints	t	cmd5a9yci000l2bt67nmav3dd	2025-08-08 21:54:09.291
cme3d65kw00052b5rrrfw2se2	Your complaint "nimebaguliwa kazini" has been updated to: Under Review - Additional Information Provided.	/dashboard/complaints	t	cmd5a9yci000l2bt67nmav3dd	2025-08-08 21:54:43.52
cme3d7woj00072b5rypvnhddg	Your complaint "nimebaguliwa kazini" has been updated to: Resolved - Pending Employee Confirmation.	/dashboard/complaints	t	cmd5a9yci000l2bt67nmav3dd	2025-08-08 21:56:05.299
cme3d8hsq00092b5rpbn6f38i	Your complaint "nimebaguliwa kazini" has been updated to: Mtumishi ameridhika na hatua.	/dashboard/complaints	t	cmd5a9yci000l2bt67nmav3dd	2025-08-08 21:56:32.666
cme3f0zvf00012b86lbd3kg18	Karibu katika Mfumo wa Usimamizi wa Huduma za Kiraia (CSMS). Mfumo huu utakusaidia kusimamia maombi yako ya kiutendaji.	/dashboard	t	cmd06nnbn000le67wtg41s3su	2025-08-08 22:46:42.075
cme473rh700052bidazuz5mfo	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	cme471pqo00032bidhttxmboj	2025-08-09 11:52:40.411
cme487gqs00032btj2vii7gzc	New leave without pay request submitted by Muuguzi Mwanaisha Juma Khamis (cme487gq500012btj3kb5djnh). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-08-09 12:23:32.741
cme46vyqq00012bidh7j9jxhe	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	cmd06nn9p0005e67wgvz3pd6c	2025-08-09 11:46:36.578
cme59lizw00012bobixxkz2xa	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	cme57cciu00082bcqnbw9sjm9	2025-08-10 05:50:14.636
cme487gql00022btjg48hvwwb	New leave without pay request submitted by Muuguzi Mwanaisha Juma Khamis (cme487gq500012btj3kb5djnh). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-08-09 12:23:32.733
cme4jt1q9000d2btjolqmapfs	New leave without pay request submitted by Dr. Mwalimu Hassan Omar (cme4jt1p5000b2btjr5vy3853). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-08-09 17:48:15.489
cme4jui2a000h2btj4alc6xrn	New leave without pay request submitted by Muuguzi Juma Khamis Omar (cme4jui1y000f2btj2gd59qv8). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-08-09 17:49:23.314
cme4jvdns000l2btj2zrec2ff	New promotion request submitted by Muuguzi Juma Khamis Omar (cme4jvdnb000j2btj777rf0xk). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-08-09 17:50:04.265
cme5jj93800052bheciyds81j	New leave without pay request submitted by Bakari Mohamed Khamis (cme5jj92q00032bhegl61crei). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-08-10 10:28:24.645
cme4jt1pk000c2btjb3c0pkr4	New leave without pay request submitted by Dr. Mwalimu Hassan Omar (cme4jt1p5000b2btjr5vy3853). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-08-09 17:48:15.464
cme4jui25000g2btjtbn3ggfg	New leave without pay request submitted by Muuguzi Juma Khamis Omar (cme4jui1y000f2btj2gd59qv8). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-08-09 17:49:23.309
cme4jvdno000k2btj8a87awde	New promotion request submitted by Muuguzi Juma Khamis Omar (cme4jvdnb000j2btj777rf0xk). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-08-09 17:50:04.26
cme56ms8t000z2btjhnrdywta	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	cme56ma17000x2btjnpvgr0kg	2025-08-10 04:27:14.429
cme5jj93e00062bhe8wo8i03f	New leave without pay request submitted by Bakari Mohamed Khamis (cme5jj92q00032bhegl61crei). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-08-10 10:28:24.65
cme5jj93800042bheocu9tw9y	New leave without pay request submitted by Bakari Mohamed Khamis (cme5jj92q00032bhegl61crei). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-08-10 10:28:24.645
cme5jj93e00072bhebcsj7snk	New leave without pay request submitted by Bakari Mohamed Khamis (cme5jj92q00032bhegl61crei). Requires your review.	/dashboard/lwop	t	cme57bm9600062bcqtlkj9wcx	2025-08-10 10:28:24.65
cme6ls5p500052bgxw0908vhi	New leave without pay request submitted by Salim Hamad Mwinyi (cme6ls5ov00032bgxwhk2x3og). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-08-11 04:19:05.561
cme6ls5pc00062bgxjqjef9jt	New leave without pay request submitted by Salim Hamad Mwinyi (cme6ls5ov00032bgxwhk2x3og). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-08-11 04:19:05.569
cme6ls5pc00072bgxdlpu8tr4	New leave without pay request submitted by Salim Hamad Mwinyi (cme6ls5ov00032bgxwhk2x3og). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-08-11 04:19:05.569
cme6lu3g8000b2bgxt096pvd4	New promotion request submitted by Salim Hamad Mwinyi (cme6lu3fz00092bgxhcmrgmnk). Requires your review.	/dashboard/promotion	f	cme57api100042bcqhbkg91r8	2025-08-11 04:20:35.96
cme6lu3gd000c2bgxosmc8hdx	New promotion request submitted by Salim Hamad Mwinyi (cme6lu3fz00092bgxhcmrgmnk). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-08-11 04:20:35.965
cme6lu3gd000d2bgxpjledcow	New promotion request submitted by Salim Hamad Mwinyi (cme6lu3fz00092bgxhcmrgmnk). Requires your review.	/dashboard/promotion	f	cme57bm9600062bcqtlkj9wcx	2025-08-11 04:20:35.965
cme6x2bzf000s2bgx2qe0kkd5	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	f	cmd06nnbq000ne67wwmiwxuo8	2025-08-11 09:34:56.044
cme6ls5p500042bgx7m8xb4ig	New leave without pay request submitted by Salim Hamad Mwinyi (cme6ls5ov00032bgxwhk2x3og). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-08-11 04:19:05.561
cme6lu3g8000a2bgxbftjrokb	New promotion request submitted by Salim Hamad Mwinyi (cme6lu3fz00092bgxhcmrgmnk). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-08-11 04:20:35.96
cmecjpr4d00012bhu7s0gfjre	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	f	cmd06nnbu000re67wdeax0fwp	2025-08-15 08:07:51.179
cmeck04e100052bhu7rawvm1a	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	cmecjzkmi00032bhu3ts6wi8y	2025-08-15 08:15:54.938
cme6tbpun000q2bgxsj429amg	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	cme6sts42000o2bgxfjax08co	2025-08-11 07:50:15.455
cmgqawlr50003xk8483p2m8as	New leave without pay request submitted by Maryam Said Kombo (cmgqawlqy0001xk841u18fdx4). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-10-14 08:29:25.409
cmgqawlr90004xk84jbvafo1z	New leave without pay request submitted by Maryam Said Kombo (cmgqawlqy0001xk841u18fdx4). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-10-14 08:29:25.413
cmgqawlr90005xk84yq6gbylj	New leave without pay request submitted by Maryam Said Kombo (cmgqawlqy0001xk841u18fdx4). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-10-14 08:29:25.413
cmgqaytpl0009xk84doybsp95	New promotion request submitted by Maryam Said Kombo (cmgqaytpf0007xk84b1jg4eq0). Requires your review.	/dashboard/promotion	f	cme57api100042bcqhbkg91r8	2025-10-14 08:31:09.033
cmgqaytpo000axk84lreyxe7w	New promotion request submitted by Maryam Said Kombo (cmgqaytpf0007xk84b1jg4eq0). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-10-14 08:31:09.036
cmgqaytpo000bxk84pc551mzt	New promotion request submitted by Maryam Said Kombo (cmgqaytpf0007xk84b1jg4eq0). Requires your review.	/dashboard/promotion	f	cme57bm9600062bcqtlkj9wcx	2025-10-14 08:31:09.036
cmgqazpf2000fxk842erv4214	New promotion request submitted by Maryam Said Kombo (cmgqazpex000dxk84vw8jufey). Requires your review.	/dashboard/promotion	f	cme57api100042bcqhbkg91r8	2025-10-14 08:31:50.126
cmgqazpf5000gxk8444g29pqn	New promotion request submitted by Maryam Said Kombo (cmgqazpex000dxk84vw8jufey). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-10-14 08:31:50.13
cmgqazpf5000hxk842ctuay3t	New promotion request submitted by Maryam Said Kombo (cmgqazpex000dxk84vw8jufey). Requires your review.	/dashboard/promotion	f	cme57bm9600062bcqtlkj9wcx	2025-10-14 08:31:50.13
cmhu8nk300003xk0sjiemq96n	New leave without pay request submitted by Ali Juma Ali (cmhu8nk2m0001xk0ssf3c5haa). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-11 07:17:11.148
cmhu8nk350004xk0sysqpuejb	New leave without pay request submitted by Ali Juma Ali (cmhu8nk2m0001xk0ssf3c5haa). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-11 07:17:11.153
cmhu8nk350005xk0s8uww10v7	New leave without pay request submitted by Ali Juma Ali (cmhu8nk2m0001xk0ssf3c5haa). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-11 07:17:11.153
cmhu8u2lk0009xk0s6b2kdhrd	New leave without pay request submitted by Hassan Juma Msangi (cmhu8u2lc0007xk0srdfz7zcb). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-11 07:22:15.08
cmhu8u2lo000axk0sau4mkpjo	New leave without pay request submitted by Hassan Juma Msangi (cmhu8u2lc0007xk0srdfz7zcb). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-11 07:22:15.084
cmhu8u2lo000bxk0s755iu5e1	New leave without pay request submitted by Hassan Juma Msangi (cmhu8u2lc0007xk0srdfz7zcb). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-11 07:22:15.084
cmhu8xpcl000fxk0s0vw8rpf7	New leave without pay request submitted by Mwajuma Abdallah Mtumwa (cmhu8xpcf000dxk0slw9hs7vq). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-11 07:25:04.534
cmhu8xpcp000gxk0s306xfwn4	New leave without pay request submitted by Mwajuma Abdallah Mtumwa (cmhu8xpcf000dxk0slw9hs7vq). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-11 07:25:04.538
cmhu8xpcp000hxk0ssmx4m764	New leave without pay request submitted by Mwajuma Abdallah Mtumwa (cmhu8xpcf000dxk0slw9hs7vq). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-11 07:25:04.538
cmhu9q81o000lxk0s2lqftq74	New leave without pay request submitted by John Peter Mwalimu (cmhu9q81h000jxk0sm8o2ujt7). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-11 07:47:15.133
cmhu9q81s000mxk0s2cj0aqtt	New leave without pay request submitted by John Peter Mwalimu (cmhu9q81h000jxk0sm8o2ujt7). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-11 07:47:15.136
cmhu9q81s000nxk0sso7mu2e1	New leave without pay request submitted by John Peter Mwalimu (cmhu9q81h000jxk0sm8o2ujt7). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-11 07:47:15.136
cmhua1kjx000rxk0s441hieiy	New leave without pay request submitted by Rashid Omar Salum (cmhua1kjl000pxk0svme1dgvb). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-11 07:56:04.557
cmhua1kk4000sxk0sdbnhslbe	New leave without pay request submitted by Rashid Omar Salum (cmhua1kjl000pxk0svme1dgvb). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-11 07:56:04.565
cmhua1kk4000txk0sdvuycap4	New leave without pay request submitted by Rashid Omar Salum (cmhua1kjl000pxk0svme1dgvb). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-11 07:56:04.565
cmhuauffo0003xkf9nz0rg13m	New leave without pay request submitted by Zaina Mohamed Bakari (cmhuauffc0001xkf9uym34tad). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-11 08:18:30.948
cmhuauffs0004xkf9xqkd63td	New leave without pay request submitted by Zaina Mohamed Bakari (cmhuauffc0001xkf9uym34tad). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-11 08:18:30.953
cmhuauffs0005xkf99x1306re	New leave without pay request submitted by Zaina Mohamed Bakari (cmhuauffc0001xkf9uym34tad). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-11 08:18:30.953
cmi49xzrg000dxkf9em78bc9r	New leave without pay request submitted by Khamis Bakari Mfalme (cmi49xzr9000bxkf9pfl1jtdm). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-18 07:50:59.405
cmi49xzrk000exkf9sswcgc9v	New leave without pay request submitted by Khamis Bakari Mfalme (cmi49xzr9000bxkf9pfl1jtdm). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-18 07:50:59.408
cmi49xzrk000fxkf95z1yoo7a	New leave without pay request submitted by Khamis Bakari Mfalme (cmi49xzr9000bxkf9pfl1jtdm). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-18 07:50:59.408
cmi4a9d2s000jxkf9nixdd014	New promotion request submitted by Hassan Juma Msangi (cmi4a9d2l000hxkf9dp2zs7c9). Requires your review.	/dashboard/promotion	f	cme57api100042bcqhbkg91r8	2025-11-18 07:59:49.877
cmi4a9d2w000kxkf9ksfu4lsh	New promotion request submitted by Hassan Juma Msangi (cmi4a9d2l000hxkf9dp2zs7c9). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-11-18 07:59:49.88
cmi4a9d2w000lxkf99hk18iyv	New promotion request submitted by Hassan Juma Msangi (cmi4a9d2l000hxkf9dp2zs7c9). Requires your review.	/dashboard/promotion	f	cme57bm9600062bcqtlkj9wcx	2025-11-18 07:59:49.88
cmi4adlny000pxkf980pzbl17	New promotion request submitted by Hassan Juma Msangi (cmi4adlnq000nxkf9v2xdtmjw). Requires your review.	/dashboard/promotion	f	cme57api100042bcqhbkg91r8	2025-11-18 08:03:07.63
cmi4adlo1000qxkf9i1rc02vq	New promotion request submitted by Hassan Juma Msangi (cmi4adlnq000nxkf9v2xdtmjw). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-11-18 08:03:07.634
cmi4adlo1000rxkf9lx44sxc4	New promotion request submitted by Hassan Juma Msangi (cmi4adlnq000nxkf9v2xdtmjw). Requires your review.	/dashboard/promotion	f	cme57bm9600062bcqtlkj9wcx	2025-11-18 08:03:07.634
cmi4sopsd0003xkxncpw09a43	New promotion request submitted by Muuguzi Omar Bakari Said (cmi4sopry0001xkxnaparmumn). Requires your review.	/dashboard/promotion	f	cme57api100042bcqhbkg91r8	2025-11-18 16:35:39.277
cmi4sopsi0004xkxnsgxdtm0m	New promotion request submitted by Muuguzi Omar Bakari Said (cmi4sopry0001xkxnaparmumn). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-11-18 16:35:39.282
cmi4sopsi0005xkxn3fd43fkd	New promotion request submitted by Muuguzi Omar Bakari Said (cmi4sopry0001xkxnaparmumn). Requires your review.	/dashboard/promotion	f	cme57bm9600062bcqtlkj9wcx	2025-11-18 16:35:39.282
cme36e7sq00052basq1uc58sq	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: Awaiting More Information.	/dashboard/complaints	t	cmd06nnbz000ve67wncnv4etg	2025-08-08 18:45:02.331
cme36g4cm00072basdpajx0cg	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: Under Review - Additional Information Provided.	/dashboard/complaints	t	cmd06nnbz000ve67wncnv4etg	2025-08-08 18:46:31.174
cme36iop300092basxx6jsbh8	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: Resolved - Pending Employee Confirmation.	/dashboard/complaints	t	cmd06nnbz000ve67wncnv4etg	2025-08-08 18:48:30.855
cme36j4k2000b2bas4qfo5iy2	Your complaint "tunafanya kazi katika mazingira hatarishi" has been updated to: Mtumishi ameridhika na hatua.	/dashboard/complaints	t	cmd06nnbz000ve67wncnv4etg	2025-08-08 18:48:51.41
80efd307-a5c2-4cad-ada0-9c77a5891495	New leave without pay request submitted by MOZA MASSOUD AMOUR (83bf51e4-7240-47fd-ae90-ccef8884779b). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-26 14:15:53.744
f6a133c1-21e1-4647-9dee-a170b843fcc4	New leave without pay request submitted by MOZA MASSOUD AMOUR (83bf51e4-7240-47fd-ae90-ccef8884779b). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-26 14:15:53.75
ac369056-7428-4365-add3-7a023994439e	New leave without pay request submitted by MOZA MASSOUD AMOUR (83bf51e4-7240-47fd-ae90-ccef8884779b). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-26 14:15:53.75
41ca8cc6-b8d8-431c-a759-b1bf6cd7b872	New leave without pay request submitted by Rahma Shaali Mwadini (542b851c-bc8f-48fc-a923-aaa7a773c5e8). Requires your review.	/dashboard/lwop	f	cme57api100042bcqhbkg91r8	2025-11-26 17:50:53.896
96b98788-5948-4e21-a6f8-90959cf9f58b	New leave without pay request submitted by Rahma Shaali Mwadini (542b851c-bc8f-48fc-a923-aaa7a773c5e8). Requires your review.	/dashboard/lwop	f	cmd06nnbd000de67wb6e6ild5	2025-11-26 17:50:53.901
feb049d1-7a49-40c4-96d8-c97003c78e3d	New leave without pay request submitted by Rahma Shaali Mwadini (542b851c-bc8f-48fc-a923-aaa7a773c5e8). Requires your review.	/dashboard/lwop	f	cme57bm9600062bcqtlkj9wcx	2025-11-26 17:50:53.901
ef31e8a5-f375-4816-bf70-4f32843b6f1e	New promotion request submitted by Rahma Shaali Mwadini (9f4e6a1b-00e0-42f5-ab2f-7ac210b503ff). Requires your review.	/dashboard/promotion	f	cme57api100042bcqhbkg91r8	2025-11-26 18:11:33.617
374a4bf7-aa83-455f-b737-3f58ec9fd69f	New promotion request submitted by Rahma Shaali Mwadini (9f4e6a1b-00e0-42f5-ab2f-7ac210b503ff). Requires your review.	/dashboard/promotion	f	cmd06nnbd000de67wb6e6ild5	2025-11-26 18:11:33.621
6ed9e8dc-6b5b-4ab0-947a-212d53cd6670	New promotion request submitted by Rahma Shaali Mwadini (9f4e6a1b-00e0-42f5-ab2f-7ac210b503ff). Requires your review.	/dashboard/promotion	f	cme57bm9600062bcqtlkj9wcx	2025-11-26 18:11:33.621
6a1da561-e236-4737-8e09-5b380ffd1e8d	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	f	emp_9298ec5cbab08d539af662de255c8203	2025-11-27 02:53:04.86
02a690cc-be5d-4bab-9bc4-27aaf0c1b057	Lalamiko jipya limewasilishwa na Rashid Omar Salum (917582c3-5267-432a-9b93-fbde9759e9da): "nimechelewa kupandishwa daraja ". Inahitaji ukaguzi wako.	/dashboard/complaints	f	cmd06nnbd000de67wb6e6ild5	2025-12-01 08:56:53.222
455ede5f-6ccf-458a-aef3-af78cd20ad97	Lalamiko jipya limewasilishwa na Rashid Omar Salum (917582c3-5267-432a-9b93-fbde9759e9da): "nimechelewa kupandishwa daraja ". Inahitaji ukaguzi wako.	/dashboard/complaints	f	cme57bm9600062bcqtlkj9wcx	2025-12-01 08:56:53.222
bcc4b4fe-fc0c-47c6-a588-f0a7d21522c8	Lalamiko jipya limewasilishwa na Rashid Omar Salum (917582c3-5267-432a-9b93-fbde9759e9da): "nimechelewa kupandishwa daraja ". Inahitaji ukaguzi wako.	/dashboard/complaints	f	cme57api100042bcqhbkg91r8	2025-12-01 08:56:53.226
cmgqawlr50002xk849c625ur7	New leave without pay request submitted by Maryam Said Kombo (cmgqawlqy0001xk841u18fdx4). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-10-14 08:29:25.409
cmgqaytpl0008xk84gi2y6sbj	New promotion request submitted by Maryam Said Kombo (cmgqaytpf0007xk84b1jg4eq0). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-10-14 08:31:09.033
cmgqazpf2000exk84pdratfdq	New promotion request submitted by Maryam Said Kombo (cmgqazpex000dxk84vw8jufey). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-10-14 08:31:50.126
cmhu8nk300002xk0sbgns3rx8	New leave without pay request submitted by Ali Juma Ali (cmhu8nk2m0001xk0ssf3c5haa). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-11 07:17:11.148
cmhu8u2lk0008xk0sne9yv60g	New leave without pay request submitted by Hassan Juma Msangi (cmhu8u2lc0007xk0srdfz7zcb). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-11 07:22:15.08
cmhu8xpcl000exk0sezb5ezsq	New leave without pay request submitted by Mwajuma Abdallah Mtumwa (cmhu8xpcf000dxk0slw9hs7vq). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-11 07:25:04.534
cmhu9q81o000kxk0scckr9cd8	New leave without pay request submitted by John Peter Mwalimu (cmhu9q81h000jxk0sm8o2ujt7). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-11 07:47:15.133
cmhua1kjx000qxk0sv9u35x2y	New leave without pay request submitted by Rashid Omar Salum (cmhua1kjl000pxk0svme1dgvb). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-11 07:56:04.557
cmhuauffo0002xkf9m5bk9wv2	New leave without pay request submitted by Zaina Mohamed Bakari (cmhuauffc0001xkf9uym34tad). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-11 08:18:30.948
cmi49xzrg000cxkf9l33r2nk2	New leave without pay request submitted by Khamis Bakari Mfalme (cmi49xzr9000bxkf9pfl1jtdm). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-18 07:50:59.405
cmi4a9d2s000ixkf9sptr49li	New promotion request submitted by Hassan Juma Msangi (cmi4a9d2l000hxkf9dp2zs7c9). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-11-18 07:59:49.877
cmi4adlny000oxkf9wwquidxj	New promotion request submitted by Hassan Juma Msangi (cmi4adlnq000nxkf9v2xdtmjw). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-11-18 08:03:07.63
cmi4sopsd0002xkxn9z2uwjbh	New promotion request submitted by Muuguzi Omar Bakari Said (cmi4sopry0001xkxnaparmumn). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-11-18 16:35:39.277
8f3297b4-7d56-428b-83a7-6927d1afe735	New leave without pay request submitted by MOZA MASSOUD AMOUR (83bf51e4-7240-47fd-ae90-ccef8884779b). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-26 14:15:53.744
7676b727-b845-4cc2-bd66-c7131f892283	New leave without pay request submitted by Rahma Shaali Mwadini (542b851c-bc8f-48fc-a923-aaa7a773c5e8). Requires your review.	/dashboard/lwop	t	cmd059ir10002e6d86l802ljc	2025-11-26 17:50:53.896
f10a485b-0354-45b3-afdd-4534db54d143	New promotion request submitted by Rahma Shaali Mwadini (9f4e6a1b-00e0-42f5-ab2f-7ac210b503ff). Requires your review.	/dashboard/promotion	t	cmd059ir10002e6d86l802ljc	2025-11-26 18:11:33.617
bdbea190-b42c-459d-ab6a-9a41bb1493ab	Lalamiko jipya limewasilishwa na Rashid Omar Salum (917582c3-5267-432a-9b93-fbde9759e9da): "nimechelewa kupandishwa daraja ". Inahitaji ukaguzi wako.	/dashboard/complaints	t	cmd059ir10002e6d86l802ljc	2025-12-01 08:56:53.226
be975fda-d14d-41ad-9f2a-6514622800f7	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	42635a13-283a-48eb-9752-752bbda196b9	2025-12-03 12:21:36.583
57e9a774-b730-4c07-9274-72215bfb6aed	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	f	f965a775-0572-4469-aab3-ad1d0f7e2032	2025-12-03 12:43:54.947
7d560ecb-27fe-4370-97d6-4e52ae73daf9	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	7011a404-7ebc-4c2d-96dd-807a073b5911	2025-12-03 13:04:40.1
6d941a05-a68a-4e5f-8707-7f0999789f84	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	33e358d2-1820-415d-abab-3213926e2096	2025-12-03 14:32:12.778
7c3b6edc-d94b-451a-9ff8-cea2eb803f13	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	f	d7e938ff-71f8-41fd-b954-cd840855049a	2025-12-04 06:56:05.071
17ade150-b9a0-45e1-9dac-eb1eda1c1a36	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	f	69b8c30e-ffab-466c-8c86-6e6d1c1ff4ee	2025-12-04 07:11:24.066
27b35927-e098-4b81-9296-410438b157d8	Welcome to the Civil Service Management System (CSMS). This system will help you manage your employment requests.	/dashboard	t	5382cf01-9b4e-4dbc-833b-ec88a02e49b4	2025-12-03 16:13:06.847
\.


--
-- Data for Name: PromotionRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PromotionRequest" (id, status, "reviewStage", "proposedCadre", "promotionType", "studiedOutsideCountry", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt", "commissionDecisionReason") FROM stdin;
cmd08neh4000he6qkbpsewsvw	APPROVED	COMMISSION_REVIEW	Education Officer	EducationAdvancement	f	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp8	cmd06nnbz000ve67wncnv4etg	\N	2025-06-22 12:45:09.255	2025-06-13 12:45:09.255	\N
cmd08neh6000je6qkinyddcfc	UNDER_REVIEW	COMMISSION_REVIEW	Education Officer	EducationAdvancement	f	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp1	cmd06nnbx000te67ww4cbaug7	cmd06nnbn000le67wtg41s3su	2025-05-30 12:45:09.258	2025-06-25 12:45:09.258	\N
cmd08neh8000le6qkplwwgysk	UNDER_REVIEW	HR_REVIEW	Senior Administrative Officer	Experience	\N	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp1	cmd06nnbu000re67wdeax0fwp	cmd06nnb50007e67wa5491lw5	2025-02-02 12:45:09.26	2025-07-07 12:45:09.26	\N
cmd08neha000ne6qk3rgcyayt	REJECTED	COMMISSION_REVIEW	Education Officer	Experience	\N	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	Does not meet minimum experience requirements	emp1	cmd06nnbx000te67ww4cbaug7	cmd06nnb50007e67wa5491lw5	2025-03-22 12:45:09.262	2025-07-10 12:45:09.262	\N
cmd08nehc000pe6qkqewkapax	PENDING	INITIAL	Senior Education Officer	EducationAdvancement	f	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp9	cmd06nnbx000te67ww4cbaug7	\N	2025-01-10 12:45:09.264	2025-06-20 12:45:09.264	\N
cmd08nehf000re6qkmx0hg1vs	APPROVED	FINAL_APPROVAL	Administrative Officer	Experience	\N	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp8	cmd06nnbu000re67wdeax0fwp	cmd06nnbq000ne67wwmiwxuo8	2025-04-01 12:45:09.266	2025-06-28 12:45:09.266	\N
cmd08nehj000te6qky2c8qhyl	APPROVED	HR_REVIEW	Principal Administrative Officer	EducationAdvancement	t	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp9	cmd06nnbz000ve67wncnv4etg	cmd06nnbn000le67wtg41s3su	2025-05-05 12:45:09.271	2025-07-04 12:45:09.271	\N
cmd08nehm000ve6qk51oyijxo	APPROVED	INITIAL	Senior Administrative Officer	EducationAdvancement	t	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp8	cmd06nnbx000te67ww4cbaug7	cmd06nnbn000le67wtg41s3su	2025-01-24 12:45:09.273	2025-07-04 12:45:09.273	\N
cmd08neho000xe6qkoir8piid	PENDING	COMMISSION_REVIEW	Principal Administrative Officer	EducationAdvancement	f	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	\N	emp9	cmd06nnbu000re67wdeax0fwp	\N	2025-01-26 12:45:09.276	2025-07-11 12:45:09.276	\N
cmd08nehq000ze6qk2jhu7giy	REJECTED	FINAL_APPROVAL	Senior Administrative Officer	EducationAdvancement	t	{https://placehold.co/promotion-application.pdf,https://placehold.co/certificates.pdf,https://placehold.co/performance-evaluation.pdf}	Does not meet minimum experience requirements	emp1	cmd06nnbu000re67wdeax0fwp	cmd059ir10002e6d86l802ljc	2025-01-01 12:45:09.278	2025-06-14 12:45:09.278	\N
cmd0xp0h80001e6j41vq5b8z3	Approved by Commission	completed	Grade 1	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_002	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-13 00:26:14.828	2025-07-13 00:26:59.15	\N
cmd1hhwy40003e6yudjugtg2c	Pending HRMO Review	initial	Afisa Mkuu Daraja la II	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_033	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-13 09:40:35.98	2025-07-13 09:59:25.111	\N
cmd0wqoye0001e6xfhxw3i2po	Approved by Commission	completed	Senior Manager	Experience	\N	{performance-appraisal-y1.pdf,performance-appraisal-y2.pdf,performance-appraisal-y3.pdf,csc-form.pdf,letter-of-request.pdf}	\N	emp8	cmd06nnbl000je67wtl28pk42	cmd059ir10002e6d86l802ljc	2025-07-12 23:59:33.59	2025-07-13 00:27:44.997	\N
cmd0wc5vh0003e6m4xfwzv41c	Approved by Commission	completed	daraja la 2	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_002	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-12 23:48:15.677	2025-07-12 23:51:30.437	\N
cmd1gw8jp0001e6yu3jk0u6ok	Approved by Commission	completed	Afisa Muandamizi	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_004	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-13 09:23:44.57	2025-07-13 09:32:26.999	\N
cmd4c9jd20001e6tc8gu4hzfk	Rejected by Commission	completed	Afisa Muandamizi	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	umekosea kuweka document sahihi 	emp_001	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-15 09:37:25.574	2025-07-15 10:55:29.104	\N
cmd1ibta10005e6yu6mvfoxr0	Rejected by Commission	completed	Afisa Mkuu Daraja la I	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-13 10:03:50.905	2025-07-13 11:07:41.459	\N
cmd4edi1k0001e6gpvy0exb17	Approved by Commission	completed	Afisa Mkuu Daraja la II	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_006	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-15 10:36:29.72	2025-07-15 10:56:37.132	\N
cmd5qh4xz00052btwsc4wp1ch	Approved by Commission	completed	Muhudumu daraja la II	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_002	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-16 09:03:00.934	2025-07-16 09:26:36.642	\N
cmd5ro8jy00072btwyj24lefo	Approved by Commission	completed	Muhudumu daraja la II	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_002	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-16 09:36:31.822	2025-07-16 09:46:49.159	\N
cmd5rvrk300092btwl0wi5471	Approved by Commission	completed	daraja la II	Experience	\N	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_020	cmd06nnbl000je67wtl28pk42	cmd059ir10002e6d86l802ljc	2025-07-16 09:42:23.042	2025-07-16 09:46:42.103	\N
cmdbg8ixw0001e6acwpxxoljc	Draft - Pending Review	HRO Review	Afisa Muandamizi	Experience	f	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_006	cmd06nnbn000le67wtg41s3su	\N	2025-07-20 09:03:00.067	2025-07-20 09:03:00.067	\N
cmddazj020005e67k238btjy0	Draft - Pending Review	HRO Review	Afisa Muandamizi	Experience	f	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_006	cmd06nnbn000le67wtg41s3su	\N	2025-07-21 16:11:34.514	2025-07-21 16:11:34.514	\N
cmddbigkx0007e67kctnbe35k	Approved by Commission	completed	daraja la 2	Experience	f	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	ofisi_emp_008	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-21 16:26:17.841	2025-07-21 16:37:32.736	ombi limekubaliwa
cmde3bpgq0005e6jop6vocgzw	Approved by Commission	completed	Afisa Mkuu Daraja la I	Experience	f	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_001	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-22 05:24:52.009	2025-07-22 05:27:19.177	amekubaliwa na tume
cmde3noh20007e6jot1wnox0m	Pending HRMO/HHRMD Review	initial	Afisa Muandamizi	Experience	f	{"Letter of Request","Performance Appraisal (Y1)","Performance Appraisal (Y2)","Performance Appraisal (Y3)","CSC Promotion Form"}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-07-22 05:34:10.598	2025-07-22 05:34:10.598	\N
cmdieh2ox0007e6rwbuwwewy6	Pending HRMO/HHRMD Review	initial	Afisa Mkuu Daraja la II	Experience	f	{promotion/letters/20250725_084801_1f7f3e0d.pdf,promotion/performance-appraisals/20250725_084749_9d2bb5c0.pdf,promotion/performance-appraisals/20250725_084752_d88f5862.pdf,promotion/performance-appraisals/20250725_084755_27d245db.pdf,promotion/csc-forms/20250725_084758_ee2bca45.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 05:48:02.913	2025-07-25 05:48:02.913	\N
cmdy7vw1y00092bd8yq0ehmq2	Pending HRMO/HHRMD Review	initial	Afisa Hesabu Mkuu daraja la I	Experience	f	{promotion/letters/1754378869208_sg3nv8_ripoti_ya_kustaafu_kwa_hiari_report.pdf,promotion/performance-appraisals/1754378838914_on06vn_ripoti_ya_kupandishwa_cheo_report.pdf,promotion/performance-appraisals/1754378839575_kx3f4o_ripoti_ya_likizo_bila_malipo_report.pdf,promotion/performance-appraisals/1754378863903_2scjih_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf,promotion/csc-forms/1754378869061_bkb9wi_ripoti_ya_kustaafu_kwa_hiari_report.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-08-05 07:27:55.622	2025-08-05 07:27:55.622	\N
cmdymbuym00032bghh6eo28ja	Pending HRMO/HHRMD Review	initial		EducationAdvancement	f	{promotion/letters/1754403133334_0koo3s_sababu.pdf,promotion/certificates/1754403129220_bq91hk_Employee_Profile_Analysis.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-08-05 14:12:15.358	2025-08-05 14:12:15.358	\N
cmdys0peu00012bdng16iaf2c	Pending HRMO/HHRMD Review	initial		EducationAdvancement	f	{promotion/letters/1754412689895_yd9rdy_sababu.pdf,promotion/certificates/1754412680917_nlvnev_Employee_Profile_Analysis.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-08-05 16:51:32.646	2025-08-05 16:51:32.646	\N
cmdymhs0n00052bgh1yx3x8as	Pending HRMO/HHRMD Review	initial	senior officer grade II	EducationAdvancement	f	{promotion/letters/1754405348803_1fevx3_mfano.pdf}	\N	emp_006	cmd06nnbn000le67wtg41s3su	cmd06nnbn000le67wtg41s3su	2025-08-05 14:16:51.478	2025-08-05 14:49:21.444	\N
cmdyf42zy000h2b41v5humh4r	Request Received – Awaiting Commission Decision	commission_review	Afisa Mkuu Daraja la VI	Experience	f	{promotion/letters/1754391261539_8wk5l9_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf,promotion/performance-appraisals/1754391243219_fhpuzr_ya_kuacha_kazi_report.pdf,promotion/performance-appraisals/1754391246376_pikn6t_1754384852415_9af7qo_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf,promotion/performance-appraisals/1754391249184_4dphvo_ya_kuacha_kazi_report.pdf,promotion/csc-forms/1754391257921_7xbd61_1754386247723_17ukwm_ripoti_ya_kuacha_kazi_report.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-08-05 10:50:15.214	2025-08-05 11:10:01.454	daraja la VIII
cmdymalck00012bgh9yppnjw1	Pending HRMO/HHRMD Review	initial		EducationAdvancement	f	{promotion/letters/1754402810374_0xpvw6_Employee_Profile_Analysis.pdf,promotion/certificates/1754402800552_8un9ye_mfano.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-08-05 14:11:16.244	2025-08-05 14:11:16.244	\N
cmdzlc88c00012bgqqs31thc3	Approved by Commission	completed		EducationAdvancement	t	{promotion/letters/1754461930733_mwheg6_ya_kuacha_kazi_report.pdf,promotion/certificates/1754461927501_1aa62t_ripoti_ya_kuacha_kazi_report.pdf,promotion/tcu-forms/1754461936307_d8x94h_ripoti_ya_kuacha_kazi_report.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-06 06:32:19.114	2025-08-06 06:33:39.477	kakubaliwa
cmdyo8h6900012bfivk1fhgu3	Approved by Commission	completed	Afisa Mkuu daraja la II	EducationAdvancement	t	{promotion/letters/1754407244845_u7lok7_mfano.pdf,promotion/certificates/1754407241090_a6o5nt_cheti.pdf,promotion/tcu-forms/1754407254984_s8khof_sababu.pdf}	\N	emp_004	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 15:05:36.753	2025-08-05 15:22:50.011	amekubaliwa
cmdzlpilt00032bgqs9fn8ami	Pending HRMO/HHRMD Review	initial	Grade IV	Experience	f	{promotion/letters/1754462556325_moxl5v_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf,promotion/performance-appraisals/1754462518565_k4hxb5_ripoti_ya_likizo_bila_malipo_report.pdf,promotion/performance-appraisals/1754462523647_k360cj_ya_kuacha_kazi_report.pdf,promotion/performance-appraisals/1754462528719_plakme_ripoti_ya_kupandishwa_cheo_report.pdf,promotion/csc-forms/1754462553076_6z94h0_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-08-06 06:42:39.09	2025-08-06 06:42:39.09	\N
cmdzlq44100052bgq2q8o7z46	Pending HRMO/HHRMD Review	initial		EducationAdvancement	t	{promotion/letters/1754462578890_p3xjr8_ya_kuacha_kazi_report.pdf,promotion/certificates/1754462575191_c9whhw_ripoti_ya_kuacha_kazi_report.pdf,promotion/tcu-forms/1754462583939_rsfqlc_ripoti_ya_kustaafu_kwa_hiari_report.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-08-06 06:43:06.961	2025-08-06 06:43:06.961	\N
cmdytdro300012b7kjj9yuuln	Approved by Commission	completed		EducationAdvancement	f	{promotion/letters/1754414128269_suj0o5_mfano.pdf,promotion/certificates/1754414119925_i94dxr_mfano.pdf}	\N	emp_006	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 17:29:41.716	2025-08-06 06:33:55.049	kakubaliwa
cme4jvdnb000j2btj777rf0xk	Approved by Commission	completed	Afisa Mkuu Daraja la II	Experience	f	{promotion/letters/1754761802267_t0rn80_ripoti_ya_kupandishwa_cheo_report__1_.pdf,promotion/performance-appraisals/1754761786871_3ml15t_1754407554728_bj7hik_sababu.pdf,promotion/performance-appraisals/1754761789629_r9sxrm_1754676807327_mfbgv3_ripoti_ya_kupandishwa_cheo_report__2_.pdf,promotion/performance-appraisals/1754761793018_ikdugv_20250802_081604_d8a23939.pdf,promotion/csc-forms/1754761798763_1rct2d_20250802_094101_02331ce1.pdf}	\N	cme45oe31000l2bfw2kzug3tj	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-09 17:50:04.247	2025-08-10 12:51:38.948	umekubaliwa
cmi4sopry0001xkxnaparmumn	Pending HRMO/HHRMD Review	initial	Mtaalamu wa upasuaji Daraja la II	Experience	f	{promotion/letters/1763483707465_gd4i8c_20250725_160611_81b8b571.pdf,promotion/performance-appraisals/1763483701319_pzrt3y_proxmox-setup-guide_single_10gbps_port.pdf,promotion/performance-appraisals/1763483698991_bnml6k_Mozilla-Recovery-Key_2025-07-12_yussufrajab_gmail.com.pdf,promotion/performance-appraisals/1763483726735_gsn2yu_architecture_comparison.pdf,promotion/csc-forms/1763483701315_pwtkkb_ripoti_ya_nyongeza_ya_utumishi_report.pdf}	\N	cme45oe3h000t2bfw72unecxi	cme471pqo00032bidhttxmboj	\N	2025-11-18 16:35:39.262	2025-11-18 16:35:39.262	\N
9f4e6a1b-00e0-42f5-ab2f-7ac210b503ff	Pending HRMO/HHRMD Review	initial	Afisa tawala daraja la II	Experience	f	{promotion/letters/1764180690501_rtmu88_20250727_072131_627b1cda.pdf,promotion/performance-appraisals/1764180669335_6jifb7_ripoti_ya_kupandishwa_cheo_report.pdf,promotion/performance-appraisals/1764180676689_xx5eks_ripoti_ya_nyongeza_ya_utumishi_report.pdf,promotion/performance-appraisals/1764180679245_aqk85w_20250802_081604_d8a23939.pdf,promotion/csc-forms/1764180685051_0zi8na_status.pdf}	\N	1abb6d7d-3816-421c-ac6e-48ccf04bf66e	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:11:33.607	2025-11-26 18:11:33.606	\N
\.


--
-- Data for Name: ResignationRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ResignationRequest" (id, status, "reviewStage", "effectiveDate", reason, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
cmd08neir001ve6qkwtv3he8d	UNDER_REVIEW	HR_REVIEW	2025-10-26 12:45:09.314	Better opportunity	{https://placehold.co/resignation-letter.pdf,https://placehold.co/handover-plan.pdf}	\N	emp8	cmd06nnbu000re67wdeax0fwp	cmd06nnbn000le67wtg41s3su	2025-07-10 12:45:09.314	2025-07-07 12:45:09.314
cmd08neit001xe6qkt6mh4rha	APPROVED	DIRECTOR_REVIEW	2025-10-20 12:45:09.317	Better opportunity	{https://placehold.co/resignation-letter.pdf,https://placehold.co/handover-plan.pdf}	\N	emp9	cmd06nnbu000re67wdeax0fwp	cmd059ir10002e6d86l802ljc	2025-07-11 12:45:09.317	2025-06-26 12:45:09.317
cmd08neiw001ze6qkxdo0hjsz	APPROVED	FINAL_APPROVAL	2025-08-22 12:45:09.319	Relocation	{https://placehold.co/resignation-letter.pdf,https://placehold.co/handover-plan.pdf}	\N	emp8	cmd06nnbx000te67ww4cbaug7	\N	2025-06-29 12:45:09.319	2025-06-27 12:45:09.319
cmd4kah670003e609jq4fhj7l	Rejected by Commission	completed	2025-07-31 00:00:00	hataki kazi	{"Letter of Request","3 Month Notice/Receipt"}	\N	emp_001	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-15 13:22:06.32	2025-07-15 13:26:31.535
cmd8k4o6s004r2bgty2fconfm	Approved by Commission	completed	2025-07-25 00:00:00	Amepata kazi nje ya nchi	{"Letter of Request","3 Month Notice/Receipt"}	\N	emp_005	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-18 08:28:40.179	2025-07-18 08:36:52.27
cmd8khiaz004z2bgt6pbfmc0g	Rejected by Commission	completed	2025-08-02 00:00:00	sdfdhhgffffff	{"Letter of Request","3 Month Notice/Receipt"}	\N	emp_002	cmd06nnbl000je67wtl28pk42	cmd06nnbb000be67wwgil78yv	2025-07-18 08:38:39.083	2025-07-18 08:39:21.955
cmddfihpu000ne67kmzio1x14	Rejected by HHRMD - Awaiting HRO Action	initial	2025-07-24 00:00:00	hataki kazi	{"Letter of Request","3 Month Notice/Receipt"}	hujaeka  ddocument . nasema 	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 18:18:17.778	2025-07-22 21:35:31.624
cmdf2n6i60003e6lonqa65v28	Rejected by Commission - Request Concluded	completed	2025-08-09 00:00:00	sawaa	{"Letter of Request","3 Month Notice/Receipt"}	\N	ofisi_emp_018	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 21:53:33.87	2025-07-22 21:54:18.579
cmdf1sjya0001e6ikkxd4343h	Forwarded to Commission for Acknowledgment	commission_review	2025-07-31 00:00:00	hataki kazi	{"Letter of Request","3 Month Notice/Receipt"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 21:29:44.962	2025-07-22 21:36:01.726
cmdbgqsj20009e6ac5yegqa2o	Forwarded to Commission for Acknowledgment	commission_review	2025-07-25 00:00:00	kazi basi	{"Letter of Request","3 Month Notice/Receipt"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-20 09:17:12.302	2025-07-22 21:36:24.593
cmdbgiji10007e6acgxt50iln	Forwarded to Commission for Acknowledgment	commission_review	2025-07-31 00:00:00	kazi basi	{"Letter of Request","3 Month Notice/Receipt"}	\N	emp_006	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-20 09:10:47.353	2025-07-22 21:37:48.018
cmd1y4a2z0007e60yqt4rschk	Forwarded to Commission for Acknowledgment	commission_review	2025-08-01 00:00:00	\N	{"Letter of Request","3 Month Notice/Receipt"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-13 17:25:53.291	2025-07-22 21:37:55.217
cmd1xkh870005e60yqmzidokb	Forwarded to Commission for Acknowledgment	commission_review	2025-07-26 00:00:00	amechoka kazi	{"Letter of Request","3 Month Notice/Receipt"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-13 17:10:29.432	2025-07-22 21:38:02.352
cmdhorx9n0003e65kmuh4fx62	Pending HRMO/HHRMD Review	initial	2025-07-26 00:00:00	sawaa	{"Letter of Request","3 Month Notice/Receipt"}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 17:48:39.083	2025-07-24 17:48:39.083
cmdifp4o7000fe6rwvhqv56u8	Pending HRMO/HHRMD Review	initial	2025-08-09 00:00:00	rrr	{resignation/20250725_092210_c6cd62da.pdf,resignation/20250725_092216_fe824371.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 06:22:18.343	2025-07-25 06:22:18.343
cmdifvrnx000he6rwr80qytt5	Pending HRMO/HHRMD Review	initial	2025-08-08 00:00:00	ggfff	{resignation/20250725_092722_93a4e0d6.pdf,resignation/20250725_092725_77cb9ea9.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 06:27:28.078	2025-07-25 06:27:28.078
cmdf2cimc0001e6loca2rnb5l	Approved by Commission	completed	2025-08-08 00:00:00	kazi basi	{"Letter of Request","3 Month Notice/Receipt"}	\N	ofisi_emp_004	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 21:45:16.356	2025-07-22 21:51:52.325
cmdig1e3x000je6rwu3bfjl8t	Pending HRMO/HHRMD Review	initial	2025-08-01 00:00:00	sdfsdf	{resignation/20250725_093141_805b88ea.pdf,resignation/20250725_093147_a4863740.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 06:31:50.445	2025-07-25 06:31:50.445
cmdis9twz0005e6z0fm8eeuj7	Pending HRMO/HHRMD Review	initial	2025-08-08 00:00:00	sidfjsdf fdf sdfsdfsd fsd fds fsdf	{resignation/20250725_151413_ae98547e.pdf,resignation/20250725_151416_ca9a6ec9.pdf}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 12:14:19.572	2025-07-25 12:14:19.572
cmdisigwk0007e6z0vus4r8zy	Pending HRMO/HHRMD Review	initial	2025-08-08 00:00:00	safs ffef  fe	{resignation/20250725_152055_e3963333.pdf,resignation/20250725_152059_f97cc54a.pdf}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 12:21:02.612	2025-07-25 12:21:02.612
cme4jzxlx000r2btj9u9sutxw	Approved by Commission	completed	2025-08-22 00:00:00	kuchoka	{resignation/1754761973300_lgjc3l_20250802_094101_02331ce1.pdf,resignation/1754761978374_7j7ch5_20250727_075904_4497516f__1_.pdf}	\N	cme45oe31000l2bfw2kzug3tj	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-09 17:53:36.741	2025-08-10 13:25:16.713
cmdybtsl000052b417qqm83s5	Approved by Commission	completed	2025-08-06 00:00:00	kaacha kazi sasa	{resignation/1754385630327_pu3pqn_ripoti_ya_kupandishwa_cheo_report.pdf,resignation/1754385636454_p9y5vr_ripoti_ya_kustaafu_kwa_ugonjwa_report.pdf}	\N	emp_006	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 09:18:16.307	2025-08-05 09:22:59.78
cmgp2kk670001xks4yj14gzj9	Pending HRMO/HHRMD Review	initial	2038-04-03 00:00:00	amepata shughuli nyengine	{resignation/1760355968744_8z0cbm_proxmox9-setup-guide_with_4MVs.pdf,resignation/1760355989416_r6nuhi_status.pdf}	\N	ofisi_emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-10-13 11:48:20.383	2025-10-13 11:48:20.383
e36e37a7-a0ad-4e97-8839-3859e445d6e8	Pending HRMO/HHRMD Review	initial	2025-12-07 00:00:00	kupumzika	{resignation/1764181918947_4hojlx_ripoti_ya_nyongeza_ya_utumishi_report.pdf,resignation/1764181928212_am4szp_20250725_071305_7f9eb5d3__2_.pdf}	\N	cme45oe2m000d2bfwd3agas2u	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:32:12.466	2025-11-26 18:32:12.464
\.


--
-- Data for Name: RetirementRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RetirementRequest" (id, status, "reviewStage", "retirementType", "illnessDescription", "proposedDate", "delayReason", documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
cmd08neih001ne6qkhk4nrulr	PENDING	INITIAL	illness	Chronic medical condition affecting work performance	2026-05-29 12:45:09.304	\N	{https://placehold.co/retirement-application.pdf,https://placehold.co/medical-report.pdf}	\N	emp8	cmd06nnbx000te67ww4cbaug7	cmd06nnbn000le67wtg41s3su	2025-05-14 12:45:09.304	2025-07-01 12:45:09.304
cmd08neik001pe6qk9h3bcyji	REJECTED	INITIAL	compulsory	\N	2025-09-02 12:45:09.308	\N	{https://placehold.co/retirement-application.pdf,https://placehold.co/service-record.pdf}	Retirement date does not meet service requirements	emp9	cmd06nnbx000te67ww4cbaug7	\N	2025-06-13 12:45:09.308	2025-07-11 12:45:09.308
cmd08neim001re6qkuubvcrzy	PENDING	FINAL_APPROVAL	compulsory	\N	2025-08-29 12:45:09.31	\N	{https://placehold.co/retirement-application.pdf,https://placehold.co/service-record.pdf}	\N	emp9	cmd06nnbz000ve67wncnv4etg	\N	2025-05-22 12:45:09.31	2025-06-23 12:45:09.31
cmd08neio001te6qkvci4itnj	REJECTED	INITIAL	illness	Chronic medical condition affecting work performance	2026-04-21 12:45:09.312	\N	{https://placehold.co/retirement-application.pdf,https://placehold.co/medical-report.pdf}	Retirement date does not meet service requirements	emp1	cmd06nnbz000ve67wncnv4etg	cmd06nnbq000ne67wwmiwxuo8	2025-07-07 12:45:09.312	2025-06-23 12:45:09.312
cmd1wvn0d0001e6jfo0kn9zbe	Pending HRMO Review	initial	compulsory	\N	2046-10-08 00:00:00	\N	{"Letter of Request","Birth Certificate Copy (or equivalent)"}	\N	emp_004	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 16:51:10.525	2025-07-13 16:51:10.525
cmd1xggf30001e60yfrzv82fj	Pending HRMO/HHRMD Review	initial	voluntary	\N	2042-08-13 00:00:00	\N	{"Letter of Request","Service Record Summary"}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 17:07:21.76	2025-07-13 17:07:21.76
cmd1xinoe0003e60yjd1svxu0	Pending HRMO/HHRMD Review	initial	illness	ugonjwa wa stroke	2027-06-18 00:00:00	\N	{"Letter of Request","Medical Form","Leave Due to Illness Letter"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 17:09:04.479	2025-07-13 17:09:04.479
cmd4k2k5g0001e6097aq1c9uk	Approved by Commission	completed	compulsory	\N	2049-06-09 00:00:00	alipata uteuzi	{"Letter of Request","Delay Document"}	\N	emp_001	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-07-15 13:15:56.932	2025-07-15 14:45:08.916
cmd8icsly003b2bgtotgbbrh7	Pending HRMO/HHRMD Review	initial	compulsory	\N	2031-11-10 00:00:00	\N	{"Letter of Request","Birth Certificate Copy (or equivalent)"}	\N	emp_022	cmd06nnbl000je67wtl28pk42	\N	2025-07-18 07:38:59.927	2025-07-18 07:38:59.927
cmd8if8gu003d2bgt6w80nimo	Approved by Commission	completed	compulsory	\N	2039-05-18 00:00:00	\N	{"Letter of Request","Birth Certificate Copy (or equivalent)"}	\N	emp_019	cmd06nnbl000je67wtl28pk42	cmd059ir10002e6d86l802ljc	2025-07-18 07:40:53.79	2025-07-18 07:58:02.393
cmd8igazj003f2bgtabwi5ctu	Rejected by Commission	completed	voluntary	\N	2033-06-18 00:00:00	\N	{"Letter of Request"}	\N	emp_019	cmd06nnbl000je67wtl28pk42	cmd06nnbb000be67wwgil78yv	2025-07-18 07:41:43.711	2025-07-18 07:55:06.048
cmd8j8kw3004j2bgtxdw7mn9v	Pending HHRMD Review	HHRMD_review	illness	Strock	2026-01-31 00:00:00	\N	{"Letter of Request","Medical Form","Leave Due to Illness Letter"}	\N	emp_020	cmd06nnbl000je67wtl28pk42	cmd06nnbb000be67wwgil78yv	2025-07-18 08:03:42.915	2025-07-18 08:10:36.85
cmd8j69lv004h2bgt012z02jn	Rejected by Commission	completed	illness	anasumbuliwa na Sukari ya muda mrefu	2026-11-18 00:00:00	\N	{"Letter of Request","Medical Form","Leave Due to Illness Letter"}	\N	emp_019	cmd06nnbl000je67wtl28pk42	cmd06nnbb000be67wwgil78yv	2025-07-18 08:01:54.979	2025-07-18 08:23:42.869
cmddfdclq000he67k3er06bhd	Pending HRMO/HHRMD Review	initial	compulsory	\N	2039-04-19 00:00:00	\N	{"Letter of Request","Birth Certificate Copy (or equivalent)"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-21 18:14:17.87	2025-07-21 18:14:17.87
cmddfgkw4000je67kvceuud0n	Pending HRMO/HHRMD Review	initial	voluntary	\N	2034-04-19 00:00:00	\N	{"Letter of Request","Service Record Summary"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-21 18:16:48.547	2025-07-21 18:16:48.547
cmddfhspt000le67kvj10ibha	Rejected by HHRMD - Awaiting HRO Correction	initial	illness	saikolojia	2026-01-23 00:00:00	\N	{"Letter of Request","Medical Form","Leave Due to Illness Letter"}	sawa. lakini hamna hilo jambo	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-21 18:17:45.377	2025-07-22 21:27:16
cmdelwsqb0009e6johf0mtf7r	Approved by Commission	completed	compulsory	\N	2054-01-01 00:00:00	\N	{"Letter of Request","Birth Certificate Copy (or equivalent)"}	\N	ofisi_emp_022	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 14:05:09.107	2025-07-22 21:27:48.803
cmdgx16ok0001e6xob4uvjprz	Pending HRMO/HHRMD Review	initial	illness	saddryfg	2026-01-30 00:00:00	\N	{"Letter of Request","Medical Form","Leave Due to Illness Letter"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-24 04:52:01.896	2025-07-24 04:52:01.896
cmdiex7c1000de6rwr1623llg	Pending HRMO/HHRMD Review	initial	compulsory	\N	2060-09-14 00:00:00	sawa	{"Letter of Request","Birth Certificate Copy (or equivalent)","Delay Justification Document"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 06:00:35.425	2025-07-25 06:00:35.425
cmditcq2x000be6z0gv7zi7jc	Pending HRMO/HHRMD Review	initial	compulsory	\N	2047-10-16 00:00:00	hg uguiu  uiuhu	{retirement/20250725_154428_bfdd9bac.pdf,retirement/20250725_154419_a73adf0b.pdf}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 12:44:34.185	2025-07-25 12:44:34.185
cmdyeel5v000d2b41hjyrv61z	Approved by Commission	completed	voluntary	\N	2041-01-18 00:00:00	\N	{retirement/1754389956732_r5hu1r_ripoti_ya_kupandishwa_cheo_report.pdf}	\N	ofisi_emp_006	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-08-05 10:30:25.698	2025-08-05 10:34:05.875
cmdyepb9i000f2b418y9bolks	Approved by Commission	completed	illness	homa	2026-02-01 00:00:00	\N	{retirement/1754390323477_leakb1_ya_kuacha_kazi_report.pdf,retirement/1754390288814_u6b0y4_ya_kuacha_kazi_report.pdf,retirement/1754390289597_y5f11x_ripoti_ya_kustaafu_kwa_hiari_report.pdf}	\N	ofisi_emp_016	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 10:38:46.086	2025-08-05 10:42:34.168
cmdyc9yq700072b41iktn5ptk	Approved by Commission	completed	compulsory	\N	2051-08-25 00:00:00	\N	{retirement/1754386518177_2bubos_ya_kuacha_kazi_report.pdf}	\N	ofisi_emp_023	cmd06nnbn000le67wtg41s3su	cmd06nnbb000be67wwgil78yv	2025-08-05 09:30:50.767	2025-08-05 09:36:48.143
cme2wb4zn00012bjvi11a1bsh	Pending HRMO/HHRMD Review	initial	illness	kifafa	2025-08-08 14:02:42.525	\N	{retirement/1754661109482_pzemw5_Employee_Profile_Analysis.pdf,retirement/1754661097999_duccoi_cheti.pdf,retirement/1754661104381_6uvnif_sababu.pdf}	\N	emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-08-08 14:02:42.527	2025-08-08 14:02:42.527
cmditpbu4000de6z021tx46ca	Rejected by HHRMD - Awaiting HRO Correction	initial	compulsory	\N	2049-10-13 00:00:00	hg hfhfy yf	{retirement/20250725_155420_1b09e784.pdf,retirement/20250725_155417_c0051a50.pdf}	haipo sahihi	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-25 12:54:22.253	2025-08-10 13:31:23.979
cme2wcwfo00032bjvb0hf1loe	Approved by Commission	completed	illness	homa ya mdudu	2025-08-08 14:04:04.786	\N	{retirement/1754661840537_s46ycb_sababu.pdf,retirement/1754661833171_6tp38c_cheti.pdf,retirement/1754661836857_v0btoz_Employee_Profile_Analysis.pdf}	\N	ofisi_emp_002	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-08 14:04:04.787	2025-08-08 14:13:13.154
cme4297s300012bqgqt6s5ems	Approved by Commission	completed	illness	kifafa	2025-08-09 09:36:56.737	\N	{retirement/1754732212130_6zluzs_ripoti_ya_kupandishwa_cheo_report__1_.pdf,retirement/1754732176812_dmj8ks_request_status_report_report.pdf,retirement/1754732192073_972lo6_1754407554728_bj7hik_sababu.pdf}	\N	emp_005	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-09 09:36:56.739	2025-08-10 13:32:20.943
cme3innw700012bpoqzo3xu3y	Rejected by Commission - Request Concluded	completed	illness	homa	2025-08-09 00:28:18.484	\N	{retirement/1754699295150_akhlcq_cheti.pdf,retirement/1754699279435_kuq3jw_1754403408864_8f2228_Employee_Profile_Analysis.pdf,retirement/1754699288995_7otdo1_request_status_report_report.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-09 00:28:18.485	2025-08-10 13:32:51.104
cme6065fb00032boivlznv5zh	Pending HRMO/HHRMD Review	initial	illness	kifafa	2025-08-10 18:14:06.836	\N	{retirement/1754849644180_0stbr2_20250725_071305_7f9eb5d3__2_.pdf,retirement/1754849627689_hqzsb5_cheti.pdf,retirement/1754849633905_bgsvyd_1754407554728_bj7hik_sababu.pdf}	\N	cme45oe2u000h2bfwmhka9n0f	cme471pqo00032bidhttxmboj	\N	2025-08-10 18:14:06.838	2025-08-10 18:14:06.838
cme4jxrnr000p2btjwgatstbv	Approved by Commission	completed	illness	kifaduru	2025-08-09 17:51:55.717	\N	{retirement/1754761911701_kk823u_20250725_100627_d2b91848__2_.pdf,retirement/1754761904336_bxmpko_1754403408864_8f2228_Employee_Profile_Analysis.pdf,retirement/1754761907725_a4gxkc_request_status_report_report.pdf}	\N	cme45oe31000l2bfw2kzug3tj	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-09 17:51:55.718	2025-08-10 13:25:56.275
278ec914-daf9-447d-9036-27ec66ef14ae	Pending HRMO/HHRMD Review	initial	compulsory	\N	2051-06-21 00:00:00	\N	{retirement/1764181865906_97mrvi_ripoti_ya_kupandishwa_cheo_report__1_.pdf}	\N	cme45oe2m000d2bfwd3agas2u	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:31:10.779	2025-11-26 18:31:10.777
\.


--
-- Data for Name: SeparationRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SeparationRequest" (id, type, status, "reviewStage", reason, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
cmd08nej50027e6qkjewf103l	DISMISSAL	APPROVED	FINAL_APPROVAL	Misconduct	{https://placehold.co/separation-notice.pdf,https://placehold.co/investigation-report.pdf}	\N	emp8	cmd06nnbs000pe67woh62ey8r	cmd06nnbq000ne67wwmiwxuo8	2025-06-18 12:45:09.329	2025-07-04 12:45:09.329
cmd08nej90029e6qka900uy17	DISMISSAL	PENDING	DIRECTOR_REVIEW	Redundancy	{https://placehold.co/separation-notice.pdf,https://placehold.co/investigation-report.pdf}	\N	emp8	cmd06nnbn000le67wtg41s3su	cmd06nnbs000pe67woh62ey8r	2025-07-11 12:45:09.332	2025-07-12 12:45:09.332
cmd1yzff20001e64rye8l1b40	TERMINATION	Pending DO/HHRMD Review	initial	Performance issues leading to termination	{"Letter of Request"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 17:50:06.542	2025-07-13 17:50:06.542
cmd1z9w5s0001e6o733qfcck0	DISMISSAL	Pending DO/HHRMD Review	initial	hapendi kazi	{"Letter of Request","Supporting Document for Dismissal"}	\N	emp_005	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 17:58:14.8	2025-07-13 17:58:14.8
cmd1zj0bs0003e6o720c9i7ny	TERMINATION	Pending DO/HHRMD Review	initial	Poor performance during probation period	{"Letter of Request","Supporting Document for Termination"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 18:05:20.104	2025-07-13 18:05:20.104
cmd1zlcvx0005e6o7eye8ukb7	DISMISSAL	Pending DO/HHRMD Review	initial	Serious misconduct and violation of company policies leading to dismissal	{"Letter of Request","Misconduct Evidence & Investigation Report","Summon Notice/Invitation Letter","Suspension Letter"}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 18:07:09.694	2025-07-13 18:07:09.694
cmddftc0z000re67komb81fh8	DISMISSAL	Pending DO/HHRMD Review	initial	mtoro kazini	{"Letter of Request","Misconduct Evidence & Investigation Report","Summon Notice/Invitation Letter","Suspension Letter","Warning Letter(s)","Employee Explanation Letter","Other Additional Document(s)"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-21 18:26:43.619	2025-07-21 18:26:43.619
cmdihaci1000ne6rwr9nidetj	DISMISSAL	Pending DO/HHRMD Review	initial	ysertsertyretre	{termination/20250725_100627_d2b91848.pdf,termination/20250725_100630_ec200737.pdf,termination/20250725_100633_806c45e6.pdf,termination/20250725_100635_0212cff2.pdf,termination/20250725_100638_6787fe45.pdf,termination/20250725_100641_a033e545.pdf,termination/20250725_100646_810f8703.pdf}	\N	ofisi_emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 07:06:47.881	2025-07-25 07:06:47.881
cmdf365yd0003e6lc3gzcs74w	DISMISSAL	Approved by Commission	completed	hana nidhamu	{"Letter of Request","Misconduct Evidence & Investigation Report","Summon Notice/Invitation Letter","Suspension Letter","Warning Letter(s)","Employee Explanation Letter","Other Additional Document(s)"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 22:08:19.621	2025-07-22 22:08:57.983
cmdis0clw0001e6z0k205q7z6	DISMISSAL	Pending DO/HHRMD Review	initial	sawa	{termination/20250725_150625_5e421f84.pdf,termination/20250725_150629_4e8ba9a4.pdf,termination/20250725_150634_d05ba9db.pdf,termination/20250725_150638_c3adea6c.pdf,termination/20250725_150642_fb3610ac.pdf,termination/20250725_150648_987ecd29.pdf,termination/20250725_150655_2e165091.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 12:06:57.236	2025-07-25 12:06:57.236
cmdf3jyjk0005e6lcqhdswe06	TERMINATION	Approved by Commission	completed	hana nidhamu ata kidogo	{"Letter of Request","Supporting Document"}	\N	ofisi_emp_019	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 22:19:03.2	2025-07-22 22:20:57.635
cmdf3opqb0007e6lcw1etegn1	DISMISSAL	Approved by Commission	completed	utoro kazini\\n mwezi wa tatu hajaja kazini	{"Letter of Request","Misconduct Evidence"}	\N	ofisi_emp_001	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 22:22:45.023	2025-07-22 22:23:47.722
cmdih5zbd000le6rw3nhbziss	DISMISSAL	Pending DO/HHRMD Review	initial	dddggdg	{termination/20250725_100304_91a10b05.pdf,termination/20250725_100306_5a59b7ef.pdf,termination/20250725_100309_1208a56c.pdf,termination/20250725_100312_4cf1940a.pdf,termination/20250725_100316_aa1639fe.pdf,termination/20250725_100318_76b1d1ff.pdf,termination/20250725_100321_54def8cc.pdf}	\N	ofisi_emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 07:03:24.169	2025-07-25 07:03:24.169
cmdxwm5gi00012b4is9eqnkkm	TERMINATION	Approved by Commission	completed	sawa	{termination/1754359928455_xzyuz2_Employee_Profile_Analysis.pdf,termination/1754359939672_pl5ppa_mfano.pdf}	\N	ofisi_emp_021	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 02:12:25.492	2025-08-05 02:16:29.446
cmdw6gm9m00032b0nrfk1p5ti	TERMINATION	Pending DO/HHRMD Review	initial	MTORO  sana tu 	{"Letter of Request","Supporting Document"}	\N	ofisi_emp_016	cmd06nnbn000le67wtg41s3su	cmd06nnbn000le67wtg41s3su	2025-08-03 21:12:31.162	2025-08-03 21:14:05.925
cmdxua45900052bgt5kbuh0l0	TERMINATION	Rejected by HHRMD - Awaiting HRO Correction	initial	mtoro kazini	{"Letter of Request","Supporting Document"}	sawa weka marekebisho ya mwisho	ofisi_emp_011	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 01:07:04.701	2025-08-05 01:54:44.862
cmdxg9v0k00012bgty7c5swt6	TERMINATION	Pending DO/HHRMD Review	initial	utoro kazini	{"Letter of Request","Supporting Document"}	\N	ofisi_emp_017	cmd06nnbn000le67wtg41s3su	cmd06nnbn000le67wtg41s3su	2025-08-04 18:34:58.242	2025-08-04 18:42:13.77
cmdy5lupz00012bd8otg922me	TERMINATION	Rejected by Commission - Request Concluded	completed	utoro kazini kwa muda mrefu	{termination/1754376102191_mivl2n_server_raf.pdf,termination/1754376107119_2ye2zs_lenovo_specs.pdf}	\N	ofisi_emp_014	cmd06nnbn000le67wtg41s3su	cmd06nnbd000de67wb6e6ild5	2025-08-05 06:24:08.111	2025-08-05 06:43:41.72
cmdy6e6zj00032bd8bp0lprlf	TERMINATION	Approved by Commission	completed	ukosefu wa nidhamu ya kazi	{termination/1754376363017_tymjvk_vitambulisho_tus_Billing.pdf,termination/1754376367828_nwrk6w_wma.pdf}	\N	ofisi_emp_014	cmd06nnbn000le67wtg41s3su	cmd06nnbd000de67wb6e6ild5	2025-08-05 06:46:10.398	2025-08-05 06:46:33.224
cmdxt4dm000032bgthsl85kby	TERMINATION	Approved by Commission	completed	mwizi	{termination/1754354061559_ekhtlc_Employee_Profile_Analysis.pdf,termination/1754354067796_pfkspp_sababu.pdf}	\N	ofisi_emp_012	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 00:34:37.415	2025-08-08 14:18:13.382
cme3iw5gt00012bubujbq9b0r	TERMINATION	Pending DO/HHRMD Review	initial	mtoro	{termination/1754699682997_tqld23_request_status_report_report.pdf,termination/1754699691979_lljhd8_1754407554728_bj7hik_sababu.pdf}	\N	ofisi_emp_011	cmd06nnbn000le67wtg41s3su	\N	2025-08-09 00:34:54.508	2025-08-09 00:34:54.508
cme4k2iel000v2btje0hid2zu	DISMISSAL	Pending DO/HHRMD Review	initial	tabia mbaya	{termination/1754762111255_u41m6m_ripoti_ya_kupandishwa_cheo_report__2_.pdf,termination/1754762115484_gm3pvg_request_status_report_report.pdf,termination/1754762118150_ubhljx_1754407554728_bj7hik_sababu.pdf,termination/1754762122238_uysr14_mfano.pdf,termination/1754762126459_1t3er8_20250802_094101_02331ce1.pdf,termination/1754762130488_ffryxx_ripoti_ya_nyongeza_ya_utumishi_report.pdf,termination/1754762135014_r235s0_1754676807327_mfbgv3_ripoti_ya_kupandishwa_cheo_report__2_.pdf}	\N	cme45oe31000l2bfw2kzug3tj	cme471pqo00032bidhttxmboj	\N	2025-08-09 17:55:37.004	2025-08-09 17:55:37.004
cmdy6ny4300052bd84v309zwu	DISMISSAL	Approved by Commission	completed	utoro kazini	{termination/1754377052672_968nmi_S0272_0013_2022ctrl-no-receipt.pdf,termination/1754377068928_14539a_ripoti_ya_kuthibitishwa_kazini_report.pdf}	\N	ofisi_emp_018	cmd06nnbn000le67wtg41s3su	cmd06nnbd000de67wb6e6ild5	2025-08-05 06:53:45.459	2025-08-05 07:02:41.172
cme60v68800052boipz2im84i	TERMINATION	Pending DO/HHRMD Review	initial	utoro kazini	{termination/1754850806473_ja8wdg_1754324616644_6r2ulr_cheti.pdf,termination/1754850811772_faa3ja_ripoti_ya_nyongeza_ya_utumishi_report.pdf}	\N	cme45oe2900072bfwwhh9l9wp	cme471pqo00032bidhttxmboj	\N	2025-08-10 18:33:34.279	2025-08-10 18:33:34.279
cmdyarxpa00012b410v8yykcr	DISMISSAL	Approved by Commission	completed	utoro kazini	{termination/1754383987109_ppz607_ripoti_ya_kuacha_kazi_report.pdf,termination/1754384014534_lob2ku_ripoti_ya_likizo_bila_malipo_report.pdf,termination/1754384021713_z43kjb_ripoti_ya_nyongeza_ya_utumishi_report.pdf,termination/1754384032297_cuz0zg_ripoti_ya_nyongeza_ya_utumishi_report.pdf,termination/1754384037952_yx7yzj_ripoti_ya_kustaafu_kwa_hiari_report.pdf,termination/1754384045308_8paxhl_ripoti_ya_kustaafu_kwa_lazima_report.pdf}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 08:48:50.014	2025-08-05 08:59:32.409
cme60yz9b00072boico1jxy1h	DISMISSAL	Approved by Commission	completed	mchelewaji kazini	{termination/1754850954646_zeaahe_mfano.pdf,termination/1754850958608_kpdi50_request_status_report_report.pdf,termination/1754850962824_b1zkzb_ripoti_ya_nyongeza_ya_utumishi_report.pdf,termination/1754850966223_cz2rfv_1754241939359_p95qlf_cheti.pdf,termination/1754850974556_azbuxq_1754241939359_p95qlf_cheti.pdf,termination/1754850978439_3kswa7_20250725_085101_a60b988b.pdf,termination/1754850982459_4gb66q_mfano.pdf}	\N	emp_013	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-10 18:36:31.871	2025-08-11 03:56:11.384
cmdy6ysrc00072bd8snffavt0	DISMISSAL	Approved by Commission	completed	mwizi  ana tabia mbaya	{termination/1754377292958_7yvbk9_2.pdf,termination/1754377292949_77styy_261-Ticket_with_NO_PRICE-2612A632.pdf,termination/1754377307462_pppx2s_2.pdf,termination/1754377293687_6mrdmq_lenovo_specs.pdf,termination/1754377314203_d70qpc_server_raf.pdf,termination/1754377321243_utik8x_261-Ticket_with_NO_PRICE-2612A632.pdf,termination/1754377330102_evx7rd_Concept_Note_and_appraisal_for_TUS_1_.pdf}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 07:02:11.736	2025-08-08 14:17:35.802
cme3efnac00012b06mlnpm7qs	DISMISSAL	Pending DO/HHRMD Review	initial	utoro kazini	{termination/1754692179413_vivutp_cheti.pdf,termination/1754692183495_u3arqf_cheti.pdf,termination/1754692187297_3mkghm_cheti.pdf,termination/1754692191970_wj3dgd_20250725_085101_a60b988b.pdf,termination/1754692195119_tjjh8q_1754324616644_6r2ulr_cheti.pdf,termination/1754692198237_h7ujif_1754324616644_6r2ulr_cheti__1_.pdf,termination/1754692204419_s6mse5_request_status_report_report.pdf}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-08-08 22:30:05.988	2025-08-08 22:30:05.988
cme7l61ya00012bku0abi5805	TERMINATION	Approved by Commission	completed	utoro kazini	{termination/1754945345580_e3k64k_20250727_085642_76b47a49.pdf,termination/1754945374848_lau26x_1754324616644_6r2ulr_cheti__1_.pdf}	\N	ofisi_emp_013	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-11 20:49:40.45	2025-08-11 20:52:27.764
92cf434f-4b4a-4551-b1ff-0be44ccd88e0	DISMISSAL	Pending DO/HHRMD Review	initial	utoro kazini	{termination/1764182015360_7tgw1s_20250802_081604_d8a23939.pdf,termination/1764182020070_65l8zo_Mozilla-Recovery-Key_2025-07-12_yussufrajab_gmail.com.pdf,termination/1764182024631_73ie4g_ripoti_ya_kupandishwa_cheo_report__2_.pdf,termination/1764182031093_6raxoc_Mozilla-Recovery-Key_2025-07-12_yussufrajab_gmail.com.pdf,termination/1764182035344_0p5y6u_ripoti_ya_kustaafu_kwa_hiari_report.pdf,termination/1764182043651_s9bwuw_20250727_191723_354fd63d.pdf}	\N	cme45oe2m000d2bfwd3agas2u	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:34:18.044	2025-11-26 18:34:18.043
\.


--
-- Data for Name: ServiceExtensionRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceExtensionRequest" (id, status, "reviewStage", "currentRetirementDate", "requestedExtensionPeriod", justification, documents, "rejectionReason", "employeeId", "submittedById", "reviewedById", "createdAt", "updatedAt") FROM stdin;
cmd08neiy0021e6qkih2j9cxo	REJECTED	INITIAL	2025-12-24 12:45:09.322	6 months	Expertise shortage	{https://placehold.co/extension-application.pdf,https://placehold.co/justification-report.pdf}	Extension not supported by institutional policy	emp1	cmd06nnbu000re67wdeax0fwp	\N	2025-06-02 12:45:09.322	2025-06-28 12:45:09.322
cmd08nej10023e6qkp5874720	UNDER_REVIEW	COMMISSION_REVIEW	2026-01-10 12:45:09.324	6 months	Expertise shortage	{https://placehold.co/extension-application.pdf,https://placehold.co/justification-report.pdf}	\N	emp1	cmd06nnbx000te67ww4cbaug7	\N	2025-06-08 12:45:09.324	2025-07-02 12:45:09.324
cmd08nej30025e6qkyocw002b	REJECTED	DIRECTOR_REVIEW	2025-09-16 12:45:09.326	1 year	Knowledge transfer requirements	{https://placehold.co/extension-application.pdf,https://placehold.co/justification-report.pdf}	Extension not supported by institutional policy	emp1	cmd06nnbu000re67wdeax0fwp	cmd06nnbn000le67wtg41s3su	2025-06-21 12:45:09.326	2025-07-06 12:45:09.326
cmd1y7rt50009e60yo3cjaeu3	Pending HRMO/HHRMD Review	initial	2025-07-19 00:00:00	1 year	kuna uhitaji	{"Letter of Request","Employee Consent Letter"}	\N	emp_003	cmd06nnbn000le67wtg41s3su	\N	2025-07-13 17:28:36.233	2025-07-13 17:34:20.329
cmd8kpux0005r2bgtwl3xgvk4	Pending HRMO/HHRMD Review	initial	2026-10-18 00:00:00	1 year	Utaaalamu bado unahitajika	{"Letter of Request","Employee Consent Letter"}	\N	emp_022	cmd06nnbl000je67wtl28pk42	\N	2025-07-18 08:45:08.675	2025-07-18 08:45:08.675
cmd8kr7q2005t2bgtrcij6k5k	Pending HRMO/HHRMD Review	initial	2025-08-23 00:00:00	1 year	qsfgffdbgf ghjgjgtjjgjjghj fhtrhhehh	{"Letter of Request","Employee Consent Letter"}	\N	emp_020	cmd06nnbl000je67wtl28pk42	\N	2025-07-18 08:46:11.93	2025-07-18 08:46:11.93
cmddfjoqt000pe67ksj3vnypn	Pending HRMO/HHRMD Review	initial	2025-07-24 00:00:00	1 year	kuna uhitaji	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-21 18:19:13.541	2025-07-21 18:19:13.541
cmdf32bir0001e6lcaq6m1i6s	Approved by Commission	completed	2025-07-31 00:00:00	1 year	sawa	{"Letter of Request","Employee Consent Letter"}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-07-22 22:05:20.211	2025-07-22 22:07:04.5
cmdis8v5h0003e6z0hs6aq0xd	Pending HRMO/HHRMD Review	initial	2025-08-08 00:00:00	1 year	gfdgdfgdf f fgdfgds gfdggdfdf	{service-extension/20250725_151327_ae788ffe.pdf,service-extension/20250725_151332_89b62975.pdf}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-07-25 12:13:34.481	2025-07-25 12:13:34.481
cmdw6lco500052b0nwl0skq4x	Pending HRMO/HHRMD Review	initial	2025-08-16 00:00:00	1 year	sawa	{service-extension/1754255765472_nofexn_sababu.pdf,service-extension/1754255768686_zvalqd_cheti.pdf}	\N	ofisi_emp_018	cmd06nnbn000le67wtg41s3su	\N	2025-08-03 21:16:12.005	2025-08-03 21:16:12.005
cmdw9swi800012bwmvk9hbgeg	Pending HRMO/HHRMD Review	initial	2025-08-08 00:00:00	1 year	waa	{service-extension/1754261314174_6o29hi_Employee_Profile_Analysis.pdf,service-extension/1754261324406_el8uhd_sababu.pdf}	\N	ofisi_emp_007	cmd06nnbn000le67wtg41s3su	\N	2025-08-03 22:46:03.152	2025-08-03 22:48:46.948
cmdw6mont00072b0n61d124gt	Request Received – Awaiting Commission Decision	commission_review	2025-08-22 00:00:00	1 year	saw  lote	{service-extension/1754255948347_s7nar4_mfano.pdf,service-extension/1754255952178_8ds7rh_sababu.pdf}	\N	emp_006	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-03 21:17:14.201	2025-08-03 21:19:44.762
cme3e5l14000b2b5ratysofi0	Pending HRMO/HHRMD Review	initial	2025-08-23 00:00:00	1 year	kuna uhitaji	{service-extension/1754691731332_eopdad_1754403408864_8f2228_Employee_Profile_Analysis.pdf,service-extension/1754691734508_0uzo0v_mfano.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-08-08 22:22:16.504	2025-08-08 22:22:16.504
cme42h17r00012bw1krrqjqm4	Pending HRMO/HHRMD Review	initial	2025-08-23 00:00:00	1 year	kuna uhitaji	{service-extension/1754732551051_8pnmtk_1754676807327_mfbgv3_ripoti_ya_kupandishwa_cheo_report__2_.pdf,service-extension/1754732578566_akrdmo_request_status_report_report.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-08-09 09:43:01.479	2025-08-09 09:43:01.479
cmdw779u000092b0nrfvkgjff	Approved by Commission	completed	2025-08-14 00:00:00	1 year	uko	{service-extension/1754257509217_0ezpz9_mfano.pdf,service-extension/1754257513164_06piby_sababu.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-03 21:33:14.759	2025-08-03 21:47:09.78
cmdw86w5k00012bwjcp4v7tyf	Rejected by HHRMD - Awaiting HRO Correction	hro_correction	2025-08-31 00:00:00	1 year	now shoe	{service-extension/1754258446076_xloh0b_Employee_Profile_Analysis.pdf,service-extension/1754258454061_8a0cz5_sababu.pdf}	ongeza maelezo zaidi	ofisi_emp_003	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-03 22:00:56.649	2025-08-03 22:01:40.666
cmdybg8tl00032b41z4faeaiq	Approved by Commission	completed	2041-05-06 00:00:00	2 years	uzoefu	{service-extension/1754385003021_tw09wj_ripoti_ya_kuacha_kazi_report.pdf,service-extension/1754385005725_62vd66_ripoti_ya_kustaafu_kwa_lazima_report.pdf}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-05 09:07:44.139	2025-08-05 09:12:16.903
cme4k1906000t2btjkubx5fdm	Approved by Commission	completed	2025-08-24 00:00:00	1 year	kuna uhitaji	{service-extension/1754762071504_gxba0m_1754324616644_6r2ulr_cheti__1_.pdf,service-extension/1754762076362_o5n1r9_1754324616644_6r2ulr_cheti__1_.pdf}	\N	cme45oe31000l2bfw2kzug3tj	cme471pqo00032bidhttxmboj	cmd059ir10002e6d86l802ljc	2025-08-09 17:54:38.166	2025-08-10 12:58:41.589
cmdxcb8tv00052bwmr80gj6sm	Approved by Commission	completed	2025-08-10 00:00:00	1 year	sawa nimerekebisha	{service-extension/1754326931072_hog5k7_cheti.pdf,service-extension/1754326934993_4tbvvz_sababu.pdf}	\N	ofisi_emp_010	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-04 16:44:04.338	2025-08-04 18:21:50.75
cmdxbl5sy00032bwmfi6bt6li	Rejected by Commission - Request Concluded	completed	2025-08-14 00:00:00	1 year	kuna uhitaji	{service-extension/1754325257729_setcht_cheti.pdf,service-extension/1754325261889_q3pu1q_Employee_Profile_Analysis.pdf}	\N	ofisi_emp_006	cmd06nnbn000le67wtg41s3su	cmd059ir10002e6d86l802ljc	2025-08-04 16:23:47.358	2025-08-08 12:01:26.514
9c07b98c-6166-4e18-91af-43adfd3367cd	Pending HRMO/HHRMD Review	initial	2025-11-28 00:00:00	1 year	kuna uhitaji	{service-extension/1764156244490_58le0v_ya_nyongeza_ya_utumi....pdf,service-extension/1764156252356_rbxqh9_architecture_comparison.pdf}	\N	emp_001	cmd06nnbn000le67wtg41s3su	\N	2025-11-26 11:24:14.922	2025-11-26 11:24:14.92
54d176e3-c2ca-430b-afca-c5dd2e5c23f4	Pending HRMO/HHRMD Review	initial	2025-12-03 00:00:00	1 year	kuna uhitaji	{service-extension/1764181976852_bktr3b_ripoti_ya_kupandishwa_cheo_report__2_.pdf,service-extension/1764181981614_g4k4i4_status.pdf}	\N	cme45oe2m000d2bfwd3agas2u	cme471pqo00032bidhttxmboj	\N	2025-11-26 18:33:09.296	2025-11-26 18:33:09.294
\.


--
-- PostgreSQL database dump complete
--

\unrestrict wuaHYbh3S3LeOo3jU55EsnxYwnfB49cQKFAVe3xEV9rMKXEwIKW3EAlstvFjmkk

