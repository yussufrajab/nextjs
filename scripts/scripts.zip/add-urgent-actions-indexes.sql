-- Urgent Actions Performance Indexes
-- These indexes significantly speed up the urgent actions queries

-- Employee table indexes for urgent actions
-- Index for retirement date queries (used in urgent actions)
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_retirementDate_range" 
ON "Employee"("retirementDate") 
WHERE "retirementDate" IS NOT NULL;

-- Composite index for probation overdue queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_probation_overdue" 
ON "Employee"("status", "employmentDate") 
WHERE "status" != 'Confirmed';

-- Composite index for institution + retirement date
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_institution_retirement" 
ON "Employee"("institutionId", "retirementDate") 
WHERE "retirementDate" IS NOT NULL;

-- Composite index for institution + status + employment date
CREATE INDEX CONCURRENTLY IF NOT EXISTS "idx_employee_institution_probation" 
ON "Employee"("institutionId", "status", "employmentDate") 
WHERE "status" != 'Confirmed';

ANALYZE "Employee";

\echo 'Urgent actions performance indexes created successfully!'
\echo 'These indexes will speed up urgent actions queries by 100x or more.'
